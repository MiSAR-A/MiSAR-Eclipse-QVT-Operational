/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service Pattern Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.ServicePatternComponent#getPatternName <em>Pattern Name</em>}</li>
 *   <li>{@link PIM.ServicePatternComponent#getComponentRole <em>Component Role</em>}</li>
 *   <li>{@link PIM.ServicePatternComponent#getComponentType <em>Component Type</em>}</li>
 *   <li>{@link PIM.ServicePatternComponent#getSubcomponent <em>Subcomponent</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getServicePatternComponent()
 * @model
 * @generated
 */
public interface ServicePatternComponent extends EObject {
	/**
	 * Returns the value of the '<em><b>Pattern Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pattern Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pattern Name</em>' attribute.
	 * @see #setPatternName(String)
	 * @see PIM.PIMPackage#getServicePatternComponent_PatternName()
	 * @model
	 * @generated
	 */
	String getPatternName();

	/**
	 * Sets the value of the '{@link PIM.ServicePatternComponent#getPatternName <em>Pattern Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pattern Name</em>' attribute.
	 * @see #getPatternName()
	 * @generated
	 */
	void setPatternName(String value);

	/**
	 * Returns the value of the '<em><b>Component Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Component Role</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Component Role</em>' attribute.
	 * @see #setComponentRole(String)
	 * @see PIM.PIMPackage#getServicePatternComponent_ComponentRole()
	 * @model
	 * @generated
	 */
	String getComponentRole();

	/**
	 * Sets the value of the '{@link PIM.ServicePatternComponent#getComponentRole <em>Component Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Component Role</em>' attribute.
	 * @see #getComponentRole()
	 * @generated
	 */
	void setComponentRole(String value);

	/**
	 * Returns the value of the '<em><b>Component Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Component Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Component Type</em>' attribute.
	 * @see #setComponentType(String)
	 * @see PIM.PIMPackage#getServicePatternComponent_ComponentType()
	 * @model
	 * @generated
	 */
	String getComponentType();

	/**
	 * Sets the value of the '{@link PIM.ServicePatternComponent#getComponentType <em>Component Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Component Type</em>' attribute.
	 * @see #getComponentType()
	 * @generated
	 */
	void setComponentType(String value);

	/**
	 * Returns the value of the '<em><b>Subcomponent</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.ServicePatternComponent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcomponent</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcomponent</em>' containment reference list.
	 * @see PIM.PIMPackage#getServicePatternComponent_Subcomponent()
	 * @model containment="true"
	 * @generated
	 */
	EList<ServicePatternComponent> getSubcomponent();

} // ServicePatternComponent
