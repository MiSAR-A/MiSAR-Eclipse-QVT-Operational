/**
 */
package PIM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Infrastructure Microservice</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getInfrastructureMicroservice()
 * @model
 * @generated
 */
public interface InfrastructureMicroservice extends Microservice {
} // InfrastructureMicroservice
