/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rest Endpoint</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.RestEndpoint#getEndpointPath <em>Endpoint Path</em>}</li>
 *   <li>{@link PIM.RestEndpoint#getHttpRequest <em>Http Request</em>}</li>
 *   <li>{@link PIM.RestEndpoint#getMessage <em>Message</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getRestEndpoint()
 * @model
 * @generated
 */
public interface RestEndpoint extends EObject {
	/**
	 * Returns the value of the '<em><b>Endpoint Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Endpoint Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Endpoint Path</em>' attribute.
	 * @see #setEndpointPath(String)
	 * @see PIM.PIMPackage#getRestEndpoint_EndpointPath()
	 * @model
	 * @generated
	 */
	String getEndpointPath();

	/**
	 * Sets the value of the '{@link PIM.RestEndpoint#getEndpointPath <em>Endpoint Path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Endpoint Path</em>' attribute.
	 * @see #getEndpointPath()
	 * @generated
	 */
	void setEndpointPath(String value);

	/**
	 * Returns the value of the '<em><b>Http Request</b></em>' attribute.
	 * The default value is <code>"GET"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Http Request</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Http Request</em>' attribute.
	 * @see #setHttpRequest(String)
	 * @see PIM.PIMPackage#getRestEndpoint_HttpRequest()
	 * @model default="GET"
	 * @generated
	 */
	String getHttpRequest();

	/**
	 * Sets the value of the '{@link PIM.RestEndpoint#getHttpRequest <em>Http Request</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Http Request</em>' attribute.
	 * @see #getHttpRequest()
	 * @generated
	 */
	void setHttpRequest(String value);

	/**
	 * Returns the value of the '<em><b>Message</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.Message}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Message</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message</em>' containment reference list.
	 * @see PIM.PIMPackage#getRestEndpoint_Message()
	 * @model containment="true"
	 * @generated
	 */
	EList<Message> getMessage();

} // RestEndpoint
