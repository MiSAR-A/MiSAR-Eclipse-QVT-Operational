/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservice Architecture Static Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.MicroserviceArchitectureStaticModel#getContainers <em>Containers</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getMicroserviceArchitectureStaticModel()
 * @model
 * @generated
 */
public interface MicroserviceArchitectureStaticModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Containers</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.Container}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Containers</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containers</em>' containment reference list.
	 * @see PIM.PIMPackage#getMicroserviceArchitectureStaticModel_Containers()
	 * @model containment="true" lower="2"
	 * @generated
	 */
	EList<Container> getContainers();

} // MicroserviceArchitectureStaticModel
