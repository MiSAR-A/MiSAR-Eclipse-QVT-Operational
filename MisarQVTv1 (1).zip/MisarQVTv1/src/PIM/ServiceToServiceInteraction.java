/**
 */
package PIM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Service To Service Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.ServiceToServiceInteraction#getConsumerMicroservice <em>Consumer Microservice</em>}</li>
 *   <li>{@link PIM.ServiceToServiceInteraction#getProviderMicroservice <em>Provider Microservice</em>}</li>
 *   <li>{@link PIM.ServiceToServiceInteraction#getProvider <em>Provider</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getServiceToServiceInteraction()
 * @model
 * @generated
 */
public interface ServiceToServiceInteraction extends EObject {
	/**
	 * Returns the value of the '<em><b>Consumer Microservice</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Consumer Microservice</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consumer Microservice</em>' attribute.
	 * @see #setConsumerMicroservice(String)
	 * @see PIM.PIMPackage#getServiceToServiceInteraction_ConsumerMicroservice()
	 * @model
	 * @generated
	 */
	String getConsumerMicroservice();

	/**
	 * Sets the value of the '{@link PIM.ServiceToServiceInteraction#getConsumerMicroservice <em>Consumer Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Consumer Microservice</em>' attribute.
	 * @see #getConsumerMicroservice()
	 * @generated
	 */
	void setConsumerMicroservice(String value);

	/**
	 * Returns the value of the '<em><b>Provider Microservice</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provider Microservice</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provider Microservice</em>' attribute.
	 * @see #setProviderMicroservice(String)
	 * @see PIM.PIMPackage#getServiceToServiceInteraction_ProviderMicroservice()
	 * @model
	 * @generated
	 */
	String getProviderMicroservice();

	/**
	 * Sets the value of the '{@link PIM.ServiceToServiceInteraction#getProviderMicroservice <em>Provider Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provider Microservice</em>' attribute.
	 * @see #getProviderMicroservice()
	 * @generated
	 */
	void setProviderMicroservice(String value);

	/**
	 * Returns the value of the '<em><b>Provider</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Provider</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Provider</em>' containment reference.
	 * @see #setProvider(Interface)
	 * @see PIM.PIMPackage#getServiceToServiceInteraction_Provider()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Interface getProvider();

	/**
	 * Sets the value of the '{@link PIM.ServiceToServiceInteraction#getProvider <em>Provider</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Provider</em>' containment reference.
	 * @see #getProvider()
	 * @generated
	 */
	void setProvider(Interface value);

} // ServiceToServiceInteraction
