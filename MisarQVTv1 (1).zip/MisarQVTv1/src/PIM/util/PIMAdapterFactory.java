/**
 */
package PIM.util;

import PIM.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see PIM.PIMPackage
 * @generated
 */
public class PIMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PIMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PIMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PIMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PIMSwitch<Adapter> modelSwitch =
		new PIMSwitch<Adapter>() {
			@Override
			public Adapter caseRootPIM(RootPIM object) {
				return createRootPIMAdapter();
			}
			@Override
			public Adapter caseMicroservicesArchitectureModel(MicroservicesArchitectureModel object) {
				return createMicroservicesArchitectureModelAdapter();
			}
			@Override
			public Adapter caseMicroserviceArchitectureStaticModel(MicroserviceArchitectureStaticModel object) {
				return createMicroserviceArchitectureStaticModelAdapter();
			}
			@Override
			public Adapter caseAmbient(Ambient object) {
				return createAmbientAdapter();
			}
			@Override
			public Adapter caseContainer(Container object) {
				return createContainerAdapter();
			}
			@Override
			public Adapter casePort(Port object) {
				return createPortAdapter();
			}
			@Override
			public Adapter caseMicroservice(Microservice object) {
				return createMicroserviceAdapter();
			}
			@Override
			public Adapter caseFunctionalMicroservice(FunctionalMicroservice object) {
				return createFunctionalMicroserviceAdapter();
			}
			@Override
			public Adapter caseInfrastructureMicroservice(InfrastructureMicroservice object) {
				return createInfrastructureMicroserviceAdapter();
			}
			@Override
			public Adapter caseServicePatternComponent(ServicePatternComponent object) {
				return createServicePatternComponentAdapter();
			}
			@Override
			public Adapter caseServerComponent(ServerComponent object) {
				return createServerComponentAdapter();
			}
			@Override
			public Adapter caseClientComponent(ClientComponent object) {
				return createClientComponentAdapter();
			}
			@Override
			public Adapter caseInterface(Interface object) {
				return createInterfaceAdapter();
			}
			@Override
			public Adapter caseInteractionProtocol(InteractionProtocol object) {
				return createInteractionProtocolAdapter();
			}
			@Override
			public Adapter caseSynchronousInteractionProtocol(SynchronousInteractionProtocol object) {
				return createSynchronousInteractionProtocolAdapter();
			}
			@Override
			public Adapter caseAsynchronousInteractionProtocol(AsynchronousInteractionProtocol object) {
				return createAsynchronousInteractionProtocolAdapter();
			}
			@Override
			public Adapter caseInteractionDestination(InteractionDestination object) {
				return createInteractionDestinationAdapter();
			}
			@Override
			public Adapter caseProperty(Property object) {
				return createPropertyAdapter();
			}
			@Override
			public Adapter caseMessage(Message object) {
				return createMessageAdapter();
			}
			@Override
			public Adapter caseMicroservicesArchitectureInteractionModel(MicroservicesArchitectureInteractionModel object) {
				return createMicroservicesArchitectureInteractionModelAdapter();
			}
			@Override
			public Adapter caseServiceToServiceInteraction(ServiceToServiceInteraction object) {
				return createServiceToServiceInteractionAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link PIM.RootPIM <em>Root PIM</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.RootPIM
	 * @generated
	 */
	public Adapter createRootPIMAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.MicroservicesArchitectureModel <em>Microservices Architecture Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.MicroservicesArchitectureModel
	 * @generated
	 */
	public Adapter createMicroservicesArchitectureModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.MicroserviceArchitectureStaticModel <em>Microservice Architecture Static Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.MicroserviceArchitectureStaticModel
	 * @generated
	 */
	public Adapter createMicroserviceArchitectureStaticModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Ambient <em>Ambient</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Ambient
	 * @generated
	 */
	public Adapter createAmbientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Container <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Container
	 * @generated
	 */
	public Adapter createContainerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Port
	 * @generated
	 */
	public Adapter createPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Microservice <em>Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Microservice
	 * @generated
	 */
	public Adapter createMicroserviceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.FunctionalMicroservice <em>Functional Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.FunctionalMicroservice
	 * @generated
	 */
	public Adapter createFunctionalMicroserviceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.InfrastructureMicroservice <em>Infrastructure Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.InfrastructureMicroservice
	 * @generated
	 */
	public Adapter createInfrastructureMicroserviceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.ServicePatternComponent <em>Service Pattern Component</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.ServicePatternComponent
	 * @generated
	 */
	public Adapter createServicePatternComponentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.ServerComponent <em>Server Component</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.ServerComponent
	 * @generated
	 */
	public Adapter createServerComponentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.ClientComponent <em>Client Component</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.ClientComponent
	 * @generated
	 */
	public Adapter createClientComponentAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Interface <em>Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Interface
	 * @generated
	 */
	public Adapter createInterfaceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.InteractionProtocol <em>Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.InteractionProtocol
	 * @generated
	 */
	public Adapter createInteractionProtocolAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.SynchronousInteractionProtocol <em>Synchronous Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.SynchronousInteractionProtocol
	 * @generated
	 */
	public Adapter createSynchronousInteractionProtocolAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.AsynchronousInteractionProtocol <em>Asynchronous Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.AsynchronousInteractionProtocol
	 * @generated
	 */
	public Adapter createAsynchronousInteractionProtocolAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.InteractionDestination <em>Interaction Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.InteractionDestination
	 * @generated
	 */
	public Adapter createInteractionDestinationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Property <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Property
	 * @generated
	 */
	public Adapter createPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.Message <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.Message
	 * @generated
	 */
	public Adapter createMessageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.MicroservicesArchitectureInteractionModel <em>Microservices Architecture Interaction Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.MicroservicesArchitectureInteractionModel
	 * @generated
	 */
	public Adapter createMicroservicesArchitectureInteractionModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PIM.ServiceToServiceInteraction <em>Service To Service Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PIM.ServiceToServiceInteraction
	 * @generated
	 */
	public Adapter createServiceToServiceInteractionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PIMAdapterFactory
