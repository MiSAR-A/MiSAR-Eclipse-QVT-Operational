/**
 */
package PIM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservices Architecture Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.MicroservicesArchitectureModel#getArchitectureName <em>Architecture Name</em>}</li>
 *   <li>{@link PIM.MicroservicesArchitectureModel#getStaticModel <em>Static Model</em>}</li>
 *   <li>{@link PIM.MicroservicesArchitectureModel#getInteractionModel <em>Interaction Model</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getMicroservicesArchitectureModel()
 * @model
 * @generated
 */
public interface MicroservicesArchitectureModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Architecture Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Architecture Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Architecture Name</em>' attribute.
	 * @see #setArchitectureName(String)
	 * @see PIM.PIMPackage#getMicroservicesArchitectureModel_ArchitectureName()
	 * @model required="true"
	 * @generated
	 */
	String getArchitectureName();

	/**
	 * Sets the value of the '{@link PIM.MicroservicesArchitectureModel#getArchitectureName <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Architecture Name</em>' attribute.
	 * @see #getArchitectureName()
	 * @generated
	 */
	void setArchitectureName(String value);

	/**
	 * Returns the value of the '<em><b>Static Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Static Model</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Static Model</em>' containment reference.
	 * @see #setStaticModel(MicroserviceArchitectureStaticModel)
	 * @see PIM.PIMPackage#getMicroservicesArchitectureModel_StaticModel()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroserviceArchitectureStaticModel getStaticModel();

	/**
	 * Sets the value of the '{@link PIM.MicroservicesArchitectureModel#getStaticModel <em>Static Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Static Model</em>' containment reference.
	 * @see #getStaticModel()
	 * @generated
	 */
	void setStaticModel(MicroserviceArchitectureStaticModel value);

	/**
	 * Returns the value of the '<em><b>Interaction Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction Model</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction Model</em>' containment reference.
	 * @see #setInteractionModel(MicroservicesArchitectureInteractionModel)
	 * @see PIM.PIMPackage#getMicroservicesArchitectureModel_InteractionModel()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroservicesArchitectureInteractionModel getInteractionModel();

	/**
	 * Sets the value of the '{@link PIM.MicroservicesArchitectureModel#getInteractionModel <em>Interaction Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interaction Model</em>' containment reference.
	 * @see #getInteractionModel()
	 * @generated
	 */
	void setInteractionModel(MicroservicesArchitectureInteractionModel value);

} // MicroservicesArchitectureModel
