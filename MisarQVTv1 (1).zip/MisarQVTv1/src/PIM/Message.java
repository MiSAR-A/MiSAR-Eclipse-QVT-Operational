/**
 */
package PIM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Message</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.Message#getMessageType <em>Message Type</em>}</li>
 *   <li>{@link PIM.Message#getBodyFormat <em>Body Format</em>}</li>
 *   <li>{@link PIM.Message#getFormatLanguage <em>Format Language</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getMessage()
 * @model
 * @generated
 */
public interface Message extends EObject {
	/**
	 * Returns the value of the '<em><b>Message Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Message Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message Type</em>' attribute.
	 * @see #setMessageType(String)
	 * @see PIM.PIMPackage#getMessage_MessageType()
	 * @model
	 * @generated
	 */
	String getMessageType();

	/**
	 * Sets the value of the '{@link PIM.Message#getMessageType <em>Message Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Message Type</em>' attribute.
	 * @see #getMessageType()
	 * @generated
	 */
	void setMessageType(String value);

	/**
	 * Returns the value of the '<em><b>Body Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Body Format</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Body Format</em>' attribute.
	 * @see #setBodyFormat(String)
	 * @see PIM.PIMPackage#getMessage_BodyFormat()
	 * @model
	 * @generated
	 */
	String getBodyFormat();

	/**
	 * Sets the value of the '{@link PIM.Message#getBodyFormat <em>Body Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Body Format</em>' attribute.
	 * @see #getBodyFormat()
	 * @generated
	 */
	void setBodyFormat(String value);

	/**
	 * Returns the value of the '<em><b>Format Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Format Language</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Format Language</em>' attribute.
	 * @see #setFormatLanguage(String)
	 * @see PIM.PIMPackage#getMessage_FormatLanguage()
	 * @model
	 * @generated
	 */
	String getFormatLanguage();

	/**
	 * Sets the value of the '{@link PIM.Message#getFormatLanguage <em>Format Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Format Language</em>' attribute.
	 * @see #getFormatLanguage()
	 * @generated
	 */
	void setFormatLanguage(String value);

} // Message
