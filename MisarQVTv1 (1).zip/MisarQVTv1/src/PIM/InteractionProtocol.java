/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.InteractionProtocol#getProtocolName <em>Protocol Name</em>}</li>
 *   <li>{@link PIM.InteractionProtocol#getInteractionType <em>Interaction Type</em>}</li>
 *   <li>{@link PIM.InteractionProtocol#getDestinations <em>Destinations</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getInteractionProtocol()
 * @model
 * @generated
 */
public interface InteractionProtocol extends EObject {
	/**
	 * Returns the value of the '<em><b>Protocol Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Protocol Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol Name</em>' attribute.
	 * @see #setProtocolName(String)
	 * @see PIM.PIMPackage#getInteractionProtocol_ProtocolName()
	 * @model
	 * @generated
	 */
	String getProtocolName();

	/**
	 * Sets the value of the '{@link PIM.InteractionProtocol#getProtocolName <em>Protocol Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol Name</em>' attribute.
	 * @see #getProtocolName()
	 * @generated
	 */
	void setProtocolName(String value);

	/**
	 * Returns the value of the '<em><b>Interaction Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction Type</em>' attribute.
	 * @see #setInteractionType(String)
	 * @see PIM.PIMPackage#getInteractionProtocol_InteractionType()
	 * @model
	 * @generated
	 */
	String getInteractionType();

	/**
	 * Sets the value of the '{@link PIM.InteractionProtocol#getInteractionType <em>Interaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interaction Type</em>' attribute.
	 * @see #getInteractionType()
	 * @generated
	 */
	void setInteractionType(String value);

	/**
	 * Returns the value of the '<em><b>Destinations</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.InteractionDestination}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destinations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destinations</em>' containment reference list.
	 * @see PIM.PIMPackage#getInteractionProtocol_Destinations()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<InteractionDestination> getDestinations();

} // InteractionProtocol
