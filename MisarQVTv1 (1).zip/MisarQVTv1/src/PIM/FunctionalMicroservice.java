/**
 */
package PIM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Functional Microservice</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getFunctionalMicroservice()
 * @model
 * @generated
 */
public interface FunctionalMicroservice extends Microservice {
} // FunctionalMicroservice
