/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AMQP Message Destination</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.AMQPMessageDestination#getDestinationName <em>Destination Name</em>}</li>
 *   <li>{@link PIM.AMQPMessageDestination#getDestinationType <em>Destination Type</em>}</li>
 *   <li>{@link PIM.AMQPMessageDestination#getMessage <em>Message</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getAMQPMessageDestination()
 * @model
 * @generated
 */
public interface AMQPMessageDestination extends EObject {
	/**
	 * Returns the value of the '<em><b>Destination Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destination Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination Name</em>' attribute.
	 * @see #setDestinationName(String)
	 * @see PIM.PIMPackage#getAMQPMessageDestination_DestinationName()
	 * @model
	 * @generated
	 */
	String getDestinationName();

	/**
	 * Sets the value of the '{@link PIM.AMQPMessageDestination#getDestinationName <em>Destination Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination Name</em>' attribute.
	 * @see #getDestinationName()
	 * @generated
	 */
	void setDestinationName(String value);

	/**
	 * Returns the value of the '<em><b>Destination Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destination Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination Type</em>' attribute.
	 * @see #setDestinationType(String)
	 * @see PIM.PIMPackage#getAMQPMessageDestination_DestinationType()
	 * @model
	 * @generated
	 */
	String getDestinationType();

	/**
	 * Sets the value of the '{@link PIM.AMQPMessageDestination#getDestinationType <em>Destination Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination Type</em>' attribute.
	 * @see #getDestinationType()
	 * @generated
	 */
	void setDestinationType(String value);

	/**
	 * Returns the value of the '<em><b>Message</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.Message}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Message</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Message</em>' containment reference list.
	 * @see PIM.PIMPackage#getAMQPMessageDestination_Message()
	 * @model containment="true"
	 * @generated
	 */
	EList<Message> getMessage();

} // AMQPMessageDestination
