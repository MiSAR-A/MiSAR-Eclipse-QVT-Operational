/**
 */
package PIM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see PIM.PIMFactory
 * @model kind="package"
 * @generated
 */
public interface PIMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PIM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://localhost/mdd/PIM.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "PIM";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PIMPackage eINSTANCE = PIM.impl.PIMPackageImpl.init();

	/**
	 * The meta object id for the '{@link PIM.impl.RootPIMImpl <em>Root PIM</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.RootPIMImpl
	 * @see PIM.impl.PIMPackageImpl#getRootPIM()
	 * @generated
	 */
	int ROOT_PIM = 0;

	/**
	 * The feature id for the '<em><b>Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PIM__MODEL = 0;

	/**
	 * The number of structural features of the '<em>Root PIM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PIM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Root PIM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PIM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.MicroservicesArchitectureModelImpl <em>Microservices Architecture Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.MicroservicesArchitectureModelImpl
	 * @see PIM.impl.PIMPackageImpl#getMicroservicesArchitectureModel()
	 * @generated
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL = 1;

	/**
	 * The feature id for the '<em><b>Architecture Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Static Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL = 1;

	/**
	 * The feature id for the '<em><b>Interaction Model</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL = 2;

	/**
	 * The number of structural features of the '<em>Microservices Architecture Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Microservices Architecture Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.MicroserviceArchitectureStaticModelImpl <em>Microservice Architecture Static Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.MicroserviceArchitectureStaticModelImpl
	 * @see PIM.impl.PIMPackageImpl#getMicroserviceArchitectureStaticModel()
	 * @generated
	 */
	int MICROSERVICE_ARCHITECTURE_STATIC_MODEL = 2;

	/**
	 * The feature id for the '<em><b>Containers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_ARCHITECTURE_STATIC_MODEL__CONTAINERS = 0;

	/**
	 * The number of structural features of the '<em>Microservice Architecture Static Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_ARCHITECTURE_STATIC_MODEL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Microservice Architecture Static Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_ARCHITECTURE_STATIC_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.AmbientImpl <em>Ambient</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.AmbientImpl
	 * @see PIM.impl.PIMPackageImpl#getAmbient()
	 * @generated
	 */
	int AMBIENT = 3;

	/**
	 * The number of structural features of the '<em>Ambient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Ambient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AMBIENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.ContainerImpl <em>Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.ContainerImpl
	 * @see PIM.impl.PIMPackageImpl#getContainer()
	 * @generated
	 */
	int CONTAINER = 4;

	/**
	 * The feature id for the '<em><b>Container Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__CONTAINER_NAME = AMBIENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Microservice</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__MICROSERVICE = AMBIENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER__PORTS = AMBIENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_FEATURE_COUNT = AMBIENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_OPERATION_COUNT = AMBIENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.PortImpl <em>Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.PortImpl
	 * @see PIM.impl.PIMPackageImpl#getPort()
	 * @generated
	 */
	int PORT = 5;

	/**
	 * The feature id for the '<em><b>Host Port</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__HOST_PORT = 0;

	/**
	 * The feature id for the '<em><b>Container Port</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__CONTAINER_PORT = 1;

	/**
	 * The number of structural features of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.MicroserviceImpl <em>Microservice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.MicroserviceImpl
	 * @see PIM.impl.PIMPackageImpl#getMicroservice()
	 * @generated
	 */
	int MICROSERVICE = 6;

	/**
	 * The feature id for the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE__MICROSERVICE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Microservice Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE__MICROSERVICE_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Components</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE__COMPONENTS = 2;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE__INTERFACE = 3;

	/**
	 * The number of structural features of the '<em>Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.FunctionalMicroserviceImpl <em>Functional Microservice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.FunctionalMicroserviceImpl
	 * @see PIM.impl.PIMPackageImpl#getFunctionalMicroservice()
	 * @generated
	 */
	int FUNCTIONAL_MICROSERVICE = 7;

	/**
	 * The feature id for the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE__MICROSERVICE_NAME = MICROSERVICE__MICROSERVICE_NAME;

	/**
	 * The feature id for the '<em><b>Microservice Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE__MICROSERVICE_TYPE = MICROSERVICE__MICROSERVICE_TYPE;

	/**
	 * The feature id for the '<em><b>Components</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE__COMPONENTS = MICROSERVICE__COMPONENTS;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE__INTERFACE = MICROSERVICE__INTERFACE;

	/**
	 * The number of structural features of the '<em>Functional Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE_FEATURE_COUNT = MICROSERVICE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Functional Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FUNCTIONAL_MICROSERVICE_OPERATION_COUNT = MICROSERVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.InfrastructureMicroserviceImpl <em>Infrastructure Microservice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.InfrastructureMicroserviceImpl
	 * @see PIM.impl.PIMPackageImpl#getInfrastructureMicroservice()
	 * @generated
	 */
	int INFRASTRUCTURE_MICROSERVICE = 8;

	/**
	 * The feature id for the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE__MICROSERVICE_NAME = MICROSERVICE__MICROSERVICE_NAME;

	/**
	 * The feature id for the '<em><b>Microservice Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE__MICROSERVICE_TYPE = MICROSERVICE__MICROSERVICE_TYPE;

	/**
	 * The feature id for the '<em><b>Components</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE__COMPONENTS = MICROSERVICE__COMPONENTS;

	/**
	 * The feature id for the '<em><b>Interface</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE__INTERFACE = MICROSERVICE__INTERFACE;

	/**
	 * The number of structural features of the '<em>Infrastructure Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE_FEATURE_COUNT = MICROSERVICE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Infrastructure Microservice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INFRASTRUCTURE_MICROSERVICE_OPERATION_COUNT = MICROSERVICE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.ServicePatternComponentImpl <em>Service Pattern Component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.ServicePatternComponentImpl
	 * @see PIM.impl.PIMPackageImpl#getServicePatternComponent()
	 * @generated
	 */
	int SERVICE_PATTERN_COMPONENT = 9;

	/**
	 * The feature id for the '<em><b>Pattern Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT__PATTERN_NAME = 0;

	/**
	 * The feature id for the '<em><b>Component Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE = 1;

	/**
	 * The feature id for the '<em><b>Component Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Subcomponent</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT__SUBCOMPONENT = 3;

	/**
	 * The number of structural features of the '<em>Service Pattern Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Service Pattern Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_PATTERN_COMPONENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.ServerComponentImpl <em>Server Component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.ServerComponentImpl
	 * @see PIM.impl.PIMPackageImpl#getServerComponent()
	 * @generated
	 */
	int SERVER_COMPONENT = 10;

	/**
	 * The feature id for the '<em><b>Pattern Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT__PATTERN_NAME = SERVICE_PATTERN_COMPONENT__PATTERN_NAME;

	/**
	 * The feature id for the '<em><b>Component Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT__COMPONENT_ROLE = SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE;

	/**
	 * The feature id for the '<em><b>Component Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT__COMPONENT_TYPE = SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE;

	/**
	 * The feature id for the '<em><b>Subcomponent</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT__SUBCOMPONENT = SERVICE_PATTERN_COMPONENT__SUBCOMPONENT;

	/**
	 * The number of structural features of the '<em>Server Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT_FEATURE_COUNT = SERVICE_PATTERN_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Server Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVER_COMPONENT_OPERATION_COUNT = SERVICE_PATTERN_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.ClientComponentImpl <em>Client Component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.ClientComponentImpl
	 * @see PIM.impl.PIMPackageImpl#getClientComponent()
	 * @generated
	 */
	int CLIENT_COMPONENT = 11;

	/**
	 * The feature id for the '<em><b>Pattern Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT__PATTERN_NAME = SERVICE_PATTERN_COMPONENT__PATTERN_NAME;

	/**
	 * The feature id for the '<em><b>Component Role</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT__COMPONENT_ROLE = SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE;

	/**
	 * The feature id for the '<em><b>Component Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT__COMPONENT_TYPE = SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE;

	/**
	 * The feature id for the '<em><b>Subcomponent</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT__SUBCOMPONENT = SERVICE_PATTERN_COMPONENT__SUBCOMPONENT;

	/**
	 * The number of structural features of the '<em>Client Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT_FEATURE_COUNT = SERVICE_PATTERN_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Client Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_COMPONENT_OPERATION_COUNT = SERVICE_PATTERN_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.InterfaceImpl <em>Interface</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.InterfaceImpl
	 * @see PIM.impl.PIMPackageImpl#getInterface()
	 * @generated
	 */
	int INTERFACE = 12;

	/**
	 * The feature id for the '<em><b>Protocols</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE__PROTOCOLS = 0;

	/**
	 * The number of structural features of the '<em>Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Interface</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERFACE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.InteractionProtocolImpl <em>Interaction Protocol</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.InteractionProtocolImpl
	 * @see PIM.impl.PIMPackageImpl#getInteractionProtocol()
	 * @generated
	 */
	int INTERACTION_PROTOCOL = 13;

	/**
	 * The feature id for the '<em><b>Protocol Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_PROTOCOL__PROTOCOL_NAME = 0;

	/**
	 * The feature id for the '<em><b>Interaction Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_PROTOCOL__INTERACTION_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Destinations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_PROTOCOL__DESTINATIONS = 2;

	/**
	 * The number of structural features of the '<em>Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_PROTOCOL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_PROTOCOL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.SynchronousInteractionProtocolImpl <em>Synchronous Interaction Protocol</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.SynchronousInteractionProtocolImpl
	 * @see PIM.impl.PIMPackageImpl#getSynchronousInteractionProtocol()
	 * @generated
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL = 14;

	/**
	 * The feature id for the '<em><b>Protocol Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL__PROTOCOL_NAME = INTERACTION_PROTOCOL__PROTOCOL_NAME;

	/**
	 * The feature id for the '<em><b>Interaction Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL__INTERACTION_TYPE = INTERACTION_PROTOCOL__INTERACTION_TYPE;

	/**
	 * The feature id for the '<em><b>Destinations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL__DESTINATIONS = INTERACTION_PROTOCOL__DESTINATIONS;

	/**
	 * The number of structural features of the '<em>Synchronous Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL_FEATURE_COUNT = INTERACTION_PROTOCOL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Synchronous Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYNCHRONOUS_INTERACTION_PROTOCOL_OPERATION_COUNT = INTERACTION_PROTOCOL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.AsynchronousInteractionProtocolImpl <em>Asynchronous Interaction Protocol</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.AsynchronousInteractionProtocolImpl
	 * @see PIM.impl.PIMPackageImpl#getAsynchronousInteractionProtocol()
	 * @generated
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL = 15;

	/**
	 * The feature id for the '<em><b>Protocol Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL__PROTOCOL_NAME = INTERACTION_PROTOCOL__PROTOCOL_NAME;

	/**
	 * The feature id for the '<em><b>Interaction Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL__INTERACTION_TYPE = INTERACTION_PROTOCOL__INTERACTION_TYPE;

	/**
	 * The feature id for the '<em><b>Destinations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL__DESTINATIONS = INTERACTION_PROTOCOL__DESTINATIONS;

	/**
	 * The number of structural features of the '<em>Asynchronous Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL_FEATURE_COUNT = INTERACTION_PROTOCOL_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Asynchronous Interaction Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASYNCHRONOUS_INTERACTION_PROTOCOL_OPERATION_COUNT = INTERACTION_PROTOCOL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PIM.impl.InteractionDestinationImpl <em>Interaction Destination</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.InteractionDestinationImpl
	 * @see PIM.impl.PIMPackageImpl#getInteractionDestination()
	 * @generated
	 */
	int INTERACTION_DESTINATION = 16;

	/**
	 * The feature id for the '<em><b>Destination Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_DESTINATION__DESTINATION_NAME = 0;

	/**
	 * The feature id for the '<em><b>Properties</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_DESTINATION__PROPERTIES = 1;

	/**
	 * The feature id for the '<em><b>Message</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_DESTINATION__MESSAGE = 2;

	/**
	 * The number of structural features of the '<em>Interaction Destination</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_DESTINATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Interaction Destination</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INTERACTION_DESTINATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.PropertyImpl <em>Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.PropertyImpl
	 * @see PIM.impl.PIMPackageImpl#getProperty()
	 * @generated
	 */
	int PROPERTY = 17;

	/**
	 * The feature id for the '<em><b>Property Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PROPERTY_NAME = 0;

	/**
	 * The feature id for the '<em><b>Property Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY__PROPERTY_VALUE = 1;

	/**
	 * The number of structural features of the '<em>Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPERTY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.MessageImpl <em>Message</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.MessageImpl
	 * @see PIM.impl.PIMPackageImpl#getMessage()
	 * @generated
	 */
	int MESSAGE = 18;

	/**
	 * The feature id for the '<em><b>Message Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__MESSAGE_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Body Format</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__BODY_FORMAT = 1;

	/**
	 * The feature id for the '<em><b>Format Language</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE__FORMAT_LANGUAGE = 2;

	/**
	 * The number of structural features of the '<em>Message</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Message</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MESSAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.MicroservicesArchitectureInteractionModelImpl <em>Microservices Architecture Interaction Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.MicroservicesArchitectureInteractionModelImpl
	 * @see PIM.impl.PIMPackageImpl#getMicroservicesArchitectureInteractionModel()
	 * @generated
	 */
	int MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL = 19;

	/**
	 * The feature id for the '<em><b>Architecture Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Interaction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION = 1;

	/**
	 * The number of structural features of the '<em>Microservices Architecture Interaction Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Microservices Architecture Interaction Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PIM.impl.ServiceToServiceInteractionImpl <em>Service To Service Interaction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PIM.impl.ServiceToServiceInteractionImpl
	 * @see PIM.impl.PIMPackageImpl#getServiceToServiceInteraction()
	 * @generated
	 */
	int SERVICE_TO_SERVICE_INTERACTION = 20;

	/**
	 * The feature id for the '<em><b>Consumer Microservice</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE = 0;

	/**
	 * The feature id for the '<em><b>Provider Microservice</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE = 1;

	/**
	 * The feature id for the '<em><b>Provider</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_TO_SERVICE_INTERACTION__PROVIDER = 2;

	/**
	 * The number of structural features of the '<em>Service To Service Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_TO_SERVICE_INTERACTION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Service To Service Interaction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SERVICE_TO_SERVICE_INTERACTION_OPERATION_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link PIM.RootPIM <em>Root PIM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Root PIM</em>'.
	 * @see PIM.RootPIM
	 * @generated
	 */
	EClass getRootPIM();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.RootPIM#getModel <em>Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Model</em>'.
	 * @see PIM.RootPIM#getModel()
	 * @see #getRootPIM()
	 * @generated
	 */
	EReference getRootPIM_Model();

	/**
	 * Returns the meta object for class '{@link PIM.MicroservicesArchitectureModel <em>Microservices Architecture Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservices Architecture Model</em>'.
	 * @see PIM.MicroservicesArchitectureModel
	 * @generated
	 */
	EClass getMicroservicesArchitectureModel();

	/**
	 * Returns the meta object for the attribute '{@link PIM.MicroservicesArchitectureModel#getArchitectureName <em>Architecture Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Architecture Name</em>'.
	 * @see PIM.MicroservicesArchitectureModel#getArchitectureName()
	 * @see #getMicroservicesArchitectureModel()
	 * @generated
	 */
	EAttribute getMicroservicesArchitectureModel_ArchitectureName();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.MicroservicesArchitectureModel#getStaticModel <em>Static Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Static Model</em>'.
	 * @see PIM.MicroservicesArchitectureModel#getStaticModel()
	 * @see #getMicroservicesArchitectureModel()
	 * @generated
	 */
	EReference getMicroservicesArchitectureModel_StaticModel();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.MicroservicesArchitectureModel#getInteractionModel <em>Interaction Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Interaction Model</em>'.
	 * @see PIM.MicroservicesArchitectureModel#getInteractionModel()
	 * @see #getMicroservicesArchitectureModel()
	 * @generated
	 */
	EReference getMicroservicesArchitectureModel_InteractionModel();

	/**
	 * Returns the meta object for class '{@link PIM.MicroserviceArchitectureStaticModel <em>Microservice Architecture Static Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservice Architecture Static Model</em>'.
	 * @see PIM.MicroserviceArchitectureStaticModel
	 * @generated
	 */
	EClass getMicroserviceArchitectureStaticModel();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.MicroserviceArchitectureStaticModel#getContainers <em>Containers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containers</em>'.
	 * @see PIM.MicroserviceArchitectureStaticModel#getContainers()
	 * @see #getMicroserviceArchitectureStaticModel()
	 * @generated
	 */
	EReference getMicroserviceArchitectureStaticModel_Containers();

	/**
	 * Returns the meta object for class '{@link PIM.Ambient <em>Ambient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ambient</em>'.
	 * @see PIM.Ambient
	 * @generated
	 */
	EClass getAmbient();

	/**
	 * Returns the meta object for class '{@link PIM.Container <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container</em>'.
	 * @see PIM.Container
	 * @generated
	 */
	EClass getContainer();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Container#getContainerName <em>Container Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Container Name</em>'.
	 * @see PIM.Container#getContainerName()
	 * @see #getContainer()
	 * @generated
	 */
	EAttribute getContainer_ContainerName();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.Container#getMicroservice <em>Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Microservice</em>'.
	 * @see PIM.Container#getMicroservice()
	 * @see #getContainer()
	 * @generated
	 */
	EReference getContainer_Microservice();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.Container#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ports</em>'.
	 * @see PIM.Container#getPorts()
	 * @see #getContainer()
	 * @generated
	 */
	EReference getContainer_Ports();

	/**
	 * Returns the meta object for class '{@link PIM.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port</em>'.
	 * @see PIM.Port
	 * @generated
	 */
	EClass getPort();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Port#getHostPort <em>Host Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Host Port</em>'.
	 * @see PIM.Port#getHostPort()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_HostPort();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Port#getContainerPort <em>Container Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Container Port</em>'.
	 * @see PIM.Port#getContainerPort()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_ContainerPort();

	/**
	 * Returns the meta object for class '{@link PIM.Microservice <em>Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservice</em>'.
	 * @see PIM.Microservice
	 * @generated
	 */
	EClass getMicroservice();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Microservice#getMicroserviceName <em>Microservice Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Microservice Name</em>'.
	 * @see PIM.Microservice#getMicroserviceName()
	 * @see #getMicroservice()
	 * @generated
	 */
	EAttribute getMicroservice_MicroserviceName();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Microservice#getMicroserviceType <em>Microservice Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Microservice Type</em>'.
	 * @see PIM.Microservice#getMicroserviceType()
	 * @see #getMicroservice()
	 * @generated
	 */
	EAttribute getMicroservice_MicroserviceType();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.Microservice#getComponents <em>Components</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Components</em>'.
	 * @see PIM.Microservice#getComponents()
	 * @see #getMicroservice()
	 * @generated
	 */
	EReference getMicroservice_Components();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.Microservice#getInterface <em>Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Interface</em>'.
	 * @see PIM.Microservice#getInterface()
	 * @see #getMicroservice()
	 * @generated
	 */
	EReference getMicroservice_Interface();

	/**
	 * Returns the meta object for class '{@link PIM.FunctionalMicroservice <em>Functional Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Functional Microservice</em>'.
	 * @see PIM.FunctionalMicroservice
	 * @generated
	 */
	EClass getFunctionalMicroservice();

	/**
	 * Returns the meta object for class '{@link PIM.InfrastructureMicroservice <em>Infrastructure Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Infrastructure Microservice</em>'.
	 * @see PIM.InfrastructureMicroservice
	 * @generated
	 */
	EClass getInfrastructureMicroservice();

	/**
	 * Returns the meta object for class '{@link PIM.ServicePatternComponent <em>Service Pattern Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service Pattern Component</em>'.
	 * @see PIM.ServicePatternComponent
	 * @generated
	 */
	EClass getServicePatternComponent();

	/**
	 * Returns the meta object for the attribute '{@link PIM.ServicePatternComponent#getPatternName <em>Pattern Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pattern Name</em>'.
	 * @see PIM.ServicePatternComponent#getPatternName()
	 * @see #getServicePatternComponent()
	 * @generated
	 */
	EAttribute getServicePatternComponent_PatternName();

	/**
	 * Returns the meta object for the attribute '{@link PIM.ServicePatternComponent#getComponentRole <em>Component Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Component Role</em>'.
	 * @see PIM.ServicePatternComponent#getComponentRole()
	 * @see #getServicePatternComponent()
	 * @generated
	 */
	EAttribute getServicePatternComponent_ComponentRole();

	/**
	 * Returns the meta object for the attribute '{@link PIM.ServicePatternComponent#getComponentType <em>Component Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Component Type</em>'.
	 * @see PIM.ServicePatternComponent#getComponentType()
	 * @see #getServicePatternComponent()
	 * @generated
	 */
	EAttribute getServicePatternComponent_ComponentType();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.ServicePatternComponent#getSubcomponent <em>Subcomponent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Subcomponent</em>'.
	 * @see PIM.ServicePatternComponent#getSubcomponent()
	 * @see #getServicePatternComponent()
	 * @generated
	 */
	EReference getServicePatternComponent_Subcomponent();

	/**
	 * Returns the meta object for class '{@link PIM.ServerComponent <em>Server Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Server Component</em>'.
	 * @see PIM.ServerComponent
	 * @generated
	 */
	EClass getServerComponent();

	/**
	 * Returns the meta object for class '{@link PIM.ClientComponent <em>Client Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Client Component</em>'.
	 * @see PIM.ClientComponent
	 * @generated
	 */
	EClass getClientComponent();

	/**
	 * Returns the meta object for class '{@link PIM.Interface <em>Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interface</em>'.
	 * @see PIM.Interface
	 * @generated
	 */
	EClass getInterface();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.Interface#getProtocols <em>Protocols</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Protocols</em>'.
	 * @see PIM.Interface#getProtocols()
	 * @see #getInterface()
	 * @generated
	 */
	EReference getInterface_Protocols();

	/**
	 * Returns the meta object for class '{@link PIM.InteractionProtocol <em>Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interaction Protocol</em>'.
	 * @see PIM.InteractionProtocol
	 * @generated
	 */
	EClass getInteractionProtocol();

	/**
	 * Returns the meta object for the attribute '{@link PIM.InteractionProtocol#getProtocolName <em>Protocol Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protocol Name</em>'.
	 * @see PIM.InteractionProtocol#getProtocolName()
	 * @see #getInteractionProtocol()
	 * @generated
	 */
	EAttribute getInteractionProtocol_ProtocolName();

	/**
	 * Returns the meta object for the attribute '{@link PIM.InteractionProtocol#getInteractionType <em>Interaction Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interaction Type</em>'.
	 * @see PIM.InteractionProtocol#getInteractionType()
	 * @see #getInteractionProtocol()
	 * @generated
	 */
	EAttribute getInteractionProtocol_InteractionType();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.InteractionProtocol#getDestinations <em>Destinations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Destinations</em>'.
	 * @see PIM.InteractionProtocol#getDestinations()
	 * @see #getInteractionProtocol()
	 * @generated
	 */
	EReference getInteractionProtocol_Destinations();

	/**
	 * Returns the meta object for class '{@link PIM.SynchronousInteractionProtocol <em>Synchronous Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Synchronous Interaction Protocol</em>'.
	 * @see PIM.SynchronousInteractionProtocol
	 * @generated
	 */
	EClass getSynchronousInteractionProtocol();

	/**
	 * Returns the meta object for class '{@link PIM.AsynchronousInteractionProtocol <em>Asynchronous Interaction Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Asynchronous Interaction Protocol</em>'.
	 * @see PIM.AsynchronousInteractionProtocol
	 * @generated
	 */
	EClass getAsynchronousInteractionProtocol();

	/**
	 * Returns the meta object for class '{@link PIM.InteractionDestination <em>Interaction Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Interaction Destination</em>'.
	 * @see PIM.InteractionDestination
	 * @generated
	 */
	EClass getInteractionDestination();

	/**
	 * Returns the meta object for the attribute '{@link PIM.InteractionDestination#getDestinationName <em>Destination Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Destination Name</em>'.
	 * @see PIM.InteractionDestination#getDestinationName()
	 * @see #getInteractionDestination()
	 * @generated
	 */
	EAttribute getInteractionDestination_DestinationName();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.InteractionDestination#getProperties <em>Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Properties</em>'.
	 * @see PIM.InteractionDestination#getProperties()
	 * @see #getInteractionDestination()
	 * @generated
	 */
	EReference getInteractionDestination_Properties();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.InteractionDestination#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Message</em>'.
	 * @see PIM.InteractionDestination#getMessage()
	 * @see #getInteractionDestination()
	 * @generated
	 */
	EReference getInteractionDestination_Message();

	/**
	 * Returns the meta object for class '{@link PIM.Property <em>Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Property</em>'.
	 * @see PIM.Property
	 * @generated
	 */
	EClass getProperty();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Property#getPropertyName <em>Property Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property Name</em>'.
	 * @see PIM.Property#getPropertyName()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_PropertyName();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Property#getPropertyValue <em>Property Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property Value</em>'.
	 * @see PIM.Property#getPropertyValue()
	 * @see #getProperty()
	 * @generated
	 */
	EAttribute getProperty_PropertyValue();

	/**
	 * Returns the meta object for class '{@link PIM.Message <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Message</em>'.
	 * @see PIM.Message
	 * @generated
	 */
	EClass getMessage();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Message#getMessageType <em>Message Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Message Type</em>'.
	 * @see PIM.Message#getMessageType()
	 * @see #getMessage()
	 * @generated
	 */
	EAttribute getMessage_MessageType();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Message#getBodyFormat <em>Body Format</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Body Format</em>'.
	 * @see PIM.Message#getBodyFormat()
	 * @see #getMessage()
	 * @generated
	 */
	EAttribute getMessage_BodyFormat();

	/**
	 * Returns the meta object for the attribute '{@link PIM.Message#getFormatLanguage <em>Format Language</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Format Language</em>'.
	 * @see PIM.Message#getFormatLanguage()
	 * @see #getMessage()
	 * @generated
	 */
	EAttribute getMessage_FormatLanguage();

	/**
	 * Returns the meta object for class '{@link PIM.MicroservicesArchitectureInteractionModel <em>Microservices Architecture Interaction Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservices Architecture Interaction Model</em>'.
	 * @see PIM.MicroservicesArchitectureInteractionModel
	 * @generated
	 */
	EClass getMicroservicesArchitectureInteractionModel();

	/**
	 * Returns the meta object for the attribute '{@link PIM.MicroservicesArchitectureInteractionModel#getArchitectureName <em>Architecture Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Architecture Name</em>'.
	 * @see PIM.MicroservicesArchitectureInteractionModel#getArchitectureName()
	 * @see #getMicroservicesArchitectureInteractionModel()
	 * @generated
	 */
	EAttribute getMicroservicesArchitectureInteractionModel_ArchitectureName();

	/**
	 * Returns the meta object for the containment reference list '{@link PIM.MicroservicesArchitectureInteractionModel#getInteraction <em>Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Interaction</em>'.
	 * @see PIM.MicroservicesArchitectureInteractionModel#getInteraction()
	 * @see #getMicroservicesArchitectureInteractionModel()
	 * @generated
	 */
	EReference getMicroservicesArchitectureInteractionModel_Interaction();

	/**
	 * Returns the meta object for class '{@link PIM.ServiceToServiceInteraction <em>Service To Service Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Service To Service Interaction</em>'.
	 * @see PIM.ServiceToServiceInteraction
	 * @generated
	 */
	EClass getServiceToServiceInteraction();

	/**
	 * Returns the meta object for the attribute '{@link PIM.ServiceToServiceInteraction#getConsumerMicroservice <em>Consumer Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Consumer Microservice</em>'.
	 * @see PIM.ServiceToServiceInteraction#getConsumerMicroservice()
	 * @see #getServiceToServiceInteraction()
	 * @generated
	 */
	EAttribute getServiceToServiceInteraction_ConsumerMicroservice();

	/**
	 * Returns the meta object for the attribute '{@link PIM.ServiceToServiceInteraction#getProviderMicroservice <em>Provider Microservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Provider Microservice</em>'.
	 * @see PIM.ServiceToServiceInteraction#getProviderMicroservice()
	 * @see #getServiceToServiceInteraction()
	 * @generated
	 */
	EAttribute getServiceToServiceInteraction_ProviderMicroservice();

	/**
	 * Returns the meta object for the containment reference '{@link PIM.ServiceToServiceInteraction#getProvider <em>Provider</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Provider</em>'.
	 * @see PIM.ServiceToServiceInteraction#getProvider()
	 * @see #getServiceToServiceInteraction()
	 * @generated
	 */
	EReference getServiceToServiceInteraction_Provider();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PIMFactory getPIMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link PIM.impl.RootPIMImpl <em>Root PIM</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.RootPIMImpl
		 * @see PIM.impl.PIMPackageImpl#getRootPIM()
		 * @generated
		 */
		EClass ROOT_PIM = eINSTANCE.getRootPIM();

		/**
		 * The meta object literal for the '<em><b>Model</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOT_PIM__MODEL = eINSTANCE.getRootPIM_Model();

		/**
		 * The meta object literal for the '{@link PIM.impl.MicroservicesArchitectureModelImpl <em>Microservices Architecture Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.MicroservicesArchitectureModelImpl
		 * @see PIM.impl.PIMPackageImpl#getMicroservicesArchitectureModel()
		 * @generated
		 */
		EClass MICROSERVICES_ARCHITECTURE_MODEL = eINSTANCE.getMicroservicesArchitectureModel();

		/**
		 * The meta object literal for the '<em><b>Architecture Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME = eINSTANCE.getMicroservicesArchitectureModel_ArchitectureName();

		/**
		 * The meta object literal for the '<em><b>Static Model</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL = eINSTANCE.getMicroservicesArchitectureModel_StaticModel();

		/**
		 * The meta object literal for the '<em><b>Interaction Model</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL = eINSTANCE.getMicroservicesArchitectureModel_InteractionModel();

		/**
		 * The meta object literal for the '{@link PIM.impl.MicroserviceArchitectureStaticModelImpl <em>Microservice Architecture Static Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.MicroserviceArchitectureStaticModelImpl
		 * @see PIM.impl.PIMPackageImpl#getMicroserviceArchitectureStaticModel()
		 * @generated
		 */
		EClass MICROSERVICE_ARCHITECTURE_STATIC_MODEL = eINSTANCE.getMicroserviceArchitectureStaticModel();

		/**
		 * The meta object literal for the '<em><b>Containers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_ARCHITECTURE_STATIC_MODEL__CONTAINERS = eINSTANCE.getMicroserviceArchitectureStaticModel_Containers();

		/**
		 * The meta object literal for the '{@link PIM.impl.AmbientImpl <em>Ambient</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.AmbientImpl
		 * @see PIM.impl.PIMPackageImpl#getAmbient()
		 * @generated
		 */
		EClass AMBIENT = eINSTANCE.getAmbient();

		/**
		 * The meta object literal for the '{@link PIM.impl.ContainerImpl <em>Container</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.ContainerImpl
		 * @see PIM.impl.PIMPackageImpl#getContainer()
		 * @generated
		 */
		EClass CONTAINER = eINSTANCE.getContainer();

		/**
		 * The meta object literal for the '<em><b>Container Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER__CONTAINER_NAME = eINSTANCE.getContainer_ContainerName();

		/**
		 * The meta object literal for the '<em><b>Microservice</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER__MICROSERVICE = eINSTANCE.getContainer_Microservice();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER__PORTS = eINSTANCE.getContainer_Ports();

		/**
		 * The meta object literal for the '{@link PIM.impl.PortImpl <em>Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.PortImpl
		 * @see PIM.impl.PIMPackageImpl#getPort()
		 * @generated
		 */
		EClass PORT = eINSTANCE.getPort();

		/**
		 * The meta object literal for the '<em><b>Host Port</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__HOST_PORT = eINSTANCE.getPort_HostPort();

		/**
		 * The meta object literal for the '<em><b>Container Port</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__CONTAINER_PORT = eINSTANCE.getPort_ContainerPort();

		/**
		 * The meta object literal for the '{@link PIM.impl.MicroserviceImpl <em>Microservice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.MicroserviceImpl
		 * @see PIM.impl.PIMPackageImpl#getMicroservice()
		 * @generated
		 */
		EClass MICROSERVICE = eINSTANCE.getMicroservice();

		/**
		 * The meta object literal for the '<em><b>Microservice Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE__MICROSERVICE_NAME = eINSTANCE.getMicroservice_MicroserviceName();

		/**
		 * The meta object literal for the '<em><b>Microservice Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE__MICROSERVICE_TYPE = eINSTANCE.getMicroservice_MicroserviceType();

		/**
		 * The meta object literal for the '<em><b>Components</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE__COMPONENTS = eINSTANCE.getMicroservice_Components();

		/**
		 * The meta object literal for the '<em><b>Interface</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE__INTERFACE = eINSTANCE.getMicroservice_Interface();

		/**
		 * The meta object literal for the '{@link PIM.impl.FunctionalMicroserviceImpl <em>Functional Microservice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.FunctionalMicroserviceImpl
		 * @see PIM.impl.PIMPackageImpl#getFunctionalMicroservice()
		 * @generated
		 */
		EClass FUNCTIONAL_MICROSERVICE = eINSTANCE.getFunctionalMicroservice();

		/**
		 * The meta object literal for the '{@link PIM.impl.InfrastructureMicroserviceImpl <em>Infrastructure Microservice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.InfrastructureMicroserviceImpl
		 * @see PIM.impl.PIMPackageImpl#getInfrastructureMicroservice()
		 * @generated
		 */
		EClass INFRASTRUCTURE_MICROSERVICE = eINSTANCE.getInfrastructureMicroservice();

		/**
		 * The meta object literal for the '{@link PIM.impl.ServicePatternComponentImpl <em>Service Pattern Component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.ServicePatternComponentImpl
		 * @see PIM.impl.PIMPackageImpl#getServicePatternComponent()
		 * @generated
		 */
		EClass SERVICE_PATTERN_COMPONENT = eINSTANCE.getServicePatternComponent();

		/**
		 * The meta object literal for the '<em><b>Pattern Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_PATTERN_COMPONENT__PATTERN_NAME = eINSTANCE.getServicePatternComponent_PatternName();

		/**
		 * The meta object literal for the '<em><b>Component Role</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE = eINSTANCE.getServicePatternComponent_ComponentRole();

		/**
		 * The meta object literal for the '<em><b>Component Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE = eINSTANCE.getServicePatternComponent_ComponentType();

		/**
		 * The meta object literal for the '<em><b>Subcomponent</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE_PATTERN_COMPONENT__SUBCOMPONENT = eINSTANCE.getServicePatternComponent_Subcomponent();

		/**
		 * The meta object literal for the '{@link PIM.impl.ServerComponentImpl <em>Server Component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.ServerComponentImpl
		 * @see PIM.impl.PIMPackageImpl#getServerComponent()
		 * @generated
		 */
		EClass SERVER_COMPONENT = eINSTANCE.getServerComponent();

		/**
		 * The meta object literal for the '{@link PIM.impl.ClientComponentImpl <em>Client Component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.ClientComponentImpl
		 * @see PIM.impl.PIMPackageImpl#getClientComponent()
		 * @generated
		 */
		EClass CLIENT_COMPONENT = eINSTANCE.getClientComponent();

		/**
		 * The meta object literal for the '{@link PIM.impl.InterfaceImpl <em>Interface</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.InterfaceImpl
		 * @see PIM.impl.PIMPackageImpl#getInterface()
		 * @generated
		 */
		EClass INTERFACE = eINSTANCE.getInterface();

		/**
		 * The meta object literal for the '<em><b>Protocols</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERFACE__PROTOCOLS = eINSTANCE.getInterface_Protocols();

		/**
		 * The meta object literal for the '{@link PIM.impl.InteractionProtocolImpl <em>Interaction Protocol</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.InteractionProtocolImpl
		 * @see PIM.impl.PIMPackageImpl#getInteractionProtocol()
		 * @generated
		 */
		EClass INTERACTION_PROTOCOL = eINSTANCE.getInteractionProtocol();

		/**
		 * The meta object literal for the '<em><b>Protocol Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_PROTOCOL__PROTOCOL_NAME = eINSTANCE.getInteractionProtocol_ProtocolName();

		/**
		 * The meta object literal for the '<em><b>Interaction Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_PROTOCOL__INTERACTION_TYPE = eINSTANCE.getInteractionProtocol_InteractionType();

		/**
		 * The meta object literal for the '<em><b>Destinations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_PROTOCOL__DESTINATIONS = eINSTANCE.getInteractionProtocol_Destinations();

		/**
		 * The meta object literal for the '{@link PIM.impl.SynchronousInteractionProtocolImpl <em>Synchronous Interaction Protocol</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.SynchronousInteractionProtocolImpl
		 * @see PIM.impl.PIMPackageImpl#getSynchronousInteractionProtocol()
		 * @generated
		 */
		EClass SYNCHRONOUS_INTERACTION_PROTOCOL = eINSTANCE.getSynchronousInteractionProtocol();

		/**
		 * The meta object literal for the '{@link PIM.impl.AsynchronousInteractionProtocolImpl <em>Asynchronous Interaction Protocol</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.AsynchronousInteractionProtocolImpl
		 * @see PIM.impl.PIMPackageImpl#getAsynchronousInteractionProtocol()
		 * @generated
		 */
		EClass ASYNCHRONOUS_INTERACTION_PROTOCOL = eINSTANCE.getAsynchronousInteractionProtocol();

		/**
		 * The meta object literal for the '{@link PIM.impl.InteractionDestinationImpl <em>Interaction Destination</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.InteractionDestinationImpl
		 * @see PIM.impl.PIMPackageImpl#getInteractionDestination()
		 * @generated
		 */
		EClass INTERACTION_DESTINATION = eINSTANCE.getInteractionDestination();

		/**
		 * The meta object literal for the '<em><b>Destination Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INTERACTION_DESTINATION__DESTINATION_NAME = eINSTANCE.getInteractionDestination_DestinationName();

		/**
		 * The meta object literal for the '<em><b>Properties</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_DESTINATION__PROPERTIES = eINSTANCE.getInteractionDestination_Properties();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INTERACTION_DESTINATION__MESSAGE = eINSTANCE.getInteractionDestination_Message();

		/**
		 * The meta object literal for the '{@link PIM.impl.PropertyImpl <em>Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.PropertyImpl
		 * @see PIM.impl.PIMPackageImpl#getProperty()
		 * @generated
		 */
		EClass PROPERTY = eINSTANCE.getProperty();

		/**
		 * The meta object literal for the '<em><b>Property Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__PROPERTY_NAME = eINSTANCE.getProperty_PropertyName();

		/**
		 * The meta object literal for the '<em><b>Property Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPERTY__PROPERTY_VALUE = eINSTANCE.getProperty_PropertyValue();

		/**
		 * The meta object literal for the '{@link PIM.impl.MessageImpl <em>Message</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.MessageImpl
		 * @see PIM.impl.PIMPackageImpl#getMessage()
		 * @generated
		 */
		EClass MESSAGE = eINSTANCE.getMessage();

		/**
		 * The meta object literal for the '<em><b>Message Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESSAGE__MESSAGE_TYPE = eINSTANCE.getMessage_MessageType();

		/**
		 * The meta object literal for the '<em><b>Body Format</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESSAGE__BODY_FORMAT = eINSTANCE.getMessage_BodyFormat();

		/**
		 * The meta object literal for the '<em><b>Format Language</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MESSAGE__FORMAT_LANGUAGE = eINSTANCE.getMessage_FormatLanguage();

		/**
		 * The meta object literal for the '{@link PIM.impl.MicroservicesArchitectureInteractionModelImpl <em>Microservices Architecture Interaction Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.MicroservicesArchitectureInteractionModelImpl
		 * @see PIM.impl.PIMPackageImpl#getMicroservicesArchitectureInteractionModel()
		 * @generated
		 */
		EClass MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL = eINSTANCE.getMicroservicesArchitectureInteractionModel();

		/**
		 * The meta object literal for the '<em><b>Architecture Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME = eINSTANCE.getMicroservicesArchitectureInteractionModel_ArchitectureName();

		/**
		 * The meta object literal for the '<em><b>Interaction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION = eINSTANCE.getMicroservicesArchitectureInteractionModel_Interaction();

		/**
		 * The meta object literal for the '{@link PIM.impl.ServiceToServiceInteractionImpl <em>Service To Service Interaction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PIM.impl.ServiceToServiceInteractionImpl
		 * @see PIM.impl.PIMPackageImpl#getServiceToServiceInteraction()
		 * @generated
		 */
		EClass SERVICE_TO_SERVICE_INTERACTION = eINSTANCE.getServiceToServiceInteraction();

		/**
		 * The meta object literal for the '<em><b>Consumer Microservice</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE = eINSTANCE.getServiceToServiceInteraction_ConsumerMicroservice();

		/**
		 * The meta object literal for the '<em><b>Provider Microservice</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE = eINSTANCE.getServiceToServiceInteraction_ProviderMicroservice();

		/**
		 * The meta object literal for the '<em><b>Provider</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SERVICE_TO_SERVICE_INTERACTION__PROVIDER = eINSTANCE.getServiceToServiceInteraction_Provider();

	}

} //PIMPackage
