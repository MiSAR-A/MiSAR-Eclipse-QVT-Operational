/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservices Architecture Interaction Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.MicroservicesArchitectureInteractionModel#getArchitectureName <em>Architecture Name</em>}</li>
 *   <li>{@link PIM.MicroservicesArchitectureInteractionModel#getInteraction <em>Interaction</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getMicroservicesArchitectureInteractionModel()
 * @model
 * @generated
 */
public interface MicroservicesArchitectureInteractionModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Architecture Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Architecture Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Architecture Name</em>' attribute.
	 * @see #setArchitectureName(String)
	 * @see PIM.PIMPackage#getMicroservicesArchitectureInteractionModel_ArchitectureName()
	 * @model
	 * @generated
	 */
	String getArchitectureName();

	/**
	 * Sets the value of the '{@link PIM.MicroservicesArchitectureInteractionModel#getArchitectureName <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Architecture Name</em>' attribute.
	 * @see #getArchitectureName()
	 * @generated
	 */
	void setArchitectureName(String value);

	/**
	 * Returns the value of the '<em><b>Interaction</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.ServiceToServiceInteraction}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interaction</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction</em>' containment reference list.
	 * @see PIM.PIMPackage#getMicroservicesArchitectureInteractionModel_Interaction()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<ServiceToServiceInteraction> getInteraction();

} // MicroservicesArchitectureInteractionModel
