/**
 */
package PIM;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Asynchronous Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getAsynchronousInteractionProtocol()
 * @model
 * @generated
 */
public interface AsynchronousInteractionProtocol extends InteractionProtocol {

} // AsynchronousInteractionProtocol
