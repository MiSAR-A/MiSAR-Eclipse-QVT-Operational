/**
 */
package PIM.impl;

import PIM.Message;
import PIM.PIMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Message</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.MessageImpl#getMessageType <em>Message Type</em>}</li>
 *   <li>{@link PIM.impl.MessageImpl#getBodyFormat <em>Body Format</em>}</li>
 *   <li>{@link PIM.impl.MessageImpl#getFormatLanguage <em>Format Language</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MessageImpl extends MinimalEObjectImpl.Container implements Message {
	/**
	 * The default value of the '{@link #getMessageType() <em>Message Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMessageType()
	 * @generated
	 * @ordered
	 */
	protected static final String MESSAGE_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMessageType() <em>Message Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMessageType()
	 * @generated
	 * @ordered
	 */
	protected String messageType = MESSAGE_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getBodyFormat() <em>Body Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBodyFormat()
	 * @generated
	 * @ordered
	 */
	protected static final String BODY_FORMAT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBodyFormat() <em>Body Format</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBodyFormat()
	 * @generated
	 * @ordered
	 */
	protected String bodyFormat = BODY_FORMAT_EDEFAULT;

	/**
	 * The default value of the '{@link #getFormatLanguage() <em>Format Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFormatLanguage()
	 * @generated
	 * @ordered
	 */
	protected static final String FORMAT_LANGUAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFormatLanguage() <em>Format Language</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFormatLanguage()
	 * @generated
	 * @ordered
	 */
	protected String formatLanguage = FORMAT_LANGUAGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MessageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.MESSAGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMessageType(String newMessageType) {
		String oldMessageType = messageType;
		messageType = newMessageType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MESSAGE__MESSAGE_TYPE, oldMessageType, messageType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBodyFormat() {
		return bodyFormat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBodyFormat(String newBodyFormat) {
		String oldBodyFormat = bodyFormat;
		bodyFormat = newBodyFormat;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MESSAGE__BODY_FORMAT, oldBodyFormat, bodyFormat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFormatLanguage() {
		return formatLanguage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFormatLanguage(String newFormatLanguage) {
		String oldFormatLanguage = formatLanguage;
		formatLanguage = newFormatLanguage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MESSAGE__FORMAT_LANGUAGE, oldFormatLanguage, formatLanguage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.MESSAGE__MESSAGE_TYPE:
				return getMessageType();
			case PIMPackage.MESSAGE__BODY_FORMAT:
				return getBodyFormat();
			case PIMPackage.MESSAGE__FORMAT_LANGUAGE:
				return getFormatLanguage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.MESSAGE__MESSAGE_TYPE:
				setMessageType((String)newValue);
				return;
			case PIMPackage.MESSAGE__BODY_FORMAT:
				setBodyFormat((String)newValue);
				return;
			case PIMPackage.MESSAGE__FORMAT_LANGUAGE:
				setFormatLanguage((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.MESSAGE__MESSAGE_TYPE:
				setMessageType(MESSAGE_TYPE_EDEFAULT);
				return;
			case PIMPackage.MESSAGE__BODY_FORMAT:
				setBodyFormat(BODY_FORMAT_EDEFAULT);
				return;
			case PIMPackage.MESSAGE__FORMAT_LANGUAGE:
				setFormatLanguage(FORMAT_LANGUAGE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.MESSAGE__MESSAGE_TYPE:
				return MESSAGE_TYPE_EDEFAULT == null ? messageType != null : !MESSAGE_TYPE_EDEFAULT.equals(messageType);
			case PIMPackage.MESSAGE__BODY_FORMAT:
				return BODY_FORMAT_EDEFAULT == null ? bodyFormat != null : !BODY_FORMAT_EDEFAULT.equals(bodyFormat);
			case PIMPackage.MESSAGE__FORMAT_LANGUAGE:
				return FORMAT_LANGUAGE_EDEFAULT == null ? formatLanguage != null : !FORMAT_LANGUAGE_EDEFAULT.equals(formatLanguage);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (MessageType: ");
		result.append(messageType);
		result.append(", BodyFormat: ");
		result.append(bodyFormat);
		result.append(", FormatLanguage: ");
		result.append(formatLanguage);
		result.append(')');
		return result.toString();
	}

} //MessageImpl
