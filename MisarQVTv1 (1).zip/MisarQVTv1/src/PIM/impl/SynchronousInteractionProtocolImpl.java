/**
 */
package PIM.impl;

import PIM.PIMPackage;
import PIM.SynchronousInteractionProtocol;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Synchronous Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SynchronousInteractionProtocolImpl extends InteractionProtocolImpl implements SynchronousInteractionProtocol {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SynchronousInteractionProtocolImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.SYNCHRONOUS_INTERACTION_PROTOCOL;
	}

} //SynchronousInteractionProtocolImpl
