/**
 */
package PIM.impl;

import PIM.InteractionDestination;
import PIM.InteractionProtocol;
import PIM.PIMPackage;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.InteractionProtocolImpl#getProtocolName <em>Protocol Name</em>}</li>
 *   <li>{@link PIM.impl.InteractionProtocolImpl#getInteractionType <em>Interaction Type</em>}</li>
 *   <li>{@link PIM.impl.InteractionProtocolImpl#getDestinations <em>Destinations</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InteractionProtocolImpl extends MinimalEObjectImpl.Container implements InteractionProtocol {
	/**
	 * The default value of the '{@link #getProtocolName() <em>Protocol Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocolName()
	 * @generated
	 * @ordered
	 */
	protected static final String PROTOCOL_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProtocolName() <em>Protocol Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocolName()
	 * @generated
	 * @ordered
	 */
	protected String protocolName = PROTOCOL_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getInteractionType() <em>Interaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteractionType()
	 * @generated
	 * @ordered
	 */
	protected static final String INTERACTION_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInteractionType() <em>Interaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteractionType()
	 * @generated
	 * @ordered
	 */
	protected String interactionType = INTERACTION_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDestinations() <em>Destinations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDestinations()
	 * @generated
	 * @ordered
	 */
	protected EList<InteractionDestination> destinations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InteractionProtocolImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.INTERACTION_PROTOCOL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProtocolName() {
		return protocolName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocolName(String newProtocolName) {
		String oldProtocolName = protocolName;
		protocolName = newProtocolName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.INTERACTION_PROTOCOL__PROTOCOL_NAME, oldProtocolName, protocolName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInteractionType() {
		return interactionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInteractionType(String newInteractionType) {
		String oldInteractionType = interactionType;
		interactionType = newInteractionType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.INTERACTION_PROTOCOL__INTERACTION_TYPE, oldInteractionType, interactionType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<InteractionDestination> getDestinations() {
		if (destinations == null) {
			destinations = new EObjectContainmentEList<InteractionDestination>(InteractionDestination.class, this, PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS);
		}
		return destinations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS:
				return ((InternalEList<?>)getDestinations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.INTERACTION_PROTOCOL__PROTOCOL_NAME:
				return getProtocolName();
			case PIMPackage.INTERACTION_PROTOCOL__INTERACTION_TYPE:
				return getInteractionType();
			case PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS:
				return getDestinations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.INTERACTION_PROTOCOL__PROTOCOL_NAME:
				setProtocolName((String)newValue);
				return;
			case PIMPackage.INTERACTION_PROTOCOL__INTERACTION_TYPE:
				setInteractionType((String)newValue);
				return;
			case PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS:
				getDestinations().clear();
				getDestinations().addAll((Collection<? extends InteractionDestination>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.INTERACTION_PROTOCOL__PROTOCOL_NAME:
				setProtocolName(PROTOCOL_NAME_EDEFAULT);
				return;
			case PIMPackage.INTERACTION_PROTOCOL__INTERACTION_TYPE:
				setInteractionType(INTERACTION_TYPE_EDEFAULT);
				return;
			case PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS:
				getDestinations().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.INTERACTION_PROTOCOL__PROTOCOL_NAME:
				return PROTOCOL_NAME_EDEFAULT == null ? protocolName != null : !PROTOCOL_NAME_EDEFAULT.equals(protocolName);
			case PIMPackage.INTERACTION_PROTOCOL__INTERACTION_TYPE:
				return INTERACTION_TYPE_EDEFAULT == null ? interactionType != null : !INTERACTION_TYPE_EDEFAULT.equals(interactionType);
			case PIMPackage.INTERACTION_PROTOCOL__DESTINATIONS:
				return destinations != null && !destinations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ProtocolName: ");
		result.append(protocolName);
		result.append(", InteractionType: ");
		result.append(interactionType);
		result.append(')');
		return result.toString();
	}

} //InteractionProtocolImpl
