/**
 */
package PIM.impl;

import PIM.FunctionalMicroservice;
import PIM.PIMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Functional Microservice</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FunctionalMicroserviceImpl extends MicroserviceImpl implements FunctionalMicroservice {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FunctionalMicroserviceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.FUNCTIONAL_MICROSERVICE;
	}

} //FunctionalMicroserviceImpl
