/**
 */
package PIM.impl;

import PIM.PIMPackage;
import PIM.ServicePatternComponent;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service Pattern Component</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.ServicePatternComponentImpl#getPatternName <em>Pattern Name</em>}</li>
 *   <li>{@link PIM.impl.ServicePatternComponentImpl#getComponentRole <em>Component Role</em>}</li>
 *   <li>{@link PIM.impl.ServicePatternComponentImpl#getComponentType <em>Component Type</em>}</li>
 *   <li>{@link PIM.impl.ServicePatternComponentImpl#getSubcomponent <em>Subcomponent</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ServicePatternComponentImpl extends MinimalEObjectImpl.Container implements ServicePatternComponent {
	/**
	 * The default value of the '{@link #getPatternName() <em>Pattern Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatternName()
	 * @generated
	 * @ordered
	 */
	protected static final String PATTERN_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPatternName() <em>Pattern Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatternName()
	 * @generated
	 * @ordered
	 */
	protected String patternName = PATTERN_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getComponentRole() <em>Component Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponentRole()
	 * @generated
	 * @ordered
	 */
	protected static final String COMPONENT_ROLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getComponentRole() <em>Component Role</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponentRole()
	 * @generated
	 * @ordered
	 */
	protected String componentRole = COMPONENT_ROLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getComponentType() <em>Component Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponentType()
	 * @generated
	 * @ordered
	 */
	protected static final String COMPONENT_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getComponentType() <em>Component Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponentType()
	 * @generated
	 * @ordered
	 */
	protected String componentType = COMPONENT_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSubcomponent() <em>Subcomponent</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcomponent()
	 * @generated
	 * @ordered
	 */
	protected EList<ServicePatternComponent> subcomponent;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServicePatternComponentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.SERVICE_PATTERN_COMPONENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPatternName() {
		return patternName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatternName(String newPatternName) {
		String oldPatternName = patternName;
		patternName = newPatternName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_PATTERN_COMPONENT__PATTERN_NAME, oldPatternName, patternName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getComponentRole() {
		return componentRole;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setComponentRole(String newComponentRole) {
		String oldComponentRole = componentRole;
		componentRole = newComponentRole;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE, oldComponentRole, componentRole));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getComponentType() {
		return componentType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setComponentType(String newComponentType) {
		String oldComponentType = componentType;
		componentType = newComponentType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE, oldComponentType, componentType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ServicePatternComponent> getSubcomponent() {
		if (subcomponent == null) {
			subcomponent = new EObjectContainmentEList<ServicePatternComponent>(ServicePatternComponent.class, this, PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT);
		}
		return subcomponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT:
				return ((InternalEList<?>)getSubcomponent()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.SERVICE_PATTERN_COMPONENT__PATTERN_NAME:
				return getPatternName();
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE:
				return getComponentRole();
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE:
				return getComponentType();
			case PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT:
				return getSubcomponent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.SERVICE_PATTERN_COMPONENT__PATTERN_NAME:
				setPatternName((String)newValue);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE:
				setComponentRole((String)newValue);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE:
				setComponentType((String)newValue);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT:
				getSubcomponent().clear();
				getSubcomponent().addAll((Collection<? extends ServicePatternComponent>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.SERVICE_PATTERN_COMPONENT__PATTERN_NAME:
				setPatternName(PATTERN_NAME_EDEFAULT);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE:
				setComponentRole(COMPONENT_ROLE_EDEFAULT);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE:
				setComponentType(COMPONENT_TYPE_EDEFAULT);
				return;
			case PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT:
				getSubcomponent().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.SERVICE_PATTERN_COMPONENT__PATTERN_NAME:
				return PATTERN_NAME_EDEFAULT == null ? patternName != null : !PATTERN_NAME_EDEFAULT.equals(patternName);
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE:
				return COMPONENT_ROLE_EDEFAULT == null ? componentRole != null : !COMPONENT_ROLE_EDEFAULT.equals(componentRole);
			case PIMPackage.SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE:
				return COMPONENT_TYPE_EDEFAULT == null ? componentType != null : !COMPONENT_TYPE_EDEFAULT.equals(componentType);
			case PIMPackage.SERVICE_PATTERN_COMPONENT__SUBCOMPONENT:
				return subcomponent != null && !subcomponent.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (PatternName: ");
		result.append(patternName);
		result.append(", ComponentRole: ");
		result.append(componentRole);
		result.append(", ComponentType: ");
		result.append(componentType);
		result.append(')');
		return result.toString();
	}

} //ServicePatternComponentImpl
