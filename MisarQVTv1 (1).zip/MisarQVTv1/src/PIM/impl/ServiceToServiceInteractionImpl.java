/**
 */
package PIM.impl;

import PIM.Interface;
import PIM.PIMPackage;
import PIM.ServiceToServiceInteraction;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Service To Service Interaction</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.ServiceToServiceInteractionImpl#getConsumerMicroservice <em>Consumer Microservice</em>}</li>
 *   <li>{@link PIM.impl.ServiceToServiceInteractionImpl#getProviderMicroservice <em>Provider Microservice</em>}</li>
 *   <li>{@link PIM.impl.ServiceToServiceInteractionImpl#getProvider <em>Provider</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ServiceToServiceInteractionImpl extends MinimalEObjectImpl.Container implements ServiceToServiceInteraction {
	/**
	 * The default value of the '{@link #getConsumerMicroservice() <em>Consumer Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsumerMicroservice()
	 * @generated
	 * @ordered
	 */
	protected static final String CONSUMER_MICROSERVICE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConsumerMicroservice() <em>Consumer Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsumerMicroservice()
	 * @generated
	 * @ordered
	 */
	protected String consumerMicroservice = CONSUMER_MICROSERVICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getProviderMicroservice() <em>Provider Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProviderMicroservice()
	 * @generated
	 * @ordered
	 */
	protected static final String PROVIDER_MICROSERVICE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProviderMicroservice() <em>Provider Microservice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProviderMicroservice()
	 * @generated
	 * @ordered
	 */
	protected String providerMicroservice = PROVIDER_MICROSERVICE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProvider() <em>Provider</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProvider()
	 * @generated
	 * @ordered
	 */
	protected Interface provider;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServiceToServiceInteractionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.SERVICE_TO_SERVICE_INTERACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConsumerMicroservice() {
		return consumerMicroservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConsumerMicroservice(String newConsumerMicroservice) {
		String oldConsumerMicroservice = consumerMicroservice;
		consumerMicroservice = newConsumerMicroservice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE, oldConsumerMicroservice, consumerMicroservice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProviderMicroservice() {
		return providerMicroservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProviderMicroservice(String newProviderMicroservice) {
		String oldProviderMicroservice = providerMicroservice;
		providerMicroservice = newProviderMicroservice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE, oldProviderMicroservice, providerMicroservice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Interface getProvider() {
		return provider;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProvider(Interface newProvider, NotificationChain msgs) {
		Interface oldProvider = provider;
		provider = newProvider;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER, oldProvider, newProvider);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProvider(Interface newProvider) {
		if (newProvider != provider) {
			NotificationChain msgs = null;
			if (provider != null)
				msgs = ((InternalEObject)provider).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER, null, msgs);
			if (newProvider != null)
				msgs = ((InternalEObject)newProvider).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER, null, msgs);
			msgs = basicSetProvider(newProvider, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER, newProvider, newProvider));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER:
				return basicSetProvider(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE:
				return getConsumerMicroservice();
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE:
				return getProviderMicroservice();
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER:
				return getProvider();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE:
				setConsumerMicroservice((String)newValue);
				return;
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE:
				setProviderMicroservice((String)newValue);
				return;
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER:
				setProvider((Interface)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE:
				setConsumerMicroservice(CONSUMER_MICROSERVICE_EDEFAULT);
				return;
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE:
				setProviderMicroservice(PROVIDER_MICROSERVICE_EDEFAULT);
				return;
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER:
				setProvider((Interface)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE:
				return CONSUMER_MICROSERVICE_EDEFAULT == null ? consumerMicroservice != null : !CONSUMER_MICROSERVICE_EDEFAULT.equals(consumerMicroservice);
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE:
				return PROVIDER_MICROSERVICE_EDEFAULT == null ? providerMicroservice != null : !PROVIDER_MICROSERVICE_EDEFAULT.equals(providerMicroservice);
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION__PROVIDER:
				return provider != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ConsumerMicroservice: ");
		result.append(consumerMicroservice);
		result.append(", ProviderMicroservice: ");
		result.append(providerMicroservice);
		result.append(')');
		return result.toString();
	}

} //ServiceToServiceInteractionImpl
