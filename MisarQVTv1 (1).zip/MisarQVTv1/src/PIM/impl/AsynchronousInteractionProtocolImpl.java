/**
 */
package PIM.impl;

import PIM.AsynchronousInteractionProtocol;
import PIM.PIMPackage;
import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Asynchronous Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AsynchronousInteractionProtocolImpl extends InteractionProtocolImpl implements AsynchronousInteractionProtocol {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AsynchronousInteractionProtocolImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.ASYNCHRONOUS_INTERACTION_PROTOCOL;
	}

} //AsynchronousInteractionProtocolImpl
