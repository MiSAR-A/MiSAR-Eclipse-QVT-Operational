/**
 */
package PIM.impl;

import PIM.Ambient;
import PIM.AsynchronousInteractionProtocol;
import PIM.ClientComponent;
import PIM.FunctionalMicroservice;
import PIM.InfrastructureMicroservice;
import PIM.InteractionDestination;
import PIM.InteractionProtocol;
import PIM.Interface;
import PIM.Message;
import PIM.Microservice;
import PIM.MicroserviceArchitectureStaticModel;
import PIM.MicroservicesArchitectureInteractionModel;
import PIM.MicroservicesArchitectureModel;
import PIM.PIMFactory;
import PIM.PIMPackage;
import PIM.Port;
import PIM.Property;
import PIM.RootPIM;
import PIM.ServerComponent;
import PIM.ServicePatternComponent;
import PIM.ServiceToServiceInteraction;
import PIM.SynchronousInteractionProtocol;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PIMPackageImpl extends EPackageImpl implements PIMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rootPIMEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microservicesArchitectureModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microserviceArchitectureStaticModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ambientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microserviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass functionalMicroserviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass infrastructureMicroserviceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass servicePatternComponentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serverComponentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clientComponentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interfaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interactionProtocolEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass synchronousInteractionProtocolEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass asynchronousInteractionProtocolEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass interactionDestinationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass propertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass messageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microservicesArchitectureInteractionModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass serviceToServiceInteractionEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see PIM.PIMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PIMPackageImpl() {
		super(eNS_URI, PIMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link PIMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PIMPackage init() {
		if (isInited) return (PIMPackage)EPackage.Registry.INSTANCE.getEPackage(PIMPackage.eNS_URI);

		// Obtain or create and register package
		PIMPackageImpl thePIMPackage = (PIMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof PIMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new PIMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		thePIMPackage.createPackageContents();

		// Initialize created meta-data
		thePIMPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		thePIMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(PIMPackage.eNS_URI, thePIMPackage);
		return thePIMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRootPIM() {
		return rootPIMEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRootPIM_Model() {
		return (EReference)rootPIMEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroservicesArchitectureModel() {
		return microservicesArchitectureModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroservicesArchitectureModel_ArchitectureName() {
		return (EAttribute)microservicesArchitectureModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroservicesArchitectureModel_StaticModel() {
		return (EReference)microservicesArchitectureModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroservicesArchitectureModel_InteractionModel() {
		return (EReference)microservicesArchitectureModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroserviceArchitectureStaticModel() {
		return microserviceArchitectureStaticModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceArchitectureStaticModel_Containers() {
		return (EReference)microserviceArchitectureStaticModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAmbient() {
		return ambientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainer() {
		return containerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainer_ContainerName() {
		return (EAttribute)containerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainer_Microservice() {
		return (EReference)containerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainer_Ports() {
		return (EReference)containerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPort() {
		return portEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPort_HostPort() {
		return (EAttribute)portEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPort_ContainerPort() {
		return (EAttribute)portEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroservice() {
		return microserviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroservice_MicroserviceName() {
		return (EAttribute)microserviceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroservice_MicroserviceType() {
		return (EAttribute)microserviceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroservice_Components() {
		return (EReference)microserviceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroservice_Interface() {
		return (EReference)microserviceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFunctionalMicroservice() {
		return functionalMicroserviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInfrastructureMicroservice() {
		return infrastructureMicroserviceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServicePatternComponent() {
		return servicePatternComponentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServicePatternComponent_PatternName() {
		return (EAttribute)servicePatternComponentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServicePatternComponent_ComponentRole() {
		return (EAttribute)servicePatternComponentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServicePatternComponent_ComponentType() {
		return (EAttribute)servicePatternComponentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServicePatternComponent_Subcomponent() {
		return (EReference)servicePatternComponentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServerComponent() {
		return serverComponentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClientComponent() {
		return clientComponentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInterface() {
		return interfaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInterface_Protocols() {
		return (EReference)interfaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInteractionProtocol() {
		return interactionProtocolEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionProtocol_ProtocolName() {
		return (EAttribute)interactionProtocolEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionProtocol_InteractionType() {
		return (EAttribute)interactionProtocolEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionProtocol_Destinations() {
		return (EReference)interactionProtocolEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSynchronousInteractionProtocol() {
		return synchronousInteractionProtocolEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAsynchronousInteractionProtocol() {
		return asynchronousInteractionProtocolEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInteractionDestination() {
		return interactionDestinationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInteractionDestination_DestinationName() {
		return (EAttribute)interactionDestinationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionDestination_Properties() {
		return (EReference)interactionDestinationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInteractionDestination_Message() {
		return (EReference)interactionDestinationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProperty() {
		return propertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_PropertyName() {
		return (EAttribute)propertyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProperty_PropertyValue() {
		return (EAttribute)propertyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMessage() {
		return messageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMessage_MessageType() {
		return (EAttribute)messageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMessage_BodyFormat() {
		return (EAttribute)messageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMessage_FormatLanguage() {
		return (EAttribute)messageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroservicesArchitectureInteractionModel() {
		return microservicesArchitectureInteractionModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroservicesArchitectureInteractionModel_ArchitectureName() {
		return (EAttribute)microservicesArchitectureInteractionModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroservicesArchitectureInteractionModel_Interaction() {
		return (EReference)microservicesArchitectureInteractionModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getServiceToServiceInteraction() {
		return serviceToServiceInteractionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceToServiceInteraction_ConsumerMicroservice() {
		return (EAttribute)serviceToServiceInteractionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getServiceToServiceInteraction_ProviderMicroservice() {
		return (EAttribute)serviceToServiceInteractionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getServiceToServiceInteraction_Provider() {
		return (EReference)serviceToServiceInteractionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PIMFactory getPIMFactory() {
		return (PIMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		rootPIMEClass = createEClass(ROOT_PIM);
		createEReference(rootPIMEClass, ROOT_PIM__MODEL);

		microservicesArchitectureModelEClass = createEClass(MICROSERVICES_ARCHITECTURE_MODEL);
		createEAttribute(microservicesArchitectureModelEClass, MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME);
		createEReference(microservicesArchitectureModelEClass, MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL);
		createEReference(microservicesArchitectureModelEClass, MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL);

		microserviceArchitectureStaticModelEClass = createEClass(MICROSERVICE_ARCHITECTURE_STATIC_MODEL);
		createEReference(microserviceArchitectureStaticModelEClass, MICROSERVICE_ARCHITECTURE_STATIC_MODEL__CONTAINERS);

		ambientEClass = createEClass(AMBIENT);

		containerEClass = createEClass(CONTAINER);
		createEAttribute(containerEClass, CONTAINER__CONTAINER_NAME);
		createEReference(containerEClass, CONTAINER__MICROSERVICE);
		createEReference(containerEClass, CONTAINER__PORTS);

		portEClass = createEClass(PORT);
		createEAttribute(portEClass, PORT__HOST_PORT);
		createEAttribute(portEClass, PORT__CONTAINER_PORT);

		microserviceEClass = createEClass(MICROSERVICE);
		createEAttribute(microserviceEClass, MICROSERVICE__MICROSERVICE_NAME);
		createEAttribute(microserviceEClass, MICROSERVICE__MICROSERVICE_TYPE);
		createEReference(microserviceEClass, MICROSERVICE__COMPONENTS);
		createEReference(microserviceEClass, MICROSERVICE__INTERFACE);

		functionalMicroserviceEClass = createEClass(FUNCTIONAL_MICROSERVICE);

		infrastructureMicroserviceEClass = createEClass(INFRASTRUCTURE_MICROSERVICE);

		servicePatternComponentEClass = createEClass(SERVICE_PATTERN_COMPONENT);
		createEAttribute(servicePatternComponentEClass, SERVICE_PATTERN_COMPONENT__PATTERN_NAME);
		createEAttribute(servicePatternComponentEClass, SERVICE_PATTERN_COMPONENT__COMPONENT_ROLE);
		createEAttribute(servicePatternComponentEClass, SERVICE_PATTERN_COMPONENT__COMPONENT_TYPE);
		createEReference(servicePatternComponentEClass, SERVICE_PATTERN_COMPONENT__SUBCOMPONENT);

		serverComponentEClass = createEClass(SERVER_COMPONENT);

		clientComponentEClass = createEClass(CLIENT_COMPONENT);

		interfaceEClass = createEClass(INTERFACE);
		createEReference(interfaceEClass, INTERFACE__PROTOCOLS);

		interactionProtocolEClass = createEClass(INTERACTION_PROTOCOL);
		createEAttribute(interactionProtocolEClass, INTERACTION_PROTOCOL__PROTOCOL_NAME);
		createEAttribute(interactionProtocolEClass, INTERACTION_PROTOCOL__INTERACTION_TYPE);
		createEReference(interactionProtocolEClass, INTERACTION_PROTOCOL__DESTINATIONS);

		synchronousInteractionProtocolEClass = createEClass(SYNCHRONOUS_INTERACTION_PROTOCOL);

		asynchronousInteractionProtocolEClass = createEClass(ASYNCHRONOUS_INTERACTION_PROTOCOL);

		interactionDestinationEClass = createEClass(INTERACTION_DESTINATION);
		createEAttribute(interactionDestinationEClass, INTERACTION_DESTINATION__DESTINATION_NAME);
		createEReference(interactionDestinationEClass, INTERACTION_DESTINATION__PROPERTIES);
		createEReference(interactionDestinationEClass, INTERACTION_DESTINATION__MESSAGE);

		propertyEClass = createEClass(PROPERTY);
		createEAttribute(propertyEClass, PROPERTY__PROPERTY_NAME);
		createEAttribute(propertyEClass, PROPERTY__PROPERTY_VALUE);

		messageEClass = createEClass(MESSAGE);
		createEAttribute(messageEClass, MESSAGE__MESSAGE_TYPE);
		createEAttribute(messageEClass, MESSAGE__BODY_FORMAT);
		createEAttribute(messageEClass, MESSAGE__FORMAT_LANGUAGE);

		microservicesArchitectureInteractionModelEClass = createEClass(MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL);
		createEAttribute(microservicesArchitectureInteractionModelEClass, MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME);
		createEReference(microservicesArchitectureInteractionModelEClass, MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION);

		serviceToServiceInteractionEClass = createEClass(SERVICE_TO_SERVICE_INTERACTION);
		createEAttribute(serviceToServiceInteractionEClass, SERVICE_TO_SERVICE_INTERACTION__CONSUMER_MICROSERVICE);
		createEAttribute(serviceToServiceInteractionEClass, SERVICE_TO_SERVICE_INTERACTION__PROVIDER_MICROSERVICE);
		createEReference(serviceToServiceInteractionEClass, SERVICE_TO_SERVICE_INTERACTION__PROVIDER);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		containerEClass.getESuperTypes().add(this.getAmbient());
		functionalMicroserviceEClass.getESuperTypes().add(this.getMicroservice());
		infrastructureMicroserviceEClass.getESuperTypes().add(this.getMicroservice());
		serverComponentEClass.getESuperTypes().add(this.getServicePatternComponent());
		clientComponentEClass.getESuperTypes().add(this.getServicePatternComponent());
		synchronousInteractionProtocolEClass.getESuperTypes().add(this.getInteractionProtocol());
		asynchronousInteractionProtocolEClass.getESuperTypes().add(this.getInteractionProtocol());

		// Initialize classes, features, and operations; add parameters
		initEClass(rootPIMEClass, RootPIM.class, "RootPIM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRootPIM_Model(), this.getMicroservicesArchitectureModel(), null, "model", null, 1, 1, RootPIM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microservicesArchitectureModelEClass, MicroservicesArchitectureModel.class, "MicroservicesArchitectureModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroservicesArchitectureModel_ArchitectureName(), ecorePackage.getEString(), "ArchitectureName", null, 1, 1, MicroservicesArchitectureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroservicesArchitectureModel_StaticModel(), this.getMicroserviceArchitectureStaticModel(), null, "staticModel", null, 1, 1, MicroservicesArchitectureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroservicesArchitectureModel_InteractionModel(), this.getMicroservicesArchitectureInteractionModel(), null, "interactionModel", null, 1, 1, MicroservicesArchitectureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microserviceArchitectureStaticModelEClass, MicroserviceArchitectureStaticModel.class, "MicroserviceArchitectureStaticModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMicroserviceArchitectureStaticModel_Containers(), this.getContainer(), null, "containers", null, 2, -1, MicroserviceArchitectureStaticModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ambientEClass, Ambient.class, "Ambient", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(containerEClass, PIM.Container.class, "Container", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContainer_ContainerName(), ecorePackage.getEString(), "ContainerName", null, 0, 1, PIM.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainer_Microservice(), this.getMicroservice(), null, "microservice", null, 1, 1, PIM.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainer_Ports(), this.getPort(), null, "ports", null, 1, -1, PIM.Container.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(portEClass, Port.class, "Port", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPort_HostPort(), ecorePackage.getEString(), "HostPort", null, 0, 1, Port.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPort_ContainerPort(), ecorePackage.getEString(), "ContainerPort", null, 0, 1, Port.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microserviceEClass, Microservice.class, "Microservice", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroservice_MicroserviceName(), ecorePackage.getEString(), "MicroserviceName", null, 0, 1, Microservice.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMicroservice_MicroserviceType(), ecorePackage.getEString(), "MicroserviceType", null, 0, 1, Microservice.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroservice_Components(), this.getServicePatternComponent(), null, "components", null, 0, -1, Microservice.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroservice_Interface(), this.getInterface(), null, "interface", null, 1, 1, Microservice.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(functionalMicroserviceEClass, FunctionalMicroservice.class, "FunctionalMicroservice", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(infrastructureMicroserviceEClass, InfrastructureMicroservice.class, "InfrastructureMicroservice", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(servicePatternComponentEClass, ServicePatternComponent.class, "ServicePatternComponent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getServicePatternComponent_PatternName(), ecorePackage.getEString(), "PatternName", null, 0, 1, ServicePatternComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServicePatternComponent_ComponentRole(), ecorePackage.getEString(), "ComponentRole", null, 0, 1, ServicePatternComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServicePatternComponent_ComponentType(), ecorePackage.getEString(), "ComponentType", null, 0, 1, ServicePatternComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getServicePatternComponent_Subcomponent(), this.getServicePatternComponent(), null, "subcomponent", null, 0, -1, ServicePatternComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(serverComponentEClass, ServerComponent.class, "ServerComponent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(clientComponentEClass, ClientComponent.class, "ClientComponent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interfaceEClass, Interface.class, "Interface", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInterface_Protocols(), this.getInteractionProtocol(), null, "protocols", null, 1, -1, Interface.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(interactionProtocolEClass, InteractionProtocol.class, "InteractionProtocol", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInteractionProtocol_ProtocolName(), ecorePackage.getEString(), "ProtocolName", null, 0, 1, InteractionProtocol.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInteractionProtocol_InteractionType(), ecorePackage.getEString(), "InteractionType", null, 0, 1, InteractionProtocol.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInteractionProtocol_Destinations(), this.getInteractionDestination(), null, "destinations", null, 1, -1, InteractionProtocol.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(synchronousInteractionProtocolEClass, SynchronousInteractionProtocol.class, "SynchronousInteractionProtocol", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(asynchronousInteractionProtocolEClass, AsynchronousInteractionProtocol.class, "AsynchronousInteractionProtocol", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(interactionDestinationEClass, InteractionDestination.class, "InteractionDestination", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInteractionDestination_DestinationName(), ecorePackage.getEString(), "DestinationName", null, 0, 1, InteractionDestination.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInteractionDestination_Properties(), this.getProperty(), null, "properties", null, 1, -1, InteractionDestination.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInteractionDestination_Message(), this.getMessage(), null, "message", null, 0, -1, InteractionDestination.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(propertyEClass, Property.class, "Property", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getProperty_PropertyName(), ecorePackage.getEString(), "PropertyName", null, 0, 1, Property.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProperty_PropertyValue(), ecorePackage.getEString(), "PropertyValue", null, 0, 1, Property.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(messageEClass, Message.class, "Message", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMessage_MessageType(), ecorePackage.getEString(), "MessageType", null, 0, 1, Message.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMessage_BodyFormat(), ecorePackage.getEString(), "BodyFormat", null, 0, 1, Message.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMessage_FormatLanguage(), ecorePackage.getEString(), "FormatLanguage", null, 0, 1, Message.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microservicesArchitectureInteractionModelEClass, MicroservicesArchitectureInteractionModel.class, "MicroservicesArchitectureInteractionModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroservicesArchitectureInteractionModel_ArchitectureName(), ecorePackage.getEString(), "ArchitectureName", null, 0, 1, MicroservicesArchitectureInteractionModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroservicesArchitectureInteractionModel_Interaction(), this.getServiceToServiceInteraction(), null, "interaction", null, 1, -1, MicroservicesArchitectureInteractionModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(serviceToServiceInteractionEClass, ServiceToServiceInteraction.class, "ServiceToServiceInteraction", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getServiceToServiceInteraction_ConsumerMicroservice(), ecorePackage.getEString(), "ConsumerMicroservice", null, 0, 1, ServiceToServiceInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getServiceToServiceInteraction_ProviderMicroservice(), ecorePackage.getEString(), "ProviderMicroservice", null, 0, 1, ServiceToServiceInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getServiceToServiceInteraction_Provider(), this.getInterface(), null, "provider", null, 1, 1, ServiceToServiceInteraction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //PIMPackageImpl
