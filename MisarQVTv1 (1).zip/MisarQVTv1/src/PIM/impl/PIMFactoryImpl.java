/**
 */
package PIM.impl;

import PIM.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PIMFactoryImpl extends EFactoryImpl implements PIMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PIMFactory init() {
		try {
			PIMFactory thePIMFactory = (PIMFactory)EPackage.Registry.INSTANCE.getEFactory(PIMPackage.eNS_URI);
			if (thePIMFactory != null) {
				return thePIMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PIMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PIMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case PIMPackage.ROOT_PIM: return createRootPIM();
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL: return createMicroservicesArchitectureModel();
			case PIMPackage.MICROSERVICE_ARCHITECTURE_STATIC_MODEL: return createMicroserviceArchitectureStaticModel();
			case PIMPackage.AMBIENT: return createAmbient();
			case PIMPackage.CONTAINER: return createContainer();
			case PIMPackage.PORT: return createPort();
			case PIMPackage.MICROSERVICE: return createMicroservice();
			case PIMPackage.FUNCTIONAL_MICROSERVICE: return createFunctionalMicroservice();
			case PIMPackage.INFRASTRUCTURE_MICROSERVICE: return createInfrastructureMicroservice();
			case PIMPackage.SERVICE_PATTERN_COMPONENT: return createServicePatternComponent();
			case PIMPackage.SERVER_COMPONENT: return createServerComponent();
			case PIMPackage.CLIENT_COMPONENT: return createClientComponent();
			case PIMPackage.INTERFACE: return createInterface();
			case PIMPackage.INTERACTION_PROTOCOL: return createInteractionProtocol();
			case PIMPackage.SYNCHRONOUS_INTERACTION_PROTOCOL: return createSynchronousInteractionProtocol();
			case PIMPackage.ASYNCHRONOUS_INTERACTION_PROTOCOL: return createAsynchronousInteractionProtocol();
			case PIMPackage.INTERACTION_DESTINATION: return createInteractionDestination();
			case PIMPackage.PROPERTY: return createProperty();
			case PIMPackage.MESSAGE: return createMessage();
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL: return createMicroservicesArchitectureInteractionModel();
			case PIMPackage.SERVICE_TO_SERVICE_INTERACTION: return createServiceToServiceInteraction();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RootPIM createRootPIM() {
		RootPIMImpl rootPIM = new RootPIMImpl();
		return rootPIM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroservicesArchitectureModel createMicroservicesArchitectureModel() {
		MicroservicesArchitectureModelImpl microservicesArchitectureModel = new MicroservicesArchitectureModelImpl();
		return microservicesArchitectureModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceArchitectureStaticModel createMicroserviceArchitectureStaticModel() {
		MicroserviceArchitectureStaticModelImpl microserviceArchitectureStaticModel = new MicroserviceArchitectureStaticModelImpl();
		return microserviceArchitectureStaticModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ambient createAmbient() {
		AmbientImpl ambient = new AmbientImpl();
		return ambient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PIM.Container createContainer() {
		ContainerImpl container = new ContainerImpl();
		return container;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Port createPort() {
		PortImpl port = new PortImpl();
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Microservice createMicroservice() {
		MicroserviceImpl microservice = new MicroserviceImpl();
		return microservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FunctionalMicroservice createFunctionalMicroservice() {
		FunctionalMicroserviceImpl functionalMicroservice = new FunctionalMicroserviceImpl();
		return functionalMicroservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InfrastructureMicroservice createInfrastructureMicroservice() {
		InfrastructureMicroserviceImpl infrastructureMicroservice = new InfrastructureMicroserviceImpl();
		return infrastructureMicroservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServicePatternComponent createServicePatternComponent() {
		ServicePatternComponentImpl servicePatternComponent = new ServicePatternComponentImpl();
		return servicePatternComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServerComponent createServerComponent() {
		ServerComponentImpl serverComponent = new ServerComponentImpl();
		return serverComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClientComponent createClientComponent() {
		ClientComponentImpl clientComponent = new ClientComponentImpl();
		return clientComponent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Interface createInterface() {
		InterfaceImpl interface_ = new InterfaceImpl();
		return interface_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InteractionProtocol createInteractionProtocol() {
		InteractionProtocolImpl interactionProtocol = new InteractionProtocolImpl();
		return interactionProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SynchronousInteractionProtocol createSynchronousInteractionProtocol() {
		SynchronousInteractionProtocolImpl synchronousInteractionProtocol = new SynchronousInteractionProtocolImpl();
		return synchronousInteractionProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AsynchronousInteractionProtocol createAsynchronousInteractionProtocol() {
		AsynchronousInteractionProtocolImpl asynchronousInteractionProtocol = new AsynchronousInteractionProtocolImpl();
		return asynchronousInteractionProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InteractionDestination createInteractionDestination() {
		InteractionDestinationImpl interactionDestination = new InteractionDestinationImpl();
		return interactionDestination;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Property createProperty() {
		PropertyImpl property = new PropertyImpl();
		return property;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Message createMessage() {
		MessageImpl message = new MessageImpl();
		return message;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroservicesArchitectureInteractionModel createMicroservicesArchitectureInteractionModel() {
		MicroservicesArchitectureInteractionModelImpl microservicesArchitectureInteractionModel = new MicroservicesArchitectureInteractionModelImpl();
		return microservicesArchitectureInteractionModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ServiceToServiceInteraction createServiceToServiceInteraction() {
		ServiceToServiceInteractionImpl serviceToServiceInteraction = new ServiceToServiceInteractionImpl();
		return serviceToServiceInteraction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PIMPackage getPIMPackage() {
		return (PIMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PIMPackage getPackage() {
		return PIMPackage.eINSTANCE;
	}

} //PIMFactoryImpl
