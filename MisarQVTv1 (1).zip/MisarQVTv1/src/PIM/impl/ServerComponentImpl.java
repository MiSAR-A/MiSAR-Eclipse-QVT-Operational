/**
 */
package PIM.impl;

import PIM.PIMPackage;
import PIM.ServerComponent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Server Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ServerComponentImpl extends ServicePatternComponentImpl implements ServerComponent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServerComponentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.SERVER_COMPONENT;
	}

} //ServerComponentImpl
