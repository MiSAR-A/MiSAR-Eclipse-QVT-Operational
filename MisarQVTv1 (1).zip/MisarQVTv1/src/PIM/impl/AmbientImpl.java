/**
 */
package PIM.impl;

import PIM.Ambient;
import PIM.PIMPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ambient</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AmbientImpl extends MinimalEObjectImpl.Container implements Ambient {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AmbientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.AMBIENT;
	}

} //AmbientImpl
