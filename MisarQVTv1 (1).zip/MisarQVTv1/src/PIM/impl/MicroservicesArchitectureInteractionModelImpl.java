/**
 */
package PIM.impl;

import PIM.MicroservicesArchitectureInteractionModel;
import PIM.PIMPackage;
import PIM.ServiceToServiceInteraction;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Microservices Architecture Interaction Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.MicroservicesArchitectureInteractionModelImpl#getArchitectureName <em>Architecture Name</em>}</li>
 *   <li>{@link PIM.impl.MicroservicesArchitectureInteractionModelImpl#getInteraction <em>Interaction</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MicroservicesArchitectureInteractionModelImpl extends MinimalEObjectImpl.Container implements MicroservicesArchitectureInteractionModel {
	/**
	 * The default value of the '{@link #getArchitectureName() <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchitectureName()
	 * @generated
	 * @ordered
	 */
	protected static final String ARCHITECTURE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArchitectureName() <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchitectureName()
	 * @generated
	 * @ordered
	 */
	protected String architectureName = ARCHITECTURE_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getInteraction() <em>Interaction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteraction()
	 * @generated
	 * @ordered
	 */
	protected EList<ServiceToServiceInteraction> interaction;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicroservicesArchitectureInteractionModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getArchitectureName() {
		return architectureName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArchitectureName(String newArchitectureName) {
		String oldArchitectureName = architectureName;
		architectureName = newArchitectureName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME, oldArchitectureName, architectureName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ServiceToServiceInteraction> getInteraction() {
		if (interaction == null) {
			interaction = new EObjectContainmentEList<ServiceToServiceInteraction>(ServiceToServiceInteraction.class, this, PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION);
		}
		return interaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION:
				return ((InternalEList<?>)getInteraction()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME:
				return getArchitectureName();
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION:
				return getInteraction();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME:
				setArchitectureName((String)newValue);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION:
				getInteraction().clear();
				getInteraction().addAll((Collection<? extends ServiceToServiceInteraction>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME:
				setArchitectureName(ARCHITECTURE_NAME_EDEFAULT);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION:
				getInteraction().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__ARCHITECTURE_NAME:
				return ARCHITECTURE_NAME_EDEFAULT == null ? architectureName != null : !ARCHITECTURE_NAME_EDEFAULT.equals(architectureName);
			case PIMPackage.MICROSERVICES_ARCHITECTURE_INTERACTION_MODEL__INTERACTION:
				return interaction != null && !interaction.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ArchitectureName: ");
		result.append(architectureName);
		result.append(')');
		return result.toString();
	}

} //MicroservicesArchitectureInteractionModelImpl
