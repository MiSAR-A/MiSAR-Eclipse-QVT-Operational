/**
 */
package PIM.impl;

import PIM.MicroserviceArchitectureStaticModel;
import PIM.MicroservicesArchitectureInteractionModel;
import PIM.MicroservicesArchitectureModel;
import PIM.PIMPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Microservices Architecture Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PIM.impl.MicroservicesArchitectureModelImpl#getArchitectureName <em>Architecture Name</em>}</li>
 *   <li>{@link PIM.impl.MicroservicesArchitectureModelImpl#getStaticModel <em>Static Model</em>}</li>
 *   <li>{@link PIM.impl.MicroservicesArchitectureModelImpl#getInteractionModel <em>Interaction Model</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MicroservicesArchitectureModelImpl extends MinimalEObjectImpl.Container implements MicroservicesArchitectureModel {
	/**
	 * The default value of the '{@link #getArchitectureName() <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchitectureName()
	 * @generated
	 * @ordered
	 */
	protected static final String ARCHITECTURE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArchitectureName() <em>Architecture Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArchitectureName()
	 * @generated
	 * @ordered
	 */
	protected String architectureName = ARCHITECTURE_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStaticModel() <em>Static Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStaticModel()
	 * @generated
	 * @ordered
	 */
	protected MicroserviceArchitectureStaticModel staticModel;

	/**
	 * The cached value of the '{@link #getInteractionModel() <em>Interaction Model</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteractionModel()
	 * @generated
	 * @ordered
	 */
	protected MicroservicesArchitectureInteractionModel interactionModel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicroservicesArchitectureModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PIMPackage.Literals.MICROSERVICES_ARCHITECTURE_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getArchitectureName() {
		return architectureName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArchitectureName(String newArchitectureName) {
		String oldArchitectureName = architectureName;
		architectureName = newArchitectureName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME, oldArchitectureName, architectureName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceArchitectureStaticModel getStaticModel() {
		return staticModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetStaticModel(MicroserviceArchitectureStaticModel newStaticModel, NotificationChain msgs) {
		MicroserviceArchitectureStaticModel oldStaticModel = staticModel;
		staticModel = newStaticModel;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL, oldStaticModel, newStaticModel);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStaticModel(MicroserviceArchitectureStaticModel newStaticModel) {
		if (newStaticModel != staticModel) {
			NotificationChain msgs = null;
			if (staticModel != null)
				msgs = ((InternalEObject)staticModel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL, null, msgs);
			if (newStaticModel != null)
				msgs = ((InternalEObject)newStaticModel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL, null, msgs);
			msgs = basicSetStaticModel(newStaticModel, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL, newStaticModel, newStaticModel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroservicesArchitectureInteractionModel getInteractionModel() {
		return interactionModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInteractionModel(MicroservicesArchitectureInteractionModel newInteractionModel, NotificationChain msgs) {
		MicroservicesArchitectureInteractionModel oldInteractionModel = interactionModel;
		interactionModel = newInteractionModel;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL, oldInteractionModel, newInteractionModel);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInteractionModel(MicroservicesArchitectureInteractionModel newInteractionModel) {
		if (newInteractionModel != interactionModel) {
			NotificationChain msgs = null;
			if (interactionModel != null)
				msgs = ((InternalEObject)interactionModel).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL, null, msgs);
			if (newInteractionModel != null)
				msgs = ((InternalEObject)newInteractionModel).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL, null, msgs);
			msgs = basicSetInteractionModel(newInteractionModel, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL, newInteractionModel, newInteractionModel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL:
				return basicSetStaticModel(null, msgs);
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL:
				return basicSetInteractionModel(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME:
				return getArchitectureName();
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL:
				return getStaticModel();
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL:
				return getInteractionModel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME:
				setArchitectureName((String)newValue);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL:
				setStaticModel((MicroserviceArchitectureStaticModel)newValue);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL:
				setInteractionModel((MicroservicesArchitectureInteractionModel)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME:
				setArchitectureName(ARCHITECTURE_NAME_EDEFAULT);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL:
				setStaticModel((MicroserviceArchitectureStaticModel)null);
				return;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL:
				setInteractionModel((MicroservicesArchitectureInteractionModel)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__ARCHITECTURE_NAME:
				return ARCHITECTURE_NAME_EDEFAULT == null ? architectureName != null : !ARCHITECTURE_NAME_EDEFAULT.equals(architectureName);
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__STATIC_MODEL:
				return staticModel != null;
			case PIMPackage.MICROSERVICES_ARCHITECTURE_MODEL__INTERACTION_MODEL:
				return interactionModel != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ArchitectureName: ");
		result.append(architectureName);
		result.append(')');
		return result.toString();
	}

} //MicroservicesArchitectureModelImpl
