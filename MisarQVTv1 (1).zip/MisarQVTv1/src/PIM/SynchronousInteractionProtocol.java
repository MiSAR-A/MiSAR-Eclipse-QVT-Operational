/**
 */
package PIM;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Synchronous Interaction Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getSynchronousInteractionProtocol()
 * @model
 * @generated
 */
public interface SynchronousInteractionProtocol extends InteractionProtocol {

} // SynchronousInteractionProtocol
