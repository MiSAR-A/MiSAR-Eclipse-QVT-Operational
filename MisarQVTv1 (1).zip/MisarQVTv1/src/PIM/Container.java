/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.Container#getContainerName <em>Container Name</em>}</li>
 *   <li>{@link PIM.Container#getMicroservice <em>Microservice</em>}</li>
 *   <li>{@link PIM.Container#getPorts <em>Ports</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getContainer()
 * @model
 * @generated
 */
public interface Container extends Ambient {
	/**
	 * Returns the value of the '<em><b>Container Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Name</em>' attribute.
	 * @see #setContainerName(String)
	 * @see PIM.PIMPackage#getContainer_ContainerName()
	 * @model
	 * @generated
	 */
	String getContainerName();

	/**
	 * Sets the value of the '{@link PIM.Container#getContainerName <em>Container Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container Name</em>' attribute.
	 * @see #getContainerName()
	 * @generated
	 */
	void setContainerName(String value);

	/**
	 * Returns the value of the '<em><b>Microservice</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Microservice</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Microservice</em>' containment reference.
	 * @see #setMicroservice(Microservice)
	 * @see PIM.PIMPackage#getContainer_Microservice()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Microservice getMicroservice();

	/**
	 * Sets the value of the '{@link PIM.Container#getMicroservice <em>Microservice</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Microservice</em>' containment reference.
	 * @see #getMicroservice()
	 * @generated
	 */
	void setMicroservice(Microservice value);

	/**
	 * Returns the value of the '<em><b>Ports</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.Port}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ports</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' containment reference list.
	 * @see PIM.PIMPackage#getContainer_Ports()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Port> getPorts();

} // Container
