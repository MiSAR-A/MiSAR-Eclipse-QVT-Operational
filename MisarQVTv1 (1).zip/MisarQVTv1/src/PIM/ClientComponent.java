/**
 */
package PIM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Client Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getClientComponent()
 * @model
 * @generated
 */
public interface ClientComponent extends ServicePatternComponent {
} // ClientComponent
