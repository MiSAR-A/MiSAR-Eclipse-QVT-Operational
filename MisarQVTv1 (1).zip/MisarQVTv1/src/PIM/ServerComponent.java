/**
 */
package PIM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Server Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PIM.PIMPackage#getServerComponent()
 * @model
 * @generated
 */
public interface ServerComponent extends ServicePatternComponent {
} // ServerComponent
