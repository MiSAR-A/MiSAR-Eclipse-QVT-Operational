/**
 */
package PIM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see PIM.PIMPackage
 * @generated
 */
public interface PIMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PIMFactory eINSTANCE = PIM.impl.PIMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Root PIM</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Root PIM</em>'.
	 * @generated
	 */
	RootPIM createRootPIM();

	/**
	 * Returns a new object of class '<em>Microservices Architecture Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservices Architecture Model</em>'.
	 * @generated
	 */
	MicroservicesArchitectureModel createMicroservicesArchitectureModel();

	/**
	 * Returns a new object of class '<em>Microservice Architecture Static Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservice Architecture Static Model</em>'.
	 * @generated
	 */
	MicroserviceArchitectureStaticModel createMicroserviceArchitectureStaticModel();

	/**
	 * Returns a new object of class '<em>Ambient</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ambient</em>'.
	 * @generated
	 */
	Ambient createAmbient();

	/**
	 * Returns a new object of class '<em>Container</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Container</em>'.
	 * @generated
	 */
	Container createContainer();

	/**
	 * Returns a new object of class '<em>Port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port</em>'.
	 * @generated
	 */
	Port createPort();

	/**
	 * Returns a new object of class '<em>Microservice</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservice</em>'.
	 * @generated
	 */
	Microservice createMicroservice();

	/**
	 * Returns a new object of class '<em>Functional Microservice</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Functional Microservice</em>'.
	 * @generated
	 */
	FunctionalMicroservice createFunctionalMicroservice();

	/**
	 * Returns a new object of class '<em>Infrastructure Microservice</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Infrastructure Microservice</em>'.
	 * @generated
	 */
	InfrastructureMicroservice createInfrastructureMicroservice();

	/**
	 * Returns a new object of class '<em>Service Pattern Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service Pattern Component</em>'.
	 * @generated
	 */
	ServicePatternComponent createServicePatternComponent();

	/**
	 * Returns a new object of class '<em>Server Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Server Component</em>'.
	 * @generated
	 */
	ServerComponent createServerComponent();

	/**
	 * Returns a new object of class '<em>Client Component</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Client Component</em>'.
	 * @generated
	 */
	ClientComponent createClientComponent();

	/**
	 * Returns a new object of class '<em>Interface</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interface</em>'.
	 * @generated
	 */
	Interface createInterface();

	/**
	 * Returns a new object of class '<em>Interaction Protocol</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interaction Protocol</em>'.
	 * @generated
	 */
	InteractionProtocol createInteractionProtocol();

	/**
	 * Returns a new object of class '<em>Synchronous Interaction Protocol</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Synchronous Interaction Protocol</em>'.
	 * @generated
	 */
	SynchronousInteractionProtocol createSynchronousInteractionProtocol();

	/**
	 * Returns a new object of class '<em>Asynchronous Interaction Protocol</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Asynchronous Interaction Protocol</em>'.
	 * @generated
	 */
	AsynchronousInteractionProtocol createAsynchronousInteractionProtocol();

	/**
	 * Returns a new object of class '<em>Interaction Destination</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Interaction Destination</em>'.
	 * @generated
	 */
	InteractionDestination createInteractionDestination();

	/**
	 * Returns a new object of class '<em>Property</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Property</em>'.
	 * @generated
	 */
	Property createProperty();

	/**
	 * Returns a new object of class '<em>Message</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Message</em>'.
	 * @generated
	 */
	Message createMessage();

	/**
	 * Returns a new object of class '<em>Microservices Architecture Interaction Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservices Architecture Interaction Model</em>'.
	 * @generated
	 */
	MicroservicesArchitectureInteractionModel createMicroservicesArchitectureInteractionModel();

	/**
	 * Returns a new object of class '<em>Service To Service Interaction</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Service To Service Interaction</em>'.
	 * @generated
	 */
	ServiceToServiceInteraction createServiceToServiceInteraction();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PIMPackage getPIMPackage();

} //PIMFactory
