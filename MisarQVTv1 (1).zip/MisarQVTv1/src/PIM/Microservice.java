/**
 */
package PIM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservice</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PIM.Microservice#getMicroserviceName <em>Microservice Name</em>}</li>
 *   <li>{@link PIM.Microservice#getMicroserviceType <em>Microservice Type</em>}</li>
 *   <li>{@link PIM.Microservice#getComponents <em>Components</em>}</li>
 *   <li>{@link PIM.Microservice#getInterface <em>Interface</em>}</li>
 * </ul>
 *
 * @see PIM.PIMPackage#getMicroservice()
 * @model
 * @generated
 */
public interface Microservice extends EObject {
	/**
	 * Returns the value of the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Microservice Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Microservice Name</em>' attribute.
	 * @see #setMicroserviceName(String)
	 * @see PIM.PIMPackage#getMicroservice_MicroserviceName()
	 * @model
	 * @generated
	 */
	String getMicroserviceName();

	/**
	 * Sets the value of the '{@link PIM.Microservice#getMicroserviceName <em>Microservice Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Microservice Name</em>' attribute.
	 * @see #getMicroserviceName()
	 * @generated
	 */
	void setMicroserviceName(String value);

	/**
	 * Returns the value of the '<em><b>Microservice Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Microservice Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Microservice Type</em>' attribute.
	 * @see #setMicroserviceType(String)
	 * @see PIM.PIMPackage#getMicroservice_MicroserviceType()
	 * @model
	 * @generated
	 */
	String getMicroserviceType();

	/**
	 * Sets the value of the '{@link PIM.Microservice#getMicroserviceType <em>Microservice Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Microservice Type</em>' attribute.
	 * @see #getMicroserviceType()
	 * @generated
	 */
	void setMicroserviceType(String value);

	/**
	 * Returns the value of the '<em><b>Components</b></em>' containment reference list.
	 * The list contents are of type {@link PIM.ServicePatternComponent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Components</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Components</em>' containment reference list.
	 * @see PIM.PIMPackage#getMicroservice_Components()
	 * @model containment="true"
	 * @generated
	 */
	EList<ServicePatternComponent> getComponents();

	/**
	 * Returns the value of the '<em><b>Interface</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Interface</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interface</em>' containment reference.
	 * @see #setInterface(Interface)
	 * @see PIM.PIMPackage#getMicroservice_Interface()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Interface getInterface();

	/**
	 * Sets the value of the '{@link PIM.Microservice#getInterface <em>Interface</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interface</em>' containment reference.
	 * @see #getInterface()
	 * @generated
	 */
	void setInterface(Interface value);

} // Microservice
