/**
 */
package PSM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.JavaField#getJsonSchema <em>Json Schema</em>}</li>
 *   <li>{@link PSM.JavaField#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getJavaField()
 * @model
 * @generated
 */
public interface JavaField extends JavaElement {
	/**
	 * Returns the value of the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Json Schema</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Json Schema</em>' attribute.
	 * @see #setJsonSchema(String)
	 * @see PSM.PSMPackage#getJavaField_JsonSchema()
	 * @model
	 * @generated
	 */
	String getJsonSchema();

	/**
	 * Sets the value of the '{@link PSM.JavaField#getJsonSchema <em>Json Schema</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Json Schema</em>' attribute.
	 * @see #getJsonSchema()
	 * @generated
	 */
	void setJsonSchema(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' containment reference.
	 * @see #setType(JavaDataType)
	 * @see PSM.PSMPackage#getJavaField_Type()
	 * @model containment="true" required="true"
	 * @generated
	 */
	JavaDataType getType();

	/**
	 * Sets the value of the '{@link PSM.JavaField#getType <em>Type</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' containment reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(JavaDataType value);

} // JavaField
