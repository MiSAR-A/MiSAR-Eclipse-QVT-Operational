/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Root PSM</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.RootPSM#getSystem <em>System</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getRootPSM()
 * @model
 * @generated
 */
public interface RootPSM extends EObject {
	/**
	 * Returns the value of the '<em><b>System</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>System</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>System</em>' containment reference.
	 * @see #setSystem(SystemProjectArtifactsModel)
	 * @see PSM.PSMPackage#getRootPSM_System()
	 * @model containment="true" required="true"
	 * @generated
	 */
	SystemProjectArtifactsModel getSystem();

	/**
	 * Sets the value of the '{@link PSM.RootPSM#getSystem <em>System</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>System</em>' containment reference.
	 * @see #getSystem()
	 * @generated
	 */
	void setSystem(SystemProjectArtifactsModel value);

} // RootPSM
