/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dependency Library</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.DependencyLibrary#getLibraryGroupName <em>Library Group Name</em>}</li>
 *   <li>{@link PSM.DependencyLibrary#getLibraryName <em>Library Name</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getDependencyLibrary()
 * @model
 * @generated
 */
public interface DependencyLibrary extends EObject {
	/**
	 * Returns the value of the '<em><b>Library Group Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Library Group Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Library Group Name</em>' attribute.
	 * @see #setLibraryGroupName(String)
	 * @see PSM.PSMPackage#getDependencyLibrary_LibraryGroupName()
	 * @model
	 * @generated
	 */
	String getLibraryGroupName();

	/**
	 * Sets the value of the '{@link PSM.DependencyLibrary#getLibraryGroupName <em>Library Group Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Library Group Name</em>' attribute.
	 * @see #getLibraryGroupName()
	 * @generated
	 */
	void setLibraryGroupName(String value);

	/**
	 * Returns the value of the '<em><b>Library Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Library Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Library Name</em>' attribute.
	 * @see #setLibraryName(String)
	 * @see PSM.PSMPackage#getDependencyLibrary_LibraryName()
	 * @model
	 * @generated
	 */
	String getLibraryName();

	/**
	 * Sets the value of the '{@link PSM.DependencyLibrary#getLibraryName <em>Library Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Library Name</em>' attribute.
	 * @see #getLibraryName()
	 * @generated
	 */
	void setLibraryName(String value);

} // DependencyLibrary
