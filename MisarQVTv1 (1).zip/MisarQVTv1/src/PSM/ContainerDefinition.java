/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container Definition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.ContainerDefinition#getServiceName <em>Service Name</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getImageField <em>Image Field</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getBuildField <em>Build Field</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#isLoggingField <em>Logging Field</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getPorts <em>Ports</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getLinks <em>Links</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getBuild <em>Build</em>}</li>
 *   <li>{@link PSM.ContainerDefinition#getProject <em>Project</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getContainerDefinition()
 * @model
 * @generated
 */
public interface ContainerDefinition extends EObject {
	/**
	 * Returns the value of the '<em><b>Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service Name</em>' attribute.
	 * @see #setServiceName(String)
	 * @see PSM.PSMPackage#getContainerDefinition_ServiceName()
	 * @model
	 * @generated
	 */
	String getServiceName();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#getServiceName <em>Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service Name</em>' attribute.
	 * @see #getServiceName()
	 * @generated
	 */
	void setServiceName(String value);

	/**
	 * Returns the value of the '<em><b>Image Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Image Field</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image Field</em>' attribute.
	 * @see #setImageField(String)
	 * @see PSM.PSMPackage#getContainerDefinition_ImageField()
	 * @model
	 * @generated
	 */
	String getImageField();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#getImageField <em>Image Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image Field</em>' attribute.
	 * @see #getImageField()
	 * @generated
	 */
	void setImageField(String value);

	/**
	 * Returns the value of the '<em><b>Build Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Build Field</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Build Field</em>' attribute.
	 * @see #setBuildField(String)
	 * @see PSM.PSMPackage#getContainerDefinition_BuildField()
	 * @model
	 * @generated
	 */
	String getBuildField();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#getBuildField <em>Build Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Build Field</em>' attribute.
	 * @see #getBuildField()
	 * @generated
	 */
	void setBuildField(String value);

	/**
	 * Returns the value of the '<em><b>Logging Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Logging Field</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Logging Field</em>' attribute.
	 * @see #setLoggingField(boolean)
	 * @see PSM.PSMPackage#getContainerDefinition_LoggingField()
	 * @model
	 * @generated
	 */
	boolean isLoggingField();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#isLoggingField <em>Logging Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Logging Field</em>' attribute.
	 * @see #isLoggingField()
	 * @generated
	 */
	void setLoggingField(boolean value);

	/**
	 * Returns the value of the '<em><b>Ports</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.PortsField}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ports</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' containment reference list.
	 * @see PSM.PSMPackage#getContainerDefinition_Ports()
	 * @model containment="true"
	 * @generated
	 */
	EList<PortsField> getPorts();

	/**
	 * Returns the value of the '<em><b>Links</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.ContainerLink}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Links</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Links</em>' containment reference list.
	 * @see PSM.PSMPackage#getContainerDefinition_Links()
	 * @model containment="true"
	 * @generated
	 */
	EList<ContainerLink> getLinks();

	/**
	 * Returns the value of the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Build</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Build</em>' containment reference.
	 * @see #setBuild(DockerFile)
	 * @see PSM.PSMPackage#getContainerDefinition_Build()
	 * @model containment="true"
	 * @generated
	 */
	DockerFile getBuild();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#getBuild <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Build</em>' containment reference.
	 * @see #getBuild()
	 * @generated
	 */
	void setBuild(DockerFile value);

	/**
	 * Returns the value of the '<em><b>Project</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Project</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Project</em>' containment reference.
	 * @see #setProject(MicroserviceProjectArtifactsModel)
	 * @see PSM.PSMPackage#getContainerDefinition_Project()
	 * @model containment="true"
	 * @generated
	 */
	MicroserviceProjectArtifactsModel getProject();

	/**
	 * Sets the value of the '{@link PSM.ContainerDefinition#getProject <em>Project</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Project</em>' containment reference.
	 * @see #getProject()
	 * @generated
	 */
	void setProject(MicroserviceProjectArtifactsModel value);

} // ContainerDefinition
