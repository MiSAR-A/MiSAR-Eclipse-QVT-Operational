/**
 */
package PSM;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see PSM.PSMPackage
 * @generated
 */
public interface PSMFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PSMFactory eINSTANCE = PSM.impl.PSMFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Root PSM</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Root PSM</em>'.
	 * @generated
	 */
	RootPSM createRootPSM();

	/**
	 * Returns a new object of class '<em>System Project Artifacts Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>System Project Artifacts Model</em>'.
	 * @generated
	 */
	SystemProjectArtifactsModel createSystemProjectArtifactsModel();

	/**
	 * Returns a new object of class '<em>Docker Compose File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Docker Compose File</em>'.
	 * @generated
	 */
	DockerComposeFile createDockerComposeFile();

	/**
	 * Returns a new object of class '<em>Container Definition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Container Definition</em>'.
	 * @generated
	 */
	ContainerDefinition createContainerDefinition();

	/**
	 * Returns a new object of class '<em>Ports Field</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ports Field</em>'.
	 * @generated
	 */
	PortsField createPortsField();

	/**
	 * Returns a new object of class '<em>Container Link</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Container Link</em>'.
	 * @generated
	 */
	ContainerLink createContainerLink();

	/**
	 * Returns a new object of class '<em>Docker File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Docker File</em>'.
	 * @generated
	 */
	DockerFile createDockerFile();

	/**
	 * Returns a new object of class '<em>System Project Build File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>System Project Build File</em>'.
	 * @generated
	 */
	SystemProjectBuildFile createSystemProjectBuildFile();

	/**
	 * Returns a new object of class '<em>Microservice Project Artifacts Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservice Project Artifacts Model</em>'.
	 * @generated
	 */
	MicroserviceProjectArtifactsModel createMicroserviceProjectArtifactsModel();

	/**
	 * Returns a new object of class '<em>Microservice Project Build File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservice Project Build File</em>'.
	 * @generated
	 */
	MicroserviceProjectBuildFile createMicroserviceProjectBuildFile();

	/**
	 * Returns a new object of class '<em>Dependency Library</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dependency Library</em>'.
	 * @generated
	 */
	DependencyLibrary createDependencyLibrary();

	/**
	 * Returns a new object of class '<em>Microservice Project Configurations File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Microservice Project Configurations File</em>'.
	 * @generated
	 */
	MicroserviceProjectConfigurationsFile createMicroserviceProjectConfigurationsFile();

	/**
	 * Returns a new object of class '<em>Configuration Property</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Configuration Property</em>'.
	 * @generated
	 */
	ConfigurationProperty createConfigurationProperty();

	/**
	 * Returns a new object of class '<em>Source File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Source File</em>'.
	 * @generated
	 */
	SourceFile createSourceFile();

	/**
	 * Returns a new object of class '<em>Java Source File</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Source File</em>'.
	 * @generated
	 */
	JavaSourceFile createJavaSourceFile();

	/**
	 * Returns a new object of class '<em>Java Element</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Element</em>'.
	 * @generated
	 */
	JavaElement createJavaElement();

	/**
	 * Returns a new object of class '<em>Java Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Annotation</em>'.
	 * @generated
	 */
	JavaAnnotation createJavaAnnotation();

	/**
	 * Returns a new object of class '<em>Java Annotation Parameter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Annotation Parameter</em>'.
	 * @generated
	 */
	JavaAnnotationParameter createJavaAnnotationParameter();

	/**
	 * Returns a new object of class '<em>Java Data Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Data Type</em>'.
	 * @generated
	 */
	JavaDataType createJavaDataType();

	/**
	 * Returns a new object of class '<em>Java User Defined Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java User Defined Type</em>'.
	 * @generated
	 */
	JavaUserDefinedType createJavaUserDefinedType();

	/**
	 * Returns a new object of class '<em>Java Class Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Class Type</em>'.
	 * @generated
	 */
	JavaClassType createJavaClassType();

	/**
	 * Returns a new object of class '<em>Java Interface Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Interface Type</em>'.
	 * @generated
	 */
	JavaInterfaceType createJavaInterfaceType();

	/**
	 * Returns a new object of class '<em>Java Method</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Method</em>'.
	 * @generated
	 */
	JavaMethod createJavaMethod();

	/**
	 * Returns a new object of class '<em>Java Field</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Java Field</em>'.
	 * @generated
	 */
	JavaField createJavaField();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	PSMPackage getPSMPackage();

} //PSMFactory
