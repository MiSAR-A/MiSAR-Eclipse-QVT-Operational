/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System Project Artifacts Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.SystemProjectArtifactsModel#getProjectName <em>Project Name</em>}</li>
 *   <li>{@link PSM.SystemProjectArtifactsModel#getArtifactsRepositoryURI <em>Artifacts Repository URI</em>}</li>
 *   <li>{@link PSM.SystemProjectArtifactsModel#getDocker <em>Docker</em>}</li>
 *   <li>{@link PSM.SystemProjectArtifactsModel#getBuild <em>Build</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getSystemProjectArtifactsModel()
 * @model
 * @generated
 */
public interface SystemProjectArtifactsModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Project Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Project Name</em>' attribute.
	 * @see #setProjectName(String)
	 * @see PSM.PSMPackage#getSystemProjectArtifactsModel_ProjectName()
	 * @model
	 * @generated
	 */
	String getProjectName();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectArtifactsModel#getProjectName <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Project Name</em>' attribute.
	 * @see #getProjectName()
	 * @generated
	 */
	void setProjectName(String value);

	/**
	 * Returns the value of the '<em><b>Artifacts Repository URI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Artifacts Repository URI</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Artifacts Repository URI</em>' attribute.
	 * @see #setArtifactsRepositoryURI(String)
	 * @see PSM.PSMPackage#getSystemProjectArtifactsModel_ArtifactsRepositoryURI()
	 * @model
	 * @generated
	 */
	String getArtifactsRepositoryURI();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectArtifactsModel#getArtifactsRepositoryURI <em>Artifacts Repository URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Artifacts Repository URI</em>' attribute.
	 * @see #getArtifactsRepositoryURI()
	 * @generated
	 */
	void setArtifactsRepositoryURI(String value);

	/**
	 * Returns the value of the '<em><b>Docker</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Docker</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Docker</em>' containment reference.
	 * @see #setDocker(DockerComposeFile)
	 * @see PSM.PSMPackage#getSystemProjectArtifactsModel_Docker()
	 * @model containment="true"
	 * @generated
	 */
	DockerComposeFile getDocker();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectArtifactsModel#getDocker <em>Docker</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Docker</em>' containment reference.
	 * @see #getDocker()
	 * @generated
	 */
	void setDocker(DockerComposeFile value);

	/**
	 * Returns the value of the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Build</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Build</em>' containment reference.
	 * @see #setBuild(SystemProjectBuildFile)
	 * @see PSM.PSMPackage#getSystemProjectArtifactsModel_Build()
	 * @model containment="true"
	 * @generated
	 */
	SystemProjectBuildFile getBuild();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectArtifactsModel#getBuild <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Build</em>' containment reference.
	 * @see #getBuild()
	 * @generated
	 */
	void setBuild(SystemProjectBuildFile value);

} // SystemProjectArtifactsModel
