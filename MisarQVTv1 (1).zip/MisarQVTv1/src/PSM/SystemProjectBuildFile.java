/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System Project Build File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.SystemProjectBuildFile#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.SystemProjectBuildFile#getSystemProjectName <em>System Project Name</em>}</li>
 *   <li>{@link PSM.SystemProjectBuildFile#getProjects <em>Projects</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getSystemProjectBuildFile()
 * @model
 * @generated
 */
public interface SystemProjectBuildFile extends EObject {
	/**
	 * Returns the value of the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>File Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Name</em>' attribute.
	 * @see #setFileName(String)
	 * @see PSM.PSMPackage#getSystemProjectBuildFile_FileName()
	 * @model
	 * @generated
	 */
	String getFileName();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectBuildFile#getFileName <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Name</em>' attribute.
	 * @see #getFileName()
	 * @generated
	 */
	void setFileName(String value);

	/**
	 * Returns the value of the '<em><b>System Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>System Project Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>System Project Name</em>' attribute.
	 * @see #setSystemProjectName(String)
	 * @see PSM.PSMPackage#getSystemProjectBuildFile_SystemProjectName()
	 * @model
	 * @generated
	 */
	String getSystemProjectName();

	/**
	 * Sets the value of the '{@link PSM.SystemProjectBuildFile#getSystemProjectName <em>System Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>System Project Name</em>' attribute.
	 * @see #getSystemProjectName()
	 * @generated
	 */
	void setSystemProjectName(String value);

	/**
	 * Returns the value of the '<em><b>Projects</b></em>' reference list.
	 * The list contents are of type {@link PSM.MicroserviceProjectArtifactsModel}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Projects</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Projects</em>' reference list.
	 * @see PSM.PSMPackage#getSystemProjectBuildFile_Projects()
	 * @model required="true"
	 * @generated
	 */
	EList<MicroserviceProjectArtifactsModel> getProjects();

} // SystemProjectBuildFile
