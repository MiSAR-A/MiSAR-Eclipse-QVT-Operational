/**
 */
package PSM.util;

import PSM.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see PSM.PSMPackage
 * @generated
 */
public class PSMSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PSMPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PSMSwitch() {
		if (modelPackage == null) {
			modelPackage = PSMPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case PSMPackage.ROOT_PSM: {
				RootPSM rootPSM = (RootPSM)theEObject;
				T result = caseRootPSM(rootPSM);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL: {
				SystemProjectArtifactsModel systemProjectArtifactsModel = (SystemProjectArtifactsModel)theEObject;
				T result = caseSystemProjectArtifactsModel(systemProjectArtifactsModel);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.DOCKER_COMPOSE_FILE: {
				DockerComposeFile dockerComposeFile = (DockerComposeFile)theEObject;
				T result = caseDockerComposeFile(dockerComposeFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.CONTAINER_DEFINITION: {
				ContainerDefinition containerDefinition = (ContainerDefinition)theEObject;
				T result = caseContainerDefinition(containerDefinition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.PORTS_FIELD: {
				PortsField portsField = (PortsField)theEObject;
				T result = casePortsField(portsField);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.CONTAINER_LINK: {
				ContainerLink containerLink = (ContainerLink)theEObject;
				T result = caseContainerLink(containerLink);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.DOCKER_FILE: {
				DockerFile dockerFile = (DockerFile)theEObject;
				T result = caseDockerFile(dockerFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE: {
				SystemProjectBuildFile systemProjectBuildFile = (SystemProjectBuildFile)theEObject;
				T result = caseSystemProjectBuildFile(systemProjectBuildFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL: {
				MicroserviceProjectArtifactsModel microserviceProjectArtifactsModel = (MicroserviceProjectArtifactsModel)theEObject;
				T result = caseMicroserviceProjectArtifactsModel(microserviceProjectArtifactsModel);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE: {
				MicroserviceProjectBuildFile microserviceProjectBuildFile = (MicroserviceProjectBuildFile)theEObject;
				T result = caseMicroserviceProjectBuildFile(microserviceProjectBuildFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.DEPENDENCY_LIBRARY: {
				DependencyLibrary dependencyLibrary = (DependencyLibrary)theEObject;
				T result = caseDependencyLibrary(dependencyLibrary);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.MICROSERVICE_PROJECT_CONFIGURATIONS_FILE: {
				MicroserviceProjectConfigurationsFile microserviceProjectConfigurationsFile = (MicroserviceProjectConfigurationsFile)theEObject;
				T result = caseMicroserviceProjectConfigurationsFile(microserviceProjectConfigurationsFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.CONFIGURATION_PROPERTY: {
				ConfigurationProperty configurationProperty = (ConfigurationProperty)theEObject;
				T result = caseConfigurationProperty(configurationProperty);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.SOURCE_FILE: {
				SourceFile sourceFile = (SourceFile)theEObject;
				T result = caseSourceFile(sourceFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_SOURCE_FILE: {
				JavaSourceFile javaSourceFile = (JavaSourceFile)theEObject;
				T result = caseJavaSourceFile(javaSourceFile);
				if (result == null) result = caseSourceFile(javaSourceFile);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_ELEMENT: {
				JavaElement javaElement = (JavaElement)theEObject;
				T result = caseJavaElement(javaElement);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_ANNOTATION: {
				JavaAnnotation javaAnnotation = (JavaAnnotation)theEObject;
				T result = caseJavaAnnotation(javaAnnotation);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_ANNOTATION_PARAMETER: {
				JavaAnnotationParameter javaAnnotationParameter = (JavaAnnotationParameter)theEObject;
				T result = caseJavaAnnotationParameter(javaAnnotationParameter);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_DATA_TYPE: {
				JavaDataType javaDataType = (JavaDataType)theEObject;
				T result = caseJavaDataType(javaDataType);
				if (result == null) result = caseJavaElement(javaDataType);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_USER_DEFINED_TYPE: {
				JavaUserDefinedType javaUserDefinedType = (JavaUserDefinedType)theEObject;
				T result = caseJavaUserDefinedType(javaUserDefinedType);
				if (result == null) result = caseJavaDataType(javaUserDefinedType);
				if (result == null) result = caseJavaElement(javaUserDefinedType);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_CLASS_TYPE: {
				JavaClassType javaClassType = (JavaClassType)theEObject;
				T result = caseJavaClassType(javaClassType);
				if (result == null) result = caseJavaUserDefinedType(javaClassType);
				if (result == null) result = caseJavaDataType(javaClassType);
				if (result == null) result = caseJavaElement(javaClassType);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_INTERFACE_TYPE: {
				JavaInterfaceType javaInterfaceType = (JavaInterfaceType)theEObject;
				T result = caseJavaInterfaceType(javaInterfaceType);
				if (result == null) result = caseJavaUserDefinedType(javaInterfaceType);
				if (result == null) result = caseJavaDataType(javaInterfaceType);
				if (result == null) result = caseJavaElement(javaInterfaceType);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_METHOD: {
				JavaMethod javaMethod = (JavaMethod)theEObject;
				T result = caseJavaMethod(javaMethod);
				if (result == null) result = caseJavaElement(javaMethod);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case PSMPackage.JAVA_FIELD: {
				JavaField javaField = (JavaField)theEObject;
				T result = caseJavaField(javaField);
				if (result == null) result = caseJavaElement(javaField);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Root PSM</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Root PSM</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRootPSM(RootPSM object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>System Project Artifacts Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>System Project Artifacts Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSystemProjectArtifactsModel(SystemProjectArtifactsModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Docker Compose File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Docker Compose File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDockerComposeFile(DockerComposeFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Container Definition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Container Definition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContainerDefinition(ContainerDefinition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ports Field</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ports Field</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortsField(PortsField object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Container Link</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Container Link</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContainerLink(ContainerLink object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Docker File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Docker File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDockerFile(DockerFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>System Project Build File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>System Project Build File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSystemProjectBuildFile(SystemProjectBuildFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Microservice Project Artifacts Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Microservice Project Artifacts Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMicroserviceProjectArtifactsModel(MicroserviceProjectArtifactsModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Microservice Project Build File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Microservice Project Build File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMicroserviceProjectBuildFile(MicroserviceProjectBuildFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dependency Library</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dependency Library</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDependencyLibrary(DependencyLibrary object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Microservice Project Configurations File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Microservice Project Configurations File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMicroserviceProjectConfigurationsFile(MicroserviceProjectConfigurationsFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Configuration Property</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Configuration Property</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConfigurationProperty(ConfigurationProperty object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Source File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Source File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSourceFile(SourceFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Source File</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Source File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaSourceFile(JavaSourceFile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Element</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Element</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaElement(JavaElement object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Annotation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Annotation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaAnnotation(JavaAnnotation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Annotation Parameter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Annotation Parameter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaAnnotationParameter(JavaAnnotationParameter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Data Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Data Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaDataType(JavaDataType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java User Defined Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java User Defined Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaUserDefinedType(JavaUserDefinedType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Class Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Class Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaClassType(JavaClassType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Interface Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Interface Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaInterfaceType(JavaInterfaceType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Method</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Method</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaMethod(JavaMethod object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Java Field</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Java Field</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseJavaField(JavaField object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //PSMSwitch
