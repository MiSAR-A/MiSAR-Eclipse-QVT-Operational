/**
 */
package PSM.util;

import PSM.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see PSM.PSMPackage
 * @generated
 */
public class PSMAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PSMPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PSMAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PSMPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PSMSwitch<Adapter> modelSwitch =
		new PSMSwitch<Adapter>() {
			@Override
			public Adapter caseRootPSM(RootPSM object) {
				return createRootPSMAdapter();
			}
			@Override
			public Adapter caseSystemProjectArtifactsModel(SystemProjectArtifactsModel object) {
				return createSystemProjectArtifactsModelAdapter();
			}
			@Override
			public Adapter caseDockerComposeFile(DockerComposeFile object) {
				return createDockerComposeFileAdapter();
			}
			@Override
			public Adapter caseContainerDefinition(ContainerDefinition object) {
				return createContainerDefinitionAdapter();
			}
			@Override
			public Adapter casePortsField(PortsField object) {
				return createPortsFieldAdapter();
			}
			@Override
			public Adapter caseContainerLink(ContainerLink object) {
				return createContainerLinkAdapter();
			}
			@Override
			public Adapter caseDockerFile(DockerFile object) {
				return createDockerFileAdapter();
			}
			@Override
			public Adapter caseSystemProjectBuildFile(SystemProjectBuildFile object) {
				return createSystemProjectBuildFileAdapter();
			}
			@Override
			public Adapter caseMicroserviceProjectArtifactsModel(MicroserviceProjectArtifactsModel object) {
				return createMicroserviceProjectArtifactsModelAdapter();
			}
			@Override
			public Adapter caseMicroserviceProjectBuildFile(MicroserviceProjectBuildFile object) {
				return createMicroserviceProjectBuildFileAdapter();
			}
			@Override
			public Adapter caseDependencyLibrary(DependencyLibrary object) {
				return createDependencyLibraryAdapter();
			}
			@Override
			public Adapter caseMicroserviceProjectConfigurationsFile(MicroserviceProjectConfigurationsFile object) {
				return createMicroserviceProjectConfigurationsFileAdapter();
			}
			@Override
			public Adapter caseConfigurationProperty(ConfigurationProperty object) {
				return createConfigurationPropertyAdapter();
			}
			@Override
			public Adapter caseSourceFile(SourceFile object) {
				return createSourceFileAdapter();
			}
			@Override
			public Adapter caseJavaSourceFile(JavaSourceFile object) {
				return createJavaSourceFileAdapter();
			}
			@Override
			public Adapter caseJavaElement(JavaElement object) {
				return createJavaElementAdapter();
			}
			@Override
			public Adapter caseJavaAnnotation(JavaAnnotation object) {
				return createJavaAnnotationAdapter();
			}
			@Override
			public Adapter caseJavaAnnotationParameter(JavaAnnotationParameter object) {
				return createJavaAnnotationParameterAdapter();
			}
			@Override
			public Adapter caseJavaDataType(JavaDataType object) {
				return createJavaDataTypeAdapter();
			}
			@Override
			public Adapter caseJavaUserDefinedType(JavaUserDefinedType object) {
				return createJavaUserDefinedTypeAdapter();
			}
			@Override
			public Adapter caseJavaClassType(JavaClassType object) {
				return createJavaClassTypeAdapter();
			}
			@Override
			public Adapter caseJavaInterfaceType(JavaInterfaceType object) {
				return createJavaInterfaceTypeAdapter();
			}
			@Override
			public Adapter caseJavaMethod(JavaMethod object) {
				return createJavaMethodAdapter();
			}
			@Override
			public Adapter caseJavaField(JavaField object) {
				return createJavaFieldAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link PSM.RootPSM <em>Root PSM</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.RootPSM
	 * @generated
	 */
	public Adapter createRootPSMAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.SystemProjectArtifactsModel <em>System Project Artifacts Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.SystemProjectArtifactsModel
	 * @generated
	 */
	public Adapter createSystemProjectArtifactsModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.DockerComposeFile <em>Docker Compose File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.DockerComposeFile
	 * @generated
	 */
	public Adapter createDockerComposeFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.ContainerDefinition <em>Container Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.ContainerDefinition
	 * @generated
	 */
	public Adapter createContainerDefinitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.PortsField <em>Ports Field</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.PortsField
	 * @generated
	 */
	public Adapter createPortsFieldAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.ContainerLink <em>Container Link</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.ContainerLink
	 * @generated
	 */
	public Adapter createContainerLinkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.DockerFile <em>Docker File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.DockerFile
	 * @generated
	 */
	public Adapter createDockerFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.SystemProjectBuildFile <em>System Project Build File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.SystemProjectBuildFile
	 * @generated
	 */
	public Adapter createSystemProjectBuildFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.MicroserviceProjectArtifactsModel <em>Microservice Project Artifacts Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.MicroserviceProjectArtifactsModel
	 * @generated
	 */
	public Adapter createMicroserviceProjectArtifactsModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.MicroserviceProjectBuildFile <em>Microservice Project Build File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.MicroserviceProjectBuildFile
	 * @generated
	 */
	public Adapter createMicroserviceProjectBuildFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.DependencyLibrary <em>Dependency Library</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.DependencyLibrary
	 * @generated
	 */
	public Adapter createDependencyLibraryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.MicroserviceProjectConfigurationsFile <em>Microservice Project Configurations File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.MicroserviceProjectConfigurationsFile
	 * @generated
	 */
	public Adapter createMicroserviceProjectConfigurationsFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.ConfigurationProperty <em>Configuration Property</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.ConfigurationProperty
	 * @generated
	 */
	public Adapter createConfigurationPropertyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.SourceFile <em>Source File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.SourceFile
	 * @generated
	 */
	public Adapter createSourceFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaSourceFile <em>Java Source File</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaSourceFile
	 * @generated
	 */
	public Adapter createJavaSourceFileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaElement <em>Java Element</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaElement
	 * @generated
	 */
	public Adapter createJavaElementAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaAnnotation <em>Java Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaAnnotation
	 * @generated
	 */
	public Adapter createJavaAnnotationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaAnnotationParameter <em>Java Annotation Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaAnnotationParameter
	 * @generated
	 */
	public Adapter createJavaAnnotationParameterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaDataType <em>Java Data Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaDataType
	 * @generated
	 */
	public Adapter createJavaDataTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaUserDefinedType <em>Java User Defined Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaUserDefinedType
	 * @generated
	 */
	public Adapter createJavaUserDefinedTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaClassType <em>Java Class Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaClassType
	 * @generated
	 */
	public Adapter createJavaClassTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaInterfaceType <em>Java Interface Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaInterfaceType
	 * @generated
	 */
	public Adapter createJavaInterfaceTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaMethod <em>Java Method</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaMethod
	 * @generated
	 */
	public Adapter createJavaMethodAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link PSM.JavaField <em>Java Field</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see PSM.JavaField
	 * @generated
	 */
	public Adapter createJavaFieldAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PSMAdapterFactory
