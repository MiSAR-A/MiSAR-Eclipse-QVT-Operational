/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.JavaDataType#isIsPrimitive <em>Is Primitive</em>}</li>
 *   <li>{@link PSM.JavaDataType#getJsonSchema <em>Json Schema</em>}</li>
 *   <li>{@link PSM.JavaDataType#getSuper <em>Super</em>}</li>
 *   <li>{@link PSM.JavaDataType#getImports <em>Imports</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getJavaDataType()
 * @model
 * @generated
 */
public interface JavaDataType extends JavaElement {
	/**
	 * Returns the value of the '<em><b>Is Primitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Primitive</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Primitive</em>' attribute.
	 * @see #setIsPrimitive(boolean)
	 * @see PSM.PSMPackage#getJavaDataType_IsPrimitive()
	 * @model
	 * @generated
	 */
	boolean isIsPrimitive();

	/**
	 * Sets the value of the '{@link PSM.JavaDataType#isIsPrimitive <em>Is Primitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Primitive</em>' attribute.
	 * @see #isIsPrimitive()
	 * @generated
	 */
	void setIsPrimitive(boolean value);

	/**
	 * Returns the value of the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Json Schema</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Json Schema</em>' attribute.
	 * @see #setJsonSchema(String)
	 * @see PSM.PSMPackage#getJavaDataType_JsonSchema()
	 * @model
	 * @generated
	 */
	String getJsonSchema();

	/**
	 * Sets the value of the '{@link PSM.JavaDataType#getJsonSchema <em>Json Schema</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Json Schema</em>' attribute.
	 * @see #getJsonSchema()
	 * @generated
	 */
	void setJsonSchema(String value);

	/**
	 * Returns the value of the '<em><b>Super</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Super</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Super</em>' reference.
	 * @see #setSuper(JavaDataType)
	 * @see PSM.PSMPackage#getJavaDataType_Super()
	 * @model
	 * @generated
	 */
	JavaDataType getSuper();

	/**
	 * Sets the value of the '{@link PSM.JavaDataType#getSuper <em>Super</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Super</em>' reference.
	 * @see #getSuper()
	 * @generated
	 */
	void setSuper(JavaDataType value);

	/**
	 * Returns the value of the '<em><b>Imports</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaDataType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Imports</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Imports</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaDataType_Imports()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaDataType> getImports();

} // JavaDataType
