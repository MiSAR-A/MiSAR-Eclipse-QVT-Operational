/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container Link</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.ContainerLink#getFromServiceName <em>From Service Name</em>}</li>
 *   <li>{@link PSM.ContainerLink#getToServiceName <em>To Service Name</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getContainerLink()
 * @model
 * @generated
 */
public interface ContainerLink extends EObject {
	/**
	 * Returns the value of the '<em><b>From Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From Service Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From Service Name</em>' attribute.
	 * @see #setFromServiceName(String)
	 * @see PSM.PSMPackage#getContainerLink_FromServiceName()
	 * @model
	 * @generated
	 */
	String getFromServiceName();

	/**
	 * Sets the value of the '{@link PSM.ContainerLink#getFromServiceName <em>From Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From Service Name</em>' attribute.
	 * @see #getFromServiceName()
	 * @generated
	 */
	void setFromServiceName(String value);

	/**
	 * Returns the value of the '<em><b>To Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To Service Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To Service Name</em>' attribute.
	 * @see #setToServiceName(String)
	 * @see PSM.PSMPackage#getContainerLink_ToServiceName()
	 * @model
	 * @generated
	 */
	String getToServiceName();

	/**
	 * Sets the value of the '{@link PSM.ContainerLink#getToServiceName <em>To Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To Service Name</em>' attribute.
	 * @see #getToServiceName()
	 * @generated
	 */
	void setToServiceName(String value);

} // ContainerLink
