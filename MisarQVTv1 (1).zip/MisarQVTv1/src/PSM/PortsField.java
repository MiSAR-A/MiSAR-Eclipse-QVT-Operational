/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ports Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.PortsField#getHostPortField <em>Host Port Field</em>}</li>
 *   <li>{@link PSM.PortsField#getContainerPortField <em>Container Port Field</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getPortsField()
 * @model
 * @generated
 */
public interface PortsField extends EObject {
	/**
	 * Returns the value of the '<em><b>Host Port Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Host Port Field</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Host Port Field</em>' attribute.
	 * @see #setHostPortField(String)
	 * @see PSM.PSMPackage#getPortsField_HostPortField()
	 * @model
	 * @generated
	 */
	String getHostPortField();

	/**
	 * Sets the value of the '{@link PSM.PortsField#getHostPortField <em>Host Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Host Port Field</em>' attribute.
	 * @see #getHostPortField()
	 * @generated
	 */
	void setHostPortField(String value);

	/**
	 * Returns the value of the '<em><b>Container Port Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Container Port Field</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Container Port Field</em>' attribute.
	 * @see #setContainerPortField(String)
	 * @see PSM.PSMPackage#getPortsField_ContainerPortField()
	 * @model
	 * @generated
	 */
	String getContainerPortField();

	/**
	 * Sets the value of the '{@link PSM.PortsField#getContainerPortField <em>Container Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Container Port Field</em>' attribute.
	 * @see #getContainerPortField()
	 * @generated
	 */
	void setContainerPortField(String value);

} // PortsField
