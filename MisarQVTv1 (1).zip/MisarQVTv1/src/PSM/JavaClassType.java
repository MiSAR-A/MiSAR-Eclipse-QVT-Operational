/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Class Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.JavaClassType#getImplements <em>Implements</em>}</li>
 *   <li>{@link PSM.JavaClassType#getFields <em>Fields</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getJavaClassType()
 * @model
 * @generated
 */
public interface JavaClassType extends JavaUserDefinedType {
	/**
	 * Returns the value of the '<em><b>Implements</b></em>' reference list.
	 * The list contents are of type {@link PSM.JavaInterfaceType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Implements</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Implements</em>' reference list.
	 * @see PSM.PSMPackage#getJavaClassType_Implements()
	 * @model
	 * @generated
	 */
	EList<JavaInterfaceType> getImplements();

	/**
	 * Returns the value of the '<em><b>Fields</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaField}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fields</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fields</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaClassType_Fields()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaField> getFields();

} // JavaClassType
