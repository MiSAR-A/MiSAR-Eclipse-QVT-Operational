/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Source File</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PSM.PSMPackage#getSourceFile()
 * @model
 * @generated
 */
public interface SourceFile extends EObject {
} // SourceFile
