/**
 */
package PSM;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see PSM.PSMFactory
 * @model kind="package"
 * @generated
 */
public interface PSMPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "PSM";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://localhost/mdd/PSM.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "PSM";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PSMPackage eINSTANCE = PSM.impl.PSMPackageImpl.init();

	/**
	 * The meta object id for the '{@link PSM.impl.RootPSMImpl <em>Root PSM</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.RootPSMImpl
	 * @see PSM.impl.PSMPackageImpl#getRootPSM()
	 * @generated
	 */
	int ROOT_PSM = 0;

	/**
	 * The feature id for the '<em><b>System</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PSM__SYSTEM = 0;

	/**
	 * The number of structural features of the '<em>Root PSM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PSM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Root PSM</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOT_PSM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.SystemProjectArtifactsModelImpl <em>System Project Artifacts Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.SystemProjectArtifactsModelImpl
	 * @see PSM.impl.PSMPackageImpl#getSystemProjectArtifactsModel()
	 * @generated
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL = 1;

	/**
	 * The feature id for the '<em><b>Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME = 0;

	/**
	 * The feature id for the '<em><b>Artifacts Repository URI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI = 1;

	/**
	 * The feature id for the '<em><b>Docker</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER = 2;

	/**
	 * The feature id for the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD = 3;

	/**
	 * The number of structural features of the '<em>System Project Artifacts Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>System Project Artifacts Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_ARTIFACTS_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.DockerComposeFileImpl <em>Docker Compose File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.DockerComposeFileImpl
	 * @see PSM.impl.PSMPackageImpl#getDockerComposeFile()
	 * @generated
	 */
	int DOCKER_COMPOSE_FILE = 2;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_COMPOSE_FILE__FILE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Containers</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_COMPOSE_FILE__CONTAINERS = 1;

	/**
	 * The number of structural features of the '<em>Docker Compose File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_COMPOSE_FILE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Docker Compose File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_COMPOSE_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.ContainerDefinitionImpl <em>Container Definition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.ContainerDefinitionImpl
	 * @see PSM.impl.PSMPackageImpl#getContainerDefinition()
	 * @generated
	 */
	int CONTAINER_DEFINITION = 3;

	/**
	 * The feature id for the '<em><b>Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__SERVICE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Image Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__IMAGE_FIELD = 1;

	/**
	 * The feature id for the '<em><b>Build Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__BUILD_FIELD = 2;

	/**
	 * The feature id for the '<em><b>Logging Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__LOGGING_FIELD = 3;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__PORTS = 4;

	/**
	 * The feature id for the '<em><b>Links</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__LINKS = 5;

	/**
	 * The feature id for the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__BUILD = 6;

	/**
	 * The feature id for the '<em><b>Project</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION__PROJECT = 7;

	/**
	 * The number of structural features of the '<em>Container Definition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Container Definition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_DEFINITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.PortsFieldImpl <em>Ports Field</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.PortsFieldImpl
	 * @see PSM.impl.PSMPackageImpl#getPortsField()
	 * @generated
	 */
	int PORTS_FIELD = 4;

	/**
	 * The feature id for the '<em><b>Host Port Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FIELD__HOST_PORT_FIELD = 0;

	/**
	 * The feature id for the '<em><b>Container Port Field</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FIELD__CONTAINER_PORT_FIELD = 1;

	/**
	 * The number of structural features of the '<em>Ports Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FIELD_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Ports Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORTS_FIELD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.ContainerLinkImpl <em>Container Link</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.ContainerLinkImpl
	 * @see PSM.impl.PSMPackageImpl#getContainerLink()
	 * @generated
	 */
	int CONTAINER_LINK = 5;

	/**
	 * The feature id for the '<em><b>From Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_LINK__FROM_SERVICE_NAME = 0;

	/**
	 * The feature id for the '<em><b>To Service Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_LINK__TO_SERVICE_NAME = 1;

	/**
	 * The number of structural features of the '<em>Container Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_LINK_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Container Link</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINER_LINK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.DockerFileImpl <em>Docker File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.DockerFileImpl
	 * @see PSM.impl.PSMPackageImpl#getDockerFile()
	 * @generated
	 */
	int DOCKER_FILE = 6;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_FILE__FILE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Command FROM</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_FILE__COMMAND_FROM = 1;

	/**
	 * The feature id for the '<em><b>Command EXPOSE</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_FILE__COMMAND_EXPOSE = 2;

	/**
	 * The number of structural features of the '<em>Docker File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_FILE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Docker File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCKER_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.SystemProjectBuildFileImpl <em>System Project Build File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.SystemProjectBuildFileImpl
	 * @see PSM.impl.PSMPackageImpl#getSystemProjectBuildFile()
	 * @generated
	 */
	int SYSTEM_PROJECT_BUILD_FILE = 7;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_BUILD_FILE__FILE_NAME = 0;

	/**
	 * The feature id for the '<em><b>System Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME = 1;

	/**
	 * The feature id for the '<em><b>Projects</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_BUILD_FILE__PROJECTS = 2;

	/**
	 * The number of structural features of the '<em>System Project Build File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_BUILD_FILE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>System Project Build File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_PROJECT_BUILD_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.MicroserviceProjectArtifactsModelImpl <em>Microservice Project Artifacts Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.MicroserviceProjectArtifactsModelImpl
	 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectArtifactsModel()
	 * @generated
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL = 8;

	/**
	 * The feature id for the '<em><b>Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME = 0;

	/**
	 * The feature id for the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD = 1;

	/**
	 * The feature id for the '<em><b>Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG = 2;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES = 3;

	/**
	 * The number of structural features of the '<em>Microservice Project Artifacts Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Microservice Project Artifacts Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_ARTIFACTS_MODEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.MicroserviceProjectBuildFileImpl <em>Microservice Project Build File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.MicroserviceProjectBuildFileImpl
	 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectBuildFile()
	 * @generated
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE = 9;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME = 1;

	/**
	 * The feature id for the '<em><b>Dependencies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES = 2;

	/**
	 * The number of structural features of the '<em>Microservice Project Build File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Microservice Project Build File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_BUILD_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.DependencyLibraryImpl <em>Dependency Library</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.DependencyLibraryImpl
	 * @see PSM.impl.PSMPackageImpl#getDependencyLibrary()
	 * @generated
	 */
	int DEPENDENCY_LIBRARY = 10;

	/**
	 * The feature id for the '<em><b>Library Group Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME = 0;

	/**
	 * The feature id for the '<em><b>Library Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_LIBRARY__LIBRARY_NAME = 1;

	/**
	 * The number of structural features of the '<em>Dependency Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_LIBRARY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Dependency Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPENDENCY_LIBRARY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.MicroserviceProjectConfigurationsFileImpl <em>Microservice Project Configurations File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.MicroserviceProjectConfigurationsFileImpl
	 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectConfigurationsFile()
	 * @generated
	 */
	int MICROSERVICE_PROJECT_CONFIGURATIONS_FILE = 11;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__FILE_NAME = 0;

	/**
	 * The feature id for the '<em><b>Properties</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__PROPERTIES = 1;

	/**
	 * The number of structural features of the '<em>Microservice Project Configurations File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_CONFIGURATIONS_FILE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Microservice Project Configurations File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROSERVICE_PROJECT_CONFIGURATIONS_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.ConfigurationPropertyImpl <em>Configuration Property</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.ConfigurationPropertyImpl
	 * @see PSM.impl.PSMPackageImpl#getConfigurationProperty()
	 * @generated
	 */
	int CONFIGURATION_PROPERTY = 12;

	/**
	 * The feature id for the '<em><b>Fully Qualified Property Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME = 0;

	/**
	 * The feature id for the '<em><b>Property Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_PROPERTY__PROPERTY_VALUE = 1;

	/**
	 * The number of structural features of the '<em>Configuration Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_PROPERTY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Configuration Property</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_PROPERTY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.SourceFileImpl <em>Source File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.SourceFileImpl
	 * @see PSM.impl.PSMPackageImpl#getSourceFile()
	 * @generated
	 */
	int SOURCE_FILE = 13;

	/**
	 * The number of structural features of the '<em>Source File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE_FILE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Source File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOURCE_FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaSourceFileImpl <em>Java Source File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaSourceFileImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaSourceFile()
	 * @generated
	 */
	int JAVA_SOURCE_FILE = 14;

	/**
	 * The feature id for the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_SOURCE_FILE__FILE_NAME = SOURCE_FILE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_SOURCE_FILE__ELEMENTS = SOURCE_FILE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Java Source File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_SOURCE_FILE_FEATURE_COUNT = SOURCE_FILE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Java Source File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_SOURCE_FILE_OPERATION_COUNT = SOURCE_FILE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaElementImpl <em>Java Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaElementImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaElement()
	 * @generated
	 */
	int JAVA_ELEMENT = 15;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT__ELEMENT_NAME = 0;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT__ELEMENT_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT__LINE_NUMBER = 2;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT__ANNOTATIONS = 3;

	/**
	 * The number of structural features of the '<em>Java Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Java Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ELEMENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaAnnotationImpl <em>Java Annotation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaAnnotationImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaAnnotation()
	 * @generated
	 */
	int JAVA_ANNOTATION = 16;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION__LINE_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Annotation Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION__ANNOTATION_NAME = 1;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION__PARAMETERS = 2;

	/**
	 * The number of structural features of the '<em>Java Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Java Annotation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaAnnotationParameterImpl <em>Java Annotation Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaAnnotationParameterImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaAnnotationParameter()
	 * @generated
	 */
	int JAVA_ANNOTATION_PARAMETER = 17;

	/**
	 * The feature id for the '<em><b>Parameter Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_PARAMETER__PARAMETER_NAME = 0;

	/**
	 * The feature id for the '<em><b>Parameter Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_PARAMETER__PARAMETER_VALUE = 1;

	/**
	 * The number of structural features of the '<em>Java Annotation Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_PARAMETER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Java Annotation Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_ANNOTATION_PARAMETER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaDataTypeImpl <em>Java Data Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaDataTypeImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaDataType()
	 * @generated
	 */
	int JAVA_DATA_TYPE = 18;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__ELEMENT_NAME = JAVA_ELEMENT__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__ELEMENT_TYPE = JAVA_ELEMENT__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__LINE_NUMBER = JAVA_ELEMENT__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__ANNOTATIONS = JAVA_ELEMENT__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Is Primitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__IS_PRIMITIVE = JAVA_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__JSON_SCHEMA = JAVA_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Super</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__SUPER = JAVA_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE__IMPORTS = JAVA_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Java Data Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE_FEATURE_COUNT = JAVA_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Java Data Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_DATA_TYPE_OPERATION_COUNT = JAVA_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaUserDefinedTypeImpl <em>Java User Defined Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaUserDefinedTypeImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaUserDefinedType()
	 * @generated
	 */
	int JAVA_USER_DEFINED_TYPE = 19;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__ELEMENT_NAME = JAVA_DATA_TYPE__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__ELEMENT_TYPE = JAVA_DATA_TYPE__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__LINE_NUMBER = JAVA_DATA_TYPE__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__ANNOTATIONS = JAVA_DATA_TYPE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Is Primitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__IS_PRIMITIVE = JAVA_DATA_TYPE__IS_PRIMITIVE;

	/**
	 * The feature id for the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__JSON_SCHEMA = JAVA_DATA_TYPE__JSON_SCHEMA;

	/**
	 * The feature id for the '<em><b>Super</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__SUPER = JAVA_DATA_TYPE__SUPER;

	/**
	 * The feature id for the '<em><b>Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE__IMPORTS = JAVA_DATA_TYPE__IMPORTS;

	/**
	 * The number of structural features of the '<em>Java User Defined Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE_FEATURE_COUNT = JAVA_DATA_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Java User Defined Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_USER_DEFINED_TYPE_OPERATION_COUNT = JAVA_DATA_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaClassTypeImpl <em>Java Class Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaClassTypeImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaClassType()
	 * @generated
	 */
	int JAVA_CLASS_TYPE = 20;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__ELEMENT_NAME = JAVA_USER_DEFINED_TYPE__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__ELEMENT_TYPE = JAVA_USER_DEFINED_TYPE__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__LINE_NUMBER = JAVA_USER_DEFINED_TYPE__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__ANNOTATIONS = JAVA_USER_DEFINED_TYPE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Is Primitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__IS_PRIMITIVE = JAVA_USER_DEFINED_TYPE__IS_PRIMITIVE;

	/**
	 * The feature id for the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__JSON_SCHEMA = JAVA_USER_DEFINED_TYPE__JSON_SCHEMA;

	/**
	 * The feature id for the '<em><b>Super</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__SUPER = JAVA_USER_DEFINED_TYPE__SUPER;

	/**
	 * The feature id for the '<em><b>Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__IMPORTS = JAVA_USER_DEFINED_TYPE__IMPORTS;

	/**
	 * The feature id for the '<em><b>Implements</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__IMPLEMENTS = JAVA_USER_DEFINED_TYPE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Fields</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE__FIELDS = JAVA_USER_DEFINED_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Java Class Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE_FEATURE_COUNT = JAVA_USER_DEFINED_TYPE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Java Class Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_CLASS_TYPE_OPERATION_COUNT = JAVA_USER_DEFINED_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaInterfaceTypeImpl <em>Java Interface Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaInterfaceTypeImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaInterfaceType()
	 * @generated
	 */
	int JAVA_INTERFACE_TYPE = 21;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__ELEMENT_NAME = JAVA_USER_DEFINED_TYPE__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__ELEMENT_TYPE = JAVA_USER_DEFINED_TYPE__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__LINE_NUMBER = JAVA_USER_DEFINED_TYPE__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__ANNOTATIONS = JAVA_USER_DEFINED_TYPE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Is Primitive</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__IS_PRIMITIVE = JAVA_USER_DEFINED_TYPE__IS_PRIMITIVE;

	/**
	 * The feature id for the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__JSON_SCHEMA = JAVA_USER_DEFINED_TYPE__JSON_SCHEMA;

	/**
	 * The feature id for the '<em><b>Super</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__SUPER = JAVA_USER_DEFINED_TYPE__SUPER;

	/**
	 * The feature id for the '<em><b>Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE__IMPORTS = JAVA_USER_DEFINED_TYPE__IMPORTS;

	/**
	 * The number of structural features of the '<em>Java Interface Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE_FEATURE_COUNT = JAVA_USER_DEFINED_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Java Interface Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_INTERFACE_TYPE_OPERATION_COUNT = JAVA_USER_DEFINED_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaMethodImpl <em>Java Method</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaMethodImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaMethod()
	 * @generated
	 */
	int JAVA_METHOD = 22;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__ELEMENT_NAME = JAVA_ELEMENT__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__ELEMENT_TYPE = JAVA_ELEMENT__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__LINE_NUMBER = JAVA_ELEMENT__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__ANNOTATIONS = JAVA_ELEMENT__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Fields</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__FIELDS = JAVA_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Invokes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__INVOKES = JAVA_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Returns</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__RETURNS = JAVA_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__PARAMETERS = JAVA_ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Owner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__OWNER = JAVA_ELEMENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Args</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD__ARGS = JAVA_ELEMENT_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Java Method</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD_FEATURE_COUNT = JAVA_ELEMENT_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Java Method</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_METHOD_OPERATION_COUNT = JAVA_ELEMENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link PSM.impl.JavaFieldImpl <em>Java Field</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see PSM.impl.JavaFieldImpl
	 * @see PSM.impl.PSMPackageImpl#getJavaField()
	 * @generated
	 */
	int JAVA_FIELD = 23;

	/**
	 * The feature id for the '<em><b>Element Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__ELEMENT_NAME = JAVA_ELEMENT__ELEMENT_NAME;

	/**
	 * The feature id for the '<em><b>Element Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__ELEMENT_TYPE = JAVA_ELEMENT__ELEMENT_TYPE;

	/**
	 * The feature id for the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__LINE_NUMBER = JAVA_ELEMENT__LINE_NUMBER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__ANNOTATIONS = JAVA_ELEMENT__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Json Schema</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__JSON_SCHEMA = JAVA_ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD__TYPE = JAVA_ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Java Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD_FEATURE_COUNT = JAVA_ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Java Field</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_FIELD_OPERATION_COUNT = JAVA_ELEMENT_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link PSM.RootPSM <em>Root PSM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Root PSM</em>'.
	 * @see PSM.RootPSM
	 * @generated
	 */
	EClass getRootPSM();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.RootPSM#getSystem <em>System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>System</em>'.
	 * @see PSM.RootPSM#getSystem()
	 * @see #getRootPSM()
	 * @generated
	 */
	EReference getRootPSM_System();

	/**
	 * Returns the meta object for class '{@link PSM.SystemProjectArtifactsModel <em>System Project Artifacts Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>System Project Artifacts Model</em>'.
	 * @see PSM.SystemProjectArtifactsModel
	 * @generated
	 */
	EClass getSystemProjectArtifactsModel();

	/**
	 * Returns the meta object for the attribute '{@link PSM.SystemProjectArtifactsModel#getProjectName <em>Project Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Project Name</em>'.
	 * @see PSM.SystemProjectArtifactsModel#getProjectName()
	 * @see #getSystemProjectArtifactsModel()
	 * @generated
	 */
	EAttribute getSystemProjectArtifactsModel_ProjectName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.SystemProjectArtifactsModel#getArtifactsRepositoryURI <em>Artifacts Repository URI</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Artifacts Repository URI</em>'.
	 * @see PSM.SystemProjectArtifactsModel#getArtifactsRepositoryURI()
	 * @see #getSystemProjectArtifactsModel()
	 * @generated
	 */
	EAttribute getSystemProjectArtifactsModel_ArtifactsRepositoryURI();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.SystemProjectArtifactsModel#getDocker <em>Docker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Docker</em>'.
	 * @see PSM.SystemProjectArtifactsModel#getDocker()
	 * @see #getSystemProjectArtifactsModel()
	 * @generated
	 */
	EReference getSystemProjectArtifactsModel_Docker();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.SystemProjectArtifactsModel#getBuild <em>Build</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Build</em>'.
	 * @see PSM.SystemProjectArtifactsModel#getBuild()
	 * @see #getSystemProjectArtifactsModel()
	 * @generated
	 */
	EReference getSystemProjectArtifactsModel_Build();

	/**
	 * Returns the meta object for class '{@link PSM.DockerComposeFile <em>Docker Compose File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Docker Compose File</em>'.
	 * @see PSM.DockerComposeFile
	 * @generated
	 */
	EClass getDockerComposeFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DockerComposeFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.DockerComposeFile#getFileName()
	 * @see #getDockerComposeFile()
	 * @generated
	 */
	EAttribute getDockerComposeFile_FileName();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.DockerComposeFile#getContainers <em>Containers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containers</em>'.
	 * @see PSM.DockerComposeFile#getContainers()
	 * @see #getDockerComposeFile()
	 * @generated
	 */
	EReference getDockerComposeFile_Containers();

	/**
	 * Returns the meta object for class '{@link PSM.ContainerDefinition <em>Container Definition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container Definition</em>'.
	 * @see PSM.ContainerDefinition
	 * @generated
	 */
	EClass getContainerDefinition();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerDefinition#getServiceName <em>Service Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service Name</em>'.
	 * @see PSM.ContainerDefinition#getServiceName()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EAttribute getContainerDefinition_ServiceName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerDefinition#getImageField <em>Image Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image Field</em>'.
	 * @see PSM.ContainerDefinition#getImageField()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EAttribute getContainerDefinition_ImageField();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerDefinition#getBuildField <em>Build Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Build Field</em>'.
	 * @see PSM.ContainerDefinition#getBuildField()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EAttribute getContainerDefinition_BuildField();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerDefinition#isLoggingField <em>Logging Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Logging Field</em>'.
	 * @see PSM.ContainerDefinition#isLoggingField()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EAttribute getContainerDefinition_LoggingField();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.ContainerDefinition#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ports</em>'.
	 * @see PSM.ContainerDefinition#getPorts()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EReference getContainerDefinition_Ports();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.ContainerDefinition#getLinks <em>Links</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Links</em>'.
	 * @see PSM.ContainerDefinition#getLinks()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EReference getContainerDefinition_Links();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.ContainerDefinition#getBuild <em>Build</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Build</em>'.
	 * @see PSM.ContainerDefinition#getBuild()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EReference getContainerDefinition_Build();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.ContainerDefinition#getProject <em>Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Project</em>'.
	 * @see PSM.ContainerDefinition#getProject()
	 * @see #getContainerDefinition()
	 * @generated
	 */
	EReference getContainerDefinition_Project();

	/**
	 * Returns the meta object for class '{@link PSM.PortsField <em>Ports Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ports Field</em>'.
	 * @see PSM.PortsField
	 * @generated
	 */
	EClass getPortsField();

	/**
	 * Returns the meta object for the attribute '{@link PSM.PortsField#getHostPortField <em>Host Port Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Host Port Field</em>'.
	 * @see PSM.PortsField#getHostPortField()
	 * @see #getPortsField()
	 * @generated
	 */
	EAttribute getPortsField_HostPortField();

	/**
	 * Returns the meta object for the attribute '{@link PSM.PortsField#getContainerPortField <em>Container Port Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Container Port Field</em>'.
	 * @see PSM.PortsField#getContainerPortField()
	 * @see #getPortsField()
	 * @generated
	 */
	EAttribute getPortsField_ContainerPortField();

	/**
	 * Returns the meta object for class '{@link PSM.ContainerLink <em>Container Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container Link</em>'.
	 * @see PSM.ContainerLink
	 * @generated
	 */
	EClass getContainerLink();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerLink#getFromServiceName <em>From Service Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>From Service Name</em>'.
	 * @see PSM.ContainerLink#getFromServiceName()
	 * @see #getContainerLink()
	 * @generated
	 */
	EAttribute getContainerLink_FromServiceName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ContainerLink#getToServiceName <em>To Service Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>To Service Name</em>'.
	 * @see PSM.ContainerLink#getToServiceName()
	 * @see #getContainerLink()
	 * @generated
	 */
	EAttribute getContainerLink_ToServiceName();

	/**
	 * Returns the meta object for class '{@link PSM.DockerFile <em>Docker File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Docker File</em>'.
	 * @see PSM.DockerFile
	 * @generated
	 */
	EClass getDockerFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DockerFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.DockerFile#getFileName()
	 * @see #getDockerFile()
	 * @generated
	 */
	EAttribute getDockerFile_FileName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DockerFile#getCommandFROM <em>Command FROM</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Command FROM</em>'.
	 * @see PSM.DockerFile#getCommandFROM()
	 * @see #getDockerFile()
	 * @generated
	 */
	EAttribute getDockerFile_CommandFROM();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DockerFile#getCommandEXPOSE <em>Command EXPOSE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Command EXPOSE</em>'.
	 * @see PSM.DockerFile#getCommandEXPOSE()
	 * @see #getDockerFile()
	 * @generated
	 */
	EAttribute getDockerFile_CommandEXPOSE();

	/**
	 * Returns the meta object for class '{@link PSM.SystemProjectBuildFile <em>System Project Build File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>System Project Build File</em>'.
	 * @see PSM.SystemProjectBuildFile
	 * @generated
	 */
	EClass getSystemProjectBuildFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.SystemProjectBuildFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.SystemProjectBuildFile#getFileName()
	 * @see #getSystemProjectBuildFile()
	 * @generated
	 */
	EAttribute getSystemProjectBuildFile_FileName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.SystemProjectBuildFile#getSystemProjectName <em>System Project Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>System Project Name</em>'.
	 * @see PSM.SystemProjectBuildFile#getSystemProjectName()
	 * @see #getSystemProjectBuildFile()
	 * @generated
	 */
	EAttribute getSystemProjectBuildFile_SystemProjectName();

	/**
	 * Returns the meta object for the reference list '{@link PSM.SystemProjectBuildFile#getProjects <em>Projects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Projects</em>'.
	 * @see PSM.SystemProjectBuildFile#getProjects()
	 * @see #getSystemProjectBuildFile()
	 * @generated
	 */
	EReference getSystemProjectBuildFile_Projects();

	/**
	 * Returns the meta object for class '{@link PSM.MicroserviceProjectArtifactsModel <em>Microservice Project Artifacts Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservice Project Artifacts Model</em>'.
	 * @see PSM.MicroserviceProjectArtifactsModel
	 * @generated
	 */
	EClass getMicroserviceProjectArtifactsModel();

	/**
	 * Returns the meta object for the attribute '{@link PSM.MicroserviceProjectArtifactsModel#getProjectName <em>Project Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Project Name</em>'.
	 * @see PSM.MicroserviceProjectArtifactsModel#getProjectName()
	 * @see #getMicroserviceProjectArtifactsModel()
	 * @generated
	 */
	EAttribute getMicroserviceProjectArtifactsModel_ProjectName();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.MicroserviceProjectArtifactsModel#getBuild <em>Build</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Build</em>'.
	 * @see PSM.MicroserviceProjectArtifactsModel#getBuild()
	 * @see #getMicroserviceProjectArtifactsModel()
	 * @generated
	 */
	EReference getMicroserviceProjectArtifactsModel_Build();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.MicroserviceProjectArtifactsModel#getConfig <em>Config</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Config</em>'.
	 * @see PSM.MicroserviceProjectArtifactsModel#getConfig()
	 * @see #getMicroserviceProjectArtifactsModel()
	 * @generated
	 */
	EReference getMicroserviceProjectArtifactsModel_Config();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.MicroserviceProjectArtifactsModel#getSources <em>Sources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sources</em>'.
	 * @see PSM.MicroserviceProjectArtifactsModel#getSources()
	 * @see #getMicroserviceProjectArtifactsModel()
	 * @generated
	 */
	EReference getMicroserviceProjectArtifactsModel_Sources();

	/**
	 * Returns the meta object for class '{@link PSM.MicroserviceProjectBuildFile <em>Microservice Project Build File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservice Project Build File</em>'.
	 * @see PSM.MicroserviceProjectBuildFile
	 * @generated
	 */
	EClass getMicroserviceProjectBuildFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.MicroserviceProjectBuildFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.MicroserviceProjectBuildFile#getFileName()
	 * @see #getMicroserviceProjectBuildFile()
	 * @generated
	 */
	EAttribute getMicroserviceProjectBuildFile_FileName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.MicroserviceProjectBuildFile#getMicroserviceName <em>Microservice Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Microservice Name</em>'.
	 * @see PSM.MicroserviceProjectBuildFile#getMicroserviceName()
	 * @see #getMicroserviceProjectBuildFile()
	 * @generated
	 */
	EAttribute getMicroserviceProjectBuildFile_MicroserviceName();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.MicroserviceProjectBuildFile#getDependencies <em>Dependencies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dependencies</em>'.
	 * @see PSM.MicroserviceProjectBuildFile#getDependencies()
	 * @see #getMicroserviceProjectBuildFile()
	 * @generated
	 */
	EReference getMicroserviceProjectBuildFile_Dependencies();

	/**
	 * Returns the meta object for class '{@link PSM.DependencyLibrary <em>Dependency Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dependency Library</em>'.
	 * @see PSM.DependencyLibrary
	 * @generated
	 */
	EClass getDependencyLibrary();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DependencyLibrary#getLibraryGroupName <em>Library Group Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Library Group Name</em>'.
	 * @see PSM.DependencyLibrary#getLibraryGroupName()
	 * @see #getDependencyLibrary()
	 * @generated
	 */
	EAttribute getDependencyLibrary_LibraryGroupName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.DependencyLibrary#getLibraryName <em>Library Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Library Name</em>'.
	 * @see PSM.DependencyLibrary#getLibraryName()
	 * @see #getDependencyLibrary()
	 * @generated
	 */
	EAttribute getDependencyLibrary_LibraryName();

	/**
	 * Returns the meta object for class '{@link PSM.MicroserviceProjectConfigurationsFile <em>Microservice Project Configurations File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microservice Project Configurations File</em>'.
	 * @see PSM.MicroserviceProjectConfigurationsFile
	 * @generated
	 */
	EClass getMicroserviceProjectConfigurationsFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.MicroserviceProjectConfigurationsFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.MicroserviceProjectConfigurationsFile#getFileName()
	 * @see #getMicroserviceProjectConfigurationsFile()
	 * @generated
	 */
	EAttribute getMicroserviceProjectConfigurationsFile_FileName();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.MicroserviceProjectConfigurationsFile#getProperties <em>Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Properties</em>'.
	 * @see PSM.MicroserviceProjectConfigurationsFile#getProperties()
	 * @see #getMicroserviceProjectConfigurationsFile()
	 * @generated
	 */
	EReference getMicroserviceProjectConfigurationsFile_Properties();

	/**
	 * Returns the meta object for class '{@link PSM.ConfigurationProperty <em>Configuration Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Configuration Property</em>'.
	 * @see PSM.ConfigurationProperty
	 * @generated
	 */
	EClass getConfigurationProperty();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ConfigurationProperty#getFullyQualifiedPropertyName <em>Fully Qualified Property Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fully Qualified Property Name</em>'.
	 * @see PSM.ConfigurationProperty#getFullyQualifiedPropertyName()
	 * @see #getConfigurationProperty()
	 * @generated
	 */
	EAttribute getConfigurationProperty_FullyQualifiedPropertyName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.ConfigurationProperty#getPropertyValue <em>Property Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Property Value</em>'.
	 * @see PSM.ConfigurationProperty#getPropertyValue()
	 * @see #getConfigurationProperty()
	 * @generated
	 */
	EAttribute getConfigurationProperty_PropertyValue();

	/**
	 * Returns the meta object for class '{@link PSM.SourceFile <em>Source File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Source File</em>'.
	 * @see PSM.SourceFile
	 * @generated
	 */
	EClass getSourceFile();

	/**
	 * Returns the meta object for class '{@link PSM.JavaSourceFile <em>Java Source File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Source File</em>'.
	 * @see PSM.JavaSourceFile
	 * @generated
	 */
	EClass getJavaSourceFile();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaSourceFile#getFileName <em>File Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Name</em>'.
	 * @see PSM.JavaSourceFile#getFileName()
	 * @see #getJavaSourceFile()
	 * @generated
	 */
	EAttribute getJavaSourceFile_FileName();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaSourceFile#getElements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elements</em>'.
	 * @see PSM.JavaSourceFile#getElements()
	 * @see #getJavaSourceFile()
	 * @generated
	 */
	EReference getJavaSourceFile_Elements();

	/**
	 * Returns the meta object for class '{@link PSM.JavaElement <em>Java Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Element</em>'.
	 * @see PSM.JavaElement
	 * @generated
	 */
	EClass getJavaElement();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaElement#getElementName <em>Element Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Element Name</em>'.
	 * @see PSM.JavaElement#getElementName()
	 * @see #getJavaElement()
	 * @generated
	 */
	EAttribute getJavaElement_ElementName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaElement#getElementType <em>Element Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Element Type</em>'.
	 * @see PSM.JavaElement#getElementType()
	 * @see #getJavaElement()
	 * @generated
	 */
	EAttribute getJavaElement_ElementType();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaElement#getLineNumber <em>Line Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Line Number</em>'.
	 * @see PSM.JavaElement#getLineNumber()
	 * @see #getJavaElement()
	 * @generated
	 */
	EAttribute getJavaElement_LineNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaElement#getAnnotations <em>Annotations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Annotations</em>'.
	 * @see PSM.JavaElement#getAnnotations()
	 * @see #getJavaElement()
	 * @generated
	 */
	EReference getJavaElement_Annotations();

	/**
	 * Returns the meta object for class '{@link PSM.JavaAnnotation <em>Java Annotation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Annotation</em>'.
	 * @see PSM.JavaAnnotation
	 * @generated
	 */
	EClass getJavaAnnotation();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaAnnotation#getLineNumber <em>Line Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Line Number</em>'.
	 * @see PSM.JavaAnnotation#getLineNumber()
	 * @see #getJavaAnnotation()
	 * @generated
	 */
	EAttribute getJavaAnnotation_LineNumber();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaAnnotation#getAnnotationName <em>Annotation Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Annotation Name</em>'.
	 * @see PSM.JavaAnnotation#getAnnotationName()
	 * @see #getJavaAnnotation()
	 * @generated
	 */
	EAttribute getJavaAnnotation_AnnotationName();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaAnnotation#getParameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameters</em>'.
	 * @see PSM.JavaAnnotation#getParameters()
	 * @see #getJavaAnnotation()
	 * @generated
	 */
	EReference getJavaAnnotation_Parameters();

	/**
	 * Returns the meta object for class '{@link PSM.JavaAnnotationParameter <em>Java Annotation Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Annotation Parameter</em>'.
	 * @see PSM.JavaAnnotationParameter
	 * @generated
	 */
	EClass getJavaAnnotationParameter();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaAnnotationParameter#getParameterName <em>Parameter Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parameter Name</em>'.
	 * @see PSM.JavaAnnotationParameter#getParameterName()
	 * @see #getJavaAnnotationParameter()
	 * @generated
	 */
	EAttribute getJavaAnnotationParameter_ParameterName();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaAnnotationParameter#getParameterValue <em>Parameter Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parameter Value</em>'.
	 * @see PSM.JavaAnnotationParameter#getParameterValue()
	 * @see #getJavaAnnotationParameter()
	 * @generated
	 */
	EAttribute getJavaAnnotationParameter_ParameterValue();

	/**
	 * Returns the meta object for class '{@link PSM.JavaDataType <em>Java Data Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Data Type</em>'.
	 * @see PSM.JavaDataType
	 * @generated
	 */
	EClass getJavaDataType();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaDataType#isIsPrimitive <em>Is Primitive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Primitive</em>'.
	 * @see PSM.JavaDataType#isIsPrimitive()
	 * @see #getJavaDataType()
	 * @generated
	 */
	EAttribute getJavaDataType_IsPrimitive();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaDataType#getJsonSchema <em>Json Schema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Json Schema</em>'.
	 * @see PSM.JavaDataType#getJsonSchema()
	 * @see #getJavaDataType()
	 * @generated
	 */
	EAttribute getJavaDataType_JsonSchema();

	/**
	 * Returns the meta object for the reference '{@link PSM.JavaDataType#getSuper <em>Super</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Super</em>'.
	 * @see PSM.JavaDataType#getSuper()
	 * @see #getJavaDataType()
	 * @generated
	 */
	EReference getJavaDataType_Super();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaDataType#getImports <em>Imports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Imports</em>'.
	 * @see PSM.JavaDataType#getImports()
	 * @see #getJavaDataType()
	 * @generated
	 */
	EReference getJavaDataType_Imports();

	/**
	 * Returns the meta object for class '{@link PSM.JavaUserDefinedType <em>Java User Defined Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java User Defined Type</em>'.
	 * @see PSM.JavaUserDefinedType
	 * @generated
	 */
	EClass getJavaUserDefinedType();

	/**
	 * Returns the meta object for class '{@link PSM.JavaClassType <em>Java Class Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Class Type</em>'.
	 * @see PSM.JavaClassType
	 * @generated
	 */
	EClass getJavaClassType();

	/**
	 * Returns the meta object for the reference list '{@link PSM.JavaClassType#getImplements <em>Implements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Implements</em>'.
	 * @see PSM.JavaClassType#getImplements()
	 * @see #getJavaClassType()
	 * @generated
	 */
	EReference getJavaClassType_Implements();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaClassType#getFields <em>Fields</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fields</em>'.
	 * @see PSM.JavaClassType#getFields()
	 * @see #getJavaClassType()
	 * @generated
	 */
	EReference getJavaClassType_Fields();

	/**
	 * Returns the meta object for class '{@link PSM.JavaInterfaceType <em>Java Interface Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Interface Type</em>'.
	 * @see PSM.JavaInterfaceType
	 * @generated
	 */
	EClass getJavaInterfaceType();

	/**
	 * Returns the meta object for class '{@link PSM.JavaMethod <em>Java Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Method</em>'.
	 * @see PSM.JavaMethod
	 * @generated
	 */
	EClass getJavaMethod();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaMethod#getFields <em>Fields</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fields</em>'.
	 * @see PSM.JavaMethod#getFields()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Fields();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaMethod#getInvokes <em>Invokes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Invokes</em>'.
	 * @see PSM.JavaMethod#getInvokes()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Invokes();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaMethod#getReturns <em>Returns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Returns</em>'.
	 * @see PSM.JavaMethod#getReturns()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Returns();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaMethod#getParameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameters</em>'.
	 * @see PSM.JavaMethod#getParameters()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Parameters();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.JavaMethod#getOwner <em>Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Owner</em>'.
	 * @see PSM.JavaMethod#getOwner()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Owner();

	/**
	 * Returns the meta object for the containment reference list '{@link PSM.JavaMethod#getArgs <em>Args</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Args</em>'.
	 * @see PSM.JavaMethod#getArgs()
	 * @see #getJavaMethod()
	 * @generated
	 */
	EReference getJavaMethod_Args();

	/**
	 * Returns the meta object for class '{@link PSM.JavaField <em>Java Field</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java Field</em>'.
	 * @see PSM.JavaField
	 * @generated
	 */
	EClass getJavaField();

	/**
	 * Returns the meta object for the attribute '{@link PSM.JavaField#getJsonSchema <em>Json Schema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Json Schema</em>'.
	 * @see PSM.JavaField#getJsonSchema()
	 * @see #getJavaField()
	 * @generated
	 */
	EAttribute getJavaField_JsonSchema();

	/**
	 * Returns the meta object for the containment reference '{@link PSM.JavaField#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Type</em>'.
	 * @see PSM.JavaField#getType()
	 * @see #getJavaField()
	 * @generated
	 */
	EReference getJavaField_Type();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PSMFactory getPSMFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link PSM.impl.RootPSMImpl <em>Root PSM</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.RootPSMImpl
		 * @see PSM.impl.PSMPackageImpl#getRootPSM()
		 * @generated
		 */
		EClass ROOT_PSM = eINSTANCE.getRootPSM();

		/**
		 * The meta object literal for the '<em><b>System</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOT_PSM__SYSTEM = eINSTANCE.getRootPSM_System();

		/**
		 * The meta object literal for the '{@link PSM.impl.SystemProjectArtifactsModelImpl <em>System Project Artifacts Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.SystemProjectArtifactsModelImpl
		 * @see PSM.impl.PSMPackageImpl#getSystemProjectArtifactsModel()
		 * @generated
		 */
		EClass SYSTEM_PROJECT_ARTIFACTS_MODEL = eINSTANCE.getSystemProjectArtifactsModel();

		/**
		 * The meta object literal for the '<em><b>Project Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME = eINSTANCE.getSystemProjectArtifactsModel_ProjectName();

		/**
		 * The meta object literal for the '<em><b>Artifacts Repository URI</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI = eINSTANCE.getSystemProjectArtifactsModel_ArtifactsRepositoryURI();

		/**
		 * The meta object literal for the '<em><b>Docker</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER = eINSTANCE.getSystemProjectArtifactsModel_Docker();

		/**
		 * The meta object literal for the '<em><b>Build</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD = eINSTANCE.getSystemProjectArtifactsModel_Build();

		/**
		 * The meta object literal for the '{@link PSM.impl.DockerComposeFileImpl <em>Docker Compose File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.DockerComposeFileImpl
		 * @see PSM.impl.PSMPackageImpl#getDockerComposeFile()
		 * @generated
		 */
		EClass DOCKER_COMPOSE_FILE = eINSTANCE.getDockerComposeFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCKER_COMPOSE_FILE__FILE_NAME = eINSTANCE.getDockerComposeFile_FileName();

		/**
		 * The meta object literal for the '<em><b>Containers</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCKER_COMPOSE_FILE__CONTAINERS = eINSTANCE.getDockerComposeFile_Containers();

		/**
		 * The meta object literal for the '{@link PSM.impl.ContainerDefinitionImpl <em>Container Definition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.ContainerDefinitionImpl
		 * @see PSM.impl.PSMPackageImpl#getContainerDefinition()
		 * @generated
		 */
		EClass CONTAINER_DEFINITION = eINSTANCE.getContainerDefinition();

		/**
		 * The meta object literal for the '<em><b>Service Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_DEFINITION__SERVICE_NAME = eINSTANCE.getContainerDefinition_ServiceName();

		/**
		 * The meta object literal for the '<em><b>Image Field</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_DEFINITION__IMAGE_FIELD = eINSTANCE.getContainerDefinition_ImageField();

		/**
		 * The meta object literal for the '<em><b>Build Field</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_DEFINITION__BUILD_FIELD = eINSTANCE.getContainerDefinition_BuildField();

		/**
		 * The meta object literal for the '<em><b>Logging Field</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_DEFINITION__LOGGING_FIELD = eINSTANCE.getContainerDefinition_LoggingField();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_DEFINITION__PORTS = eINSTANCE.getContainerDefinition_Ports();

		/**
		 * The meta object literal for the '<em><b>Links</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_DEFINITION__LINKS = eINSTANCE.getContainerDefinition_Links();

		/**
		 * The meta object literal for the '<em><b>Build</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_DEFINITION__BUILD = eINSTANCE.getContainerDefinition_Build();

		/**
		 * The meta object literal for the '<em><b>Project</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONTAINER_DEFINITION__PROJECT = eINSTANCE.getContainerDefinition_Project();

		/**
		 * The meta object literal for the '{@link PSM.impl.PortsFieldImpl <em>Ports Field</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.PortsFieldImpl
		 * @see PSM.impl.PSMPackageImpl#getPortsField()
		 * @generated
		 */
		EClass PORTS_FIELD = eINSTANCE.getPortsField();

		/**
		 * The meta object literal for the '<em><b>Host Port Field</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORTS_FIELD__HOST_PORT_FIELD = eINSTANCE.getPortsField_HostPortField();

		/**
		 * The meta object literal for the '<em><b>Container Port Field</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORTS_FIELD__CONTAINER_PORT_FIELD = eINSTANCE.getPortsField_ContainerPortField();

		/**
		 * The meta object literal for the '{@link PSM.impl.ContainerLinkImpl <em>Container Link</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.ContainerLinkImpl
		 * @see PSM.impl.PSMPackageImpl#getContainerLink()
		 * @generated
		 */
		EClass CONTAINER_LINK = eINSTANCE.getContainerLink();

		/**
		 * The meta object literal for the '<em><b>From Service Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_LINK__FROM_SERVICE_NAME = eINSTANCE.getContainerLink_FromServiceName();

		/**
		 * The meta object literal for the '<em><b>To Service Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTAINER_LINK__TO_SERVICE_NAME = eINSTANCE.getContainerLink_ToServiceName();

		/**
		 * The meta object literal for the '{@link PSM.impl.DockerFileImpl <em>Docker File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.DockerFileImpl
		 * @see PSM.impl.PSMPackageImpl#getDockerFile()
		 * @generated
		 */
		EClass DOCKER_FILE = eINSTANCE.getDockerFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCKER_FILE__FILE_NAME = eINSTANCE.getDockerFile_FileName();

		/**
		 * The meta object literal for the '<em><b>Command FROM</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCKER_FILE__COMMAND_FROM = eINSTANCE.getDockerFile_CommandFROM();

		/**
		 * The meta object literal for the '<em><b>Command EXPOSE</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCKER_FILE__COMMAND_EXPOSE = eINSTANCE.getDockerFile_CommandEXPOSE();

		/**
		 * The meta object literal for the '{@link PSM.impl.SystemProjectBuildFileImpl <em>System Project Build File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.SystemProjectBuildFileImpl
		 * @see PSM.impl.PSMPackageImpl#getSystemProjectBuildFile()
		 * @generated
		 */
		EClass SYSTEM_PROJECT_BUILD_FILE = eINSTANCE.getSystemProjectBuildFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_PROJECT_BUILD_FILE__FILE_NAME = eINSTANCE.getSystemProjectBuildFile_FileName();

		/**
		 * The meta object literal for the '<em><b>System Project Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME = eINSTANCE.getSystemProjectBuildFile_SystemProjectName();

		/**
		 * The meta object literal for the '<em><b>Projects</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM_PROJECT_BUILD_FILE__PROJECTS = eINSTANCE.getSystemProjectBuildFile_Projects();

		/**
		 * The meta object literal for the '{@link PSM.impl.MicroserviceProjectArtifactsModelImpl <em>Microservice Project Artifacts Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.MicroserviceProjectArtifactsModelImpl
		 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectArtifactsModel()
		 * @generated
		 */
		EClass MICROSERVICE_PROJECT_ARTIFACTS_MODEL = eINSTANCE.getMicroserviceProjectArtifactsModel();

		/**
		 * The meta object literal for the '<em><b>Project Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME = eINSTANCE.getMicroserviceProjectArtifactsModel_ProjectName();

		/**
		 * The meta object literal for the '<em><b>Build</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD = eINSTANCE.getMicroserviceProjectArtifactsModel_Build();

		/**
		 * The meta object literal for the '<em><b>Config</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG = eINSTANCE.getMicroserviceProjectArtifactsModel_Config();

		/**
		 * The meta object literal for the '<em><b>Sources</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES = eINSTANCE.getMicroserviceProjectArtifactsModel_Sources();

		/**
		 * The meta object literal for the '{@link PSM.impl.MicroserviceProjectBuildFileImpl <em>Microservice Project Build File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.MicroserviceProjectBuildFileImpl
		 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectBuildFile()
		 * @generated
		 */
		EClass MICROSERVICE_PROJECT_BUILD_FILE = eINSTANCE.getMicroserviceProjectBuildFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME = eINSTANCE.getMicroserviceProjectBuildFile_FileName();

		/**
		 * The meta object literal for the '<em><b>Microservice Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME = eINSTANCE.getMicroserviceProjectBuildFile_MicroserviceName();

		/**
		 * The meta object literal for the '<em><b>Dependencies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES = eINSTANCE.getMicroserviceProjectBuildFile_Dependencies();

		/**
		 * The meta object literal for the '{@link PSM.impl.DependencyLibraryImpl <em>Dependency Library</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.DependencyLibraryImpl
		 * @see PSM.impl.PSMPackageImpl#getDependencyLibrary()
		 * @generated
		 */
		EClass DEPENDENCY_LIBRARY = eINSTANCE.getDependencyLibrary();

		/**
		 * The meta object literal for the '<em><b>Library Group Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME = eINSTANCE.getDependencyLibrary_LibraryGroupName();

		/**
		 * The meta object literal for the '<em><b>Library Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEPENDENCY_LIBRARY__LIBRARY_NAME = eINSTANCE.getDependencyLibrary_LibraryName();

		/**
		 * The meta object literal for the '{@link PSM.impl.MicroserviceProjectConfigurationsFileImpl <em>Microservice Project Configurations File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.MicroserviceProjectConfigurationsFileImpl
		 * @see PSM.impl.PSMPackageImpl#getMicroserviceProjectConfigurationsFile()
		 * @generated
		 */
		EClass MICROSERVICE_PROJECT_CONFIGURATIONS_FILE = eINSTANCE.getMicroserviceProjectConfigurationsFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__FILE_NAME = eINSTANCE.getMicroserviceProjectConfigurationsFile_FileName();

		/**
		 * The meta object literal for the '<em><b>Properties</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__PROPERTIES = eINSTANCE.getMicroserviceProjectConfigurationsFile_Properties();

		/**
		 * The meta object literal for the '{@link PSM.impl.ConfigurationPropertyImpl <em>Configuration Property</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.ConfigurationPropertyImpl
		 * @see PSM.impl.PSMPackageImpl#getConfigurationProperty()
		 * @generated
		 */
		EClass CONFIGURATION_PROPERTY = eINSTANCE.getConfigurationProperty();

		/**
		 * The meta object literal for the '<em><b>Fully Qualified Property Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME = eINSTANCE.getConfigurationProperty_FullyQualifiedPropertyName();

		/**
		 * The meta object literal for the '<em><b>Property Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONFIGURATION_PROPERTY__PROPERTY_VALUE = eINSTANCE.getConfigurationProperty_PropertyValue();

		/**
		 * The meta object literal for the '{@link PSM.impl.SourceFileImpl <em>Source File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.SourceFileImpl
		 * @see PSM.impl.PSMPackageImpl#getSourceFile()
		 * @generated
		 */
		EClass SOURCE_FILE = eINSTANCE.getSourceFile();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaSourceFileImpl <em>Java Source File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaSourceFileImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaSourceFile()
		 * @generated
		 */
		EClass JAVA_SOURCE_FILE = eINSTANCE.getJavaSourceFile();

		/**
		 * The meta object literal for the '<em><b>File Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_SOURCE_FILE__FILE_NAME = eINSTANCE.getJavaSourceFile_FileName();

		/**
		 * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_SOURCE_FILE__ELEMENTS = eINSTANCE.getJavaSourceFile_Elements();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaElementImpl <em>Java Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaElementImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaElement()
		 * @generated
		 */
		EClass JAVA_ELEMENT = eINSTANCE.getJavaElement();

		/**
		 * The meta object literal for the '<em><b>Element Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ELEMENT__ELEMENT_NAME = eINSTANCE.getJavaElement_ElementName();

		/**
		 * The meta object literal for the '<em><b>Element Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ELEMENT__ELEMENT_TYPE = eINSTANCE.getJavaElement_ElementType();

		/**
		 * The meta object literal for the '<em><b>Line Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ELEMENT__LINE_NUMBER = eINSTANCE.getJavaElement_LineNumber();

		/**
		 * The meta object literal for the '<em><b>Annotations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_ELEMENT__ANNOTATIONS = eINSTANCE.getJavaElement_Annotations();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaAnnotationImpl <em>Java Annotation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaAnnotationImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaAnnotation()
		 * @generated
		 */
		EClass JAVA_ANNOTATION = eINSTANCE.getJavaAnnotation();

		/**
		 * The meta object literal for the '<em><b>Line Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ANNOTATION__LINE_NUMBER = eINSTANCE.getJavaAnnotation_LineNumber();

		/**
		 * The meta object literal for the '<em><b>Annotation Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ANNOTATION__ANNOTATION_NAME = eINSTANCE.getJavaAnnotation_AnnotationName();

		/**
		 * The meta object literal for the '<em><b>Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_ANNOTATION__PARAMETERS = eINSTANCE.getJavaAnnotation_Parameters();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaAnnotationParameterImpl <em>Java Annotation Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaAnnotationParameterImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaAnnotationParameter()
		 * @generated
		 */
		EClass JAVA_ANNOTATION_PARAMETER = eINSTANCE.getJavaAnnotationParameter();

		/**
		 * The meta object literal for the '<em><b>Parameter Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ANNOTATION_PARAMETER__PARAMETER_NAME = eINSTANCE.getJavaAnnotationParameter_ParameterName();

		/**
		 * The meta object literal for the '<em><b>Parameter Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_ANNOTATION_PARAMETER__PARAMETER_VALUE = eINSTANCE.getJavaAnnotationParameter_ParameterValue();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaDataTypeImpl <em>Java Data Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaDataTypeImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaDataType()
		 * @generated
		 */
		EClass JAVA_DATA_TYPE = eINSTANCE.getJavaDataType();

		/**
		 * The meta object literal for the '<em><b>Is Primitive</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_DATA_TYPE__IS_PRIMITIVE = eINSTANCE.getJavaDataType_IsPrimitive();

		/**
		 * The meta object literal for the '<em><b>Json Schema</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_DATA_TYPE__JSON_SCHEMA = eINSTANCE.getJavaDataType_JsonSchema();

		/**
		 * The meta object literal for the '<em><b>Super</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_DATA_TYPE__SUPER = eINSTANCE.getJavaDataType_Super();

		/**
		 * The meta object literal for the '<em><b>Imports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_DATA_TYPE__IMPORTS = eINSTANCE.getJavaDataType_Imports();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaUserDefinedTypeImpl <em>Java User Defined Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaUserDefinedTypeImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaUserDefinedType()
		 * @generated
		 */
		EClass JAVA_USER_DEFINED_TYPE = eINSTANCE.getJavaUserDefinedType();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaClassTypeImpl <em>Java Class Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaClassTypeImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaClassType()
		 * @generated
		 */
		EClass JAVA_CLASS_TYPE = eINSTANCE.getJavaClassType();

		/**
		 * The meta object literal for the '<em><b>Implements</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_CLASS_TYPE__IMPLEMENTS = eINSTANCE.getJavaClassType_Implements();

		/**
		 * The meta object literal for the '<em><b>Fields</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_CLASS_TYPE__FIELDS = eINSTANCE.getJavaClassType_Fields();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaInterfaceTypeImpl <em>Java Interface Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaInterfaceTypeImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaInterfaceType()
		 * @generated
		 */
		EClass JAVA_INTERFACE_TYPE = eINSTANCE.getJavaInterfaceType();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaMethodImpl <em>Java Method</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaMethodImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaMethod()
		 * @generated
		 */
		EClass JAVA_METHOD = eINSTANCE.getJavaMethod();

		/**
		 * The meta object literal for the '<em><b>Fields</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__FIELDS = eINSTANCE.getJavaMethod_Fields();

		/**
		 * The meta object literal for the '<em><b>Invokes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__INVOKES = eINSTANCE.getJavaMethod_Invokes();

		/**
		 * The meta object literal for the '<em><b>Returns</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__RETURNS = eINSTANCE.getJavaMethod_Returns();

		/**
		 * The meta object literal for the '<em><b>Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__PARAMETERS = eINSTANCE.getJavaMethod_Parameters();

		/**
		 * The meta object literal for the '<em><b>Owner</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__OWNER = eINSTANCE.getJavaMethod_Owner();

		/**
		 * The meta object literal for the '<em><b>Args</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_METHOD__ARGS = eINSTANCE.getJavaMethod_Args();

		/**
		 * The meta object literal for the '{@link PSM.impl.JavaFieldImpl <em>Java Field</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see PSM.impl.JavaFieldImpl
		 * @see PSM.impl.PSMPackageImpl#getJavaField()
		 * @generated
		 */
		EClass JAVA_FIELD = eINSTANCE.getJavaField();

		/**
		 * The meta object literal for the '<em><b>Json Schema</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JAVA_FIELD__JSON_SCHEMA = eINSTANCE.getJavaField_JsonSchema();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JAVA_FIELD__TYPE = eINSTANCE.getJavaField_Type();

	}

} //PSMPackage
