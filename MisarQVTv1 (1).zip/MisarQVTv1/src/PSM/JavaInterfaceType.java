/**
 */
package PSM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Interface Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PSM.PSMPackage#getJavaInterfaceType()
 * @model
 * @generated
 */
public interface JavaInterfaceType extends JavaUserDefinedType {
} // JavaInterfaceType
