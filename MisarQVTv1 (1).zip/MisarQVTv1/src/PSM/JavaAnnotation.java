/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Annotation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.JavaAnnotation#getLineNumber <em>Line Number</em>}</li>
 *   <li>{@link PSM.JavaAnnotation#getAnnotationName <em>Annotation Name</em>}</li>
 *   <li>{@link PSM.JavaAnnotation#getParameters <em>Parameters</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getJavaAnnotation()
 * @model
 * @generated
 */
public interface JavaAnnotation extends EObject {
	/**
	 * Returns the value of the '<em><b>Line Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Line Number</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Line Number</em>' attribute.
	 * @see #setLineNumber(int)
	 * @see PSM.PSMPackage#getJavaAnnotation_LineNumber()
	 * @model
	 * @generated
	 */
	int getLineNumber();

	/**
	 * Sets the value of the '{@link PSM.JavaAnnotation#getLineNumber <em>Line Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Line Number</em>' attribute.
	 * @see #getLineNumber()
	 * @generated
	 */
	void setLineNumber(int value);

	/**
	 * Returns the value of the '<em><b>Annotation Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Annotation Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Annotation Name</em>' attribute.
	 * @see #setAnnotationName(String)
	 * @see PSM.PSMPackage#getJavaAnnotation_AnnotationName()
	 * @model
	 * @generated
	 */
	String getAnnotationName();

	/**
	 * Sets the value of the '{@link PSM.JavaAnnotation#getAnnotationName <em>Annotation Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Annotation Name</em>' attribute.
	 * @see #getAnnotationName()
	 * @generated
	 */
	void setAnnotationName(String value);

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaAnnotationParameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaAnnotation_Parameters()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<JavaAnnotationParameter> getParameters();

} // JavaAnnotation
