/**
 */
package PSM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java User Defined Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see PSM.PSMPackage#getJavaUserDefinedType()
 * @model
 * @generated
 */
public interface JavaUserDefinedType extends JavaDataType {
} // JavaUserDefinedType
