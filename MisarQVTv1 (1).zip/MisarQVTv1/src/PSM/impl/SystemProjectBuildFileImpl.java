/**
 */
package PSM.impl;

import PSM.MicroserviceProjectArtifactsModel;
import PSM.PSMPackage;
import PSM.SystemProjectBuildFile;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System Project Build File</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.SystemProjectBuildFileImpl#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.impl.SystemProjectBuildFileImpl#getSystemProjectName <em>System Project Name</em>}</li>
 *   <li>{@link PSM.impl.SystemProjectBuildFileImpl#getProjects <em>Projects</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SystemProjectBuildFileImpl extends MinimalEObjectImpl.Container implements SystemProjectBuildFile {
	/**
	 * The default value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected static final String FILE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected String fileName = FILE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSystemProjectName() <em>System Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProjectName()
	 * @generated
	 * @ordered
	 */
	protected static final String SYSTEM_PROJECT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSystemProjectName() <em>System Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProjectName()
	 * @generated
	 * @ordered
	 */
	protected String systemProjectName = SYSTEM_PROJECT_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getProjects() <em>Projects</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProjects()
	 * @generated
	 * @ordered
	 */
	protected EList<MicroserviceProjectArtifactsModel> projects;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SystemProjectBuildFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.SYSTEM_PROJECT_BUILD_FILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFileName(String newFileName) {
		String oldFileName = fileName;
		fileName = newFileName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_BUILD_FILE__FILE_NAME, oldFileName, fileName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSystemProjectName() {
		return systemProjectName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSystemProjectName(String newSystemProjectName) {
		String oldSystemProjectName = systemProjectName;
		systemProjectName = newSystemProjectName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME, oldSystemProjectName, systemProjectName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MicroserviceProjectArtifactsModel> getProjects() {
		if (projects == null) {
			projects = new EObjectResolvingEList<MicroserviceProjectArtifactsModel>(MicroserviceProjectArtifactsModel.class, this, PSMPackage.SYSTEM_PROJECT_BUILD_FILE__PROJECTS);
		}
		return projects;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__FILE_NAME:
				return getFileName();
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME:
				return getSystemProjectName();
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__PROJECTS:
				return getProjects();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__FILE_NAME:
				setFileName((String)newValue);
				return;
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME:
				setSystemProjectName((String)newValue);
				return;
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__PROJECTS:
				getProjects().clear();
				getProjects().addAll((Collection<? extends MicroserviceProjectArtifactsModel>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__FILE_NAME:
				setFileName(FILE_NAME_EDEFAULT);
				return;
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME:
				setSystemProjectName(SYSTEM_PROJECT_NAME_EDEFAULT);
				return;
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__PROJECTS:
				getProjects().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__FILE_NAME:
				return FILE_NAME_EDEFAULT == null ? fileName != null : !FILE_NAME_EDEFAULT.equals(fileName);
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME:
				return SYSTEM_PROJECT_NAME_EDEFAULT == null ? systemProjectName != null : !SYSTEM_PROJECT_NAME_EDEFAULT.equals(systemProjectName);
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE__PROJECTS:
				return projects != null && !projects.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (FileName: ");
		result.append(fileName);
		result.append(", SystemProjectName: ");
		result.append(systemProjectName);
		result.append(')');
		return result.toString();
	}

} //SystemProjectBuildFileImpl
