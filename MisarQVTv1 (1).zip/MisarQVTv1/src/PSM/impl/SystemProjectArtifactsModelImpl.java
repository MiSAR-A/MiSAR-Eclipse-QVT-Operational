/**
 */
package PSM.impl;

import PSM.DockerComposeFile;
import PSM.PSMPackage;
import PSM.SystemProjectArtifactsModel;
import PSM.SystemProjectBuildFile;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>System Project Artifacts Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.SystemProjectArtifactsModelImpl#getProjectName <em>Project Name</em>}</li>
 *   <li>{@link PSM.impl.SystemProjectArtifactsModelImpl#getArtifactsRepositoryURI <em>Artifacts Repository URI</em>}</li>
 *   <li>{@link PSM.impl.SystemProjectArtifactsModelImpl#getDocker <em>Docker</em>}</li>
 *   <li>{@link PSM.impl.SystemProjectArtifactsModelImpl#getBuild <em>Build</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SystemProjectArtifactsModelImpl extends MinimalEObjectImpl.Container implements SystemProjectArtifactsModel {
	/**
	 * The default value of the '{@link #getProjectName() <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProjectName()
	 * @generated
	 * @ordered
	 */
	protected static final String PROJECT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProjectName() <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProjectName()
	 * @generated
	 * @ordered
	 */
	protected String projectName = PROJECT_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getArtifactsRepositoryURI() <em>Artifacts Repository URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArtifactsRepositoryURI()
	 * @generated
	 * @ordered
	 */
	protected static final String ARTIFACTS_REPOSITORY_URI_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArtifactsRepositoryURI() <em>Artifacts Repository URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArtifactsRepositoryURI()
	 * @generated
	 * @ordered
	 */
	protected String artifactsRepositoryURI = ARTIFACTS_REPOSITORY_URI_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDocker() <em>Docker</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDocker()
	 * @generated
	 * @ordered
	 */
	protected DockerComposeFile docker;

	/**
	 * The cached value of the '{@link #getBuild() <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuild()
	 * @generated
	 * @ordered
	 */
	protected SystemProjectBuildFile build;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SystemProjectArtifactsModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.SYSTEM_PROJECT_ARTIFACTS_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProjectName(String newProjectName) {
		String oldProjectName = projectName;
		projectName = newProjectName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME, oldProjectName, projectName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getArtifactsRepositoryURI() {
		return artifactsRepositoryURI;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArtifactsRepositoryURI(String newArtifactsRepositoryURI) {
		String oldArtifactsRepositoryURI = artifactsRepositoryURI;
		artifactsRepositoryURI = newArtifactsRepositoryURI;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI, oldArtifactsRepositoryURI, artifactsRepositoryURI));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DockerComposeFile getDocker() {
		return docker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDocker(DockerComposeFile newDocker, NotificationChain msgs) {
		DockerComposeFile oldDocker = docker;
		docker = newDocker;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER, oldDocker, newDocker);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDocker(DockerComposeFile newDocker) {
		if (newDocker != docker) {
			NotificationChain msgs = null;
			if (docker != null)
				msgs = ((InternalEObject)docker).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER, null, msgs);
			if (newDocker != null)
				msgs = ((InternalEObject)newDocker).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER, null, msgs);
			msgs = basicSetDocker(newDocker, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER, newDocker, newDocker));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SystemProjectBuildFile getBuild() {
		return build;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuild(SystemProjectBuildFile newBuild, NotificationChain msgs) {
		SystemProjectBuildFile oldBuild = build;
		build = newBuild;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD, oldBuild, newBuild);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuild(SystemProjectBuildFile newBuild) {
		if (newBuild != build) {
			NotificationChain msgs = null;
			if (build != null)
				msgs = ((InternalEObject)build).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD, null, msgs);
			if (newBuild != null)
				msgs = ((InternalEObject)newBuild).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD, null, msgs);
			msgs = basicSetBuild(newBuild, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD, newBuild, newBuild));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER:
				return basicSetDocker(null, msgs);
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD:
				return basicSetBuild(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				return getProjectName();
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI:
				return getArtifactsRepositoryURI();
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER:
				return getDocker();
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD:
				return getBuild();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				setProjectName((String)newValue);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI:
				setArtifactsRepositoryURI((String)newValue);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER:
				setDocker((DockerComposeFile)newValue);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD:
				setBuild((SystemProjectBuildFile)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				setProjectName(PROJECT_NAME_EDEFAULT);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI:
				setArtifactsRepositoryURI(ARTIFACTS_REPOSITORY_URI_EDEFAULT);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER:
				setDocker((DockerComposeFile)null);
				return;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD:
				setBuild((SystemProjectBuildFile)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				return PROJECT_NAME_EDEFAULT == null ? projectName != null : !PROJECT_NAME_EDEFAULT.equals(projectName);
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI:
				return ARTIFACTS_REPOSITORY_URI_EDEFAULT == null ? artifactsRepositoryURI != null : !ARTIFACTS_REPOSITORY_URI_EDEFAULT.equals(artifactsRepositoryURI);
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER:
				return docker != null;
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD:
				return build != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ProjectName: ");
		result.append(projectName);
		result.append(", ArtifactsRepositoryURI: ");
		result.append(artifactsRepositoryURI);
		result.append(')');
		return result.toString();
	}

} //SystemProjectArtifactsModelImpl
