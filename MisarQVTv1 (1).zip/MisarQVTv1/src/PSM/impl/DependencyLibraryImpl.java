/**
 */
package PSM.impl;

import PSM.DependencyLibrary;
import PSM.PSMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dependency Library</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.DependencyLibraryImpl#getLibraryGroupName <em>Library Group Name</em>}</li>
 *   <li>{@link PSM.impl.DependencyLibraryImpl#getLibraryName <em>Library Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DependencyLibraryImpl extends MinimalEObjectImpl.Container implements DependencyLibrary {
	/**
	 * The default value of the '{@link #getLibraryGroupName() <em>Library Group Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibraryGroupName()
	 * @generated
	 * @ordered
	 */
	protected static final String LIBRARY_GROUP_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLibraryGroupName() <em>Library Group Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibraryGroupName()
	 * @generated
	 * @ordered
	 */
	protected String libraryGroupName = LIBRARY_GROUP_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getLibraryName() <em>Library Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibraryName()
	 * @generated
	 * @ordered
	 */
	protected static final String LIBRARY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLibraryName() <em>Library Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLibraryName()
	 * @generated
	 * @ordered
	 */
	protected String libraryName = LIBRARY_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DependencyLibraryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.DEPENDENCY_LIBRARY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLibraryGroupName() {
		return libraryGroupName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLibraryGroupName(String newLibraryGroupName) {
		String oldLibraryGroupName = libraryGroupName;
		libraryGroupName = newLibraryGroupName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME, oldLibraryGroupName, libraryGroupName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLibraryName() {
		return libraryName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLibraryName(String newLibraryName) {
		String oldLibraryName = libraryName;
		libraryName = newLibraryName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_NAME, oldLibraryName, libraryName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME:
				return getLibraryGroupName();
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_NAME:
				return getLibraryName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME:
				setLibraryGroupName((String)newValue);
				return;
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_NAME:
				setLibraryName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME:
				setLibraryGroupName(LIBRARY_GROUP_NAME_EDEFAULT);
				return;
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_NAME:
				setLibraryName(LIBRARY_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME:
				return LIBRARY_GROUP_NAME_EDEFAULT == null ? libraryGroupName != null : !LIBRARY_GROUP_NAME_EDEFAULT.equals(libraryGroupName);
			case PSMPackage.DEPENDENCY_LIBRARY__LIBRARY_NAME:
				return LIBRARY_NAME_EDEFAULT == null ? libraryName != null : !LIBRARY_NAME_EDEFAULT.equals(libraryName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (LibraryGroupName: ");
		result.append(libraryGroupName);
		result.append(", LibraryName: ");
		result.append(libraryName);
		result.append(')');
		return result.toString();
	}

} //DependencyLibraryImpl
