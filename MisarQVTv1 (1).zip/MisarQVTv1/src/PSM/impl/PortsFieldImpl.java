/**
 */
package PSM.impl;

import PSM.PSMPackage;
import PSM.PortsField;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ports Field</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.PortsFieldImpl#getHostPortField <em>Host Port Field</em>}</li>
 *   <li>{@link PSM.impl.PortsFieldImpl#getContainerPortField <em>Container Port Field</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PortsFieldImpl extends MinimalEObjectImpl.Container implements PortsField {
	/**
	 * The default value of the '{@link #getHostPortField() <em>Host Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHostPortField()
	 * @generated
	 * @ordered
	 */
	protected static final String HOST_PORT_FIELD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHostPortField() <em>Host Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHostPortField()
	 * @generated
	 * @ordered
	 */
	protected String hostPortField = HOST_PORT_FIELD_EDEFAULT;

	/**
	 * The default value of the '{@link #getContainerPortField() <em>Container Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerPortField()
	 * @generated
	 * @ordered
	 */
	protected static final String CONTAINER_PORT_FIELD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getContainerPortField() <em>Container Port Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerPortField()
	 * @generated
	 * @ordered
	 */
	protected String containerPortField = CONTAINER_PORT_FIELD_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PortsFieldImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.PORTS_FIELD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHostPortField() {
		return hostPortField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHostPortField(String newHostPortField) {
		String oldHostPortField = hostPortField;
		hostPortField = newHostPortField;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.PORTS_FIELD__HOST_PORT_FIELD, oldHostPortField, hostPortField));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getContainerPortField() {
		return containerPortField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setContainerPortField(String newContainerPortField) {
		String oldContainerPortField = containerPortField;
		containerPortField = newContainerPortField;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.PORTS_FIELD__CONTAINER_PORT_FIELD, oldContainerPortField, containerPortField));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.PORTS_FIELD__HOST_PORT_FIELD:
				return getHostPortField();
			case PSMPackage.PORTS_FIELD__CONTAINER_PORT_FIELD:
				return getContainerPortField();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.PORTS_FIELD__HOST_PORT_FIELD:
				setHostPortField((String)newValue);
				return;
			case PSMPackage.PORTS_FIELD__CONTAINER_PORT_FIELD:
				setContainerPortField((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.PORTS_FIELD__HOST_PORT_FIELD:
				setHostPortField(HOST_PORT_FIELD_EDEFAULT);
				return;
			case PSMPackage.PORTS_FIELD__CONTAINER_PORT_FIELD:
				setContainerPortField(CONTAINER_PORT_FIELD_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.PORTS_FIELD__HOST_PORT_FIELD:
				return HOST_PORT_FIELD_EDEFAULT == null ? hostPortField != null : !HOST_PORT_FIELD_EDEFAULT.equals(hostPortField);
			case PSMPackage.PORTS_FIELD__CONTAINER_PORT_FIELD:
				return CONTAINER_PORT_FIELD_EDEFAULT == null ? containerPortField != null : !CONTAINER_PORT_FIELD_EDEFAULT.equals(containerPortField);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (HostPortField: ");
		result.append(hostPortField);
		result.append(", ContainerPortField: ");
		result.append(containerPortField);
		result.append(')');
		return result.toString();
	}

} //PortsFieldImpl
