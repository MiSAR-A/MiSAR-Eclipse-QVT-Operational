/**
 */
package PSM.impl;

import PSM.DependencyLibrary;
import PSM.MicroserviceProjectBuildFile;
import PSM.PSMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Microservice Project Build File</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.MicroserviceProjectBuildFileImpl#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.impl.MicroserviceProjectBuildFileImpl#getMicroserviceName <em>Microservice Name</em>}</li>
 *   <li>{@link PSM.impl.MicroserviceProjectBuildFileImpl#getDependencies <em>Dependencies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MicroserviceProjectBuildFileImpl extends MinimalEObjectImpl.Container implements MicroserviceProjectBuildFile {
	/**
	 * The default value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected static final String FILE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected String fileName = FILE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMicroserviceName() <em>Microservice Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMicroserviceName()
	 * @generated
	 * @ordered
	 */
	protected static final String MICROSERVICE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMicroserviceName() <em>Microservice Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMicroserviceName()
	 * @generated
	 * @ordered
	 */
	protected String microserviceName = MICROSERVICE_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDependencies() <em>Dependencies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDependencies()
	 * @generated
	 * @ordered
	 */
	protected EList<DependencyLibrary> dependencies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicroserviceProjectBuildFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.MICROSERVICE_PROJECT_BUILD_FILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFileName(String newFileName) {
		String oldFileName = fileName;
		fileName = newFileName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME, oldFileName, fileName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMicroserviceName() {
		return microserviceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMicroserviceName(String newMicroserviceName) {
		String oldMicroserviceName = microserviceName;
		microserviceName = newMicroserviceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME, oldMicroserviceName, microserviceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DependencyLibrary> getDependencies() {
		if (dependencies == null) {
			dependencies = new EObjectContainmentEList<DependencyLibrary>(DependencyLibrary.class, this, PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES);
		}
		return dependencies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES:
				return ((InternalEList<?>)getDependencies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME:
				return getFileName();
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME:
				return getMicroserviceName();
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES:
				return getDependencies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME:
				setFileName((String)newValue);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME:
				setMicroserviceName((String)newValue);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES:
				getDependencies().clear();
				getDependencies().addAll((Collection<? extends DependencyLibrary>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME:
				setFileName(FILE_NAME_EDEFAULT);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME:
				setMicroserviceName(MICROSERVICE_NAME_EDEFAULT);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES:
				getDependencies().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME:
				return FILE_NAME_EDEFAULT == null ? fileName != null : !FILE_NAME_EDEFAULT.equals(fileName);
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME:
				return MICROSERVICE_NAME_EDEFAULT == null ? microserviceName != null : !MICROSERVICE_NAME_EDEFAULT.equals(microserviceName);
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES:
				return dependencies != null && !dependencies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (FileName: ");
		result.append(fileName);
		result.append(", MicroserviceName: ");
		result.append(microserviceName);
		result.append(')');
		return result.toString();
	}

} //MicroserviceProjectBuildFileImpl
