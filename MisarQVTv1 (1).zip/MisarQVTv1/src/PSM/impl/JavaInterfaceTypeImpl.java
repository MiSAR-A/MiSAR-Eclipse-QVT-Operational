/**
 */
package PSM.impl;

import PSM.JavaInterfaceType;
import PSM.PSMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java Interface Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JavaInterfaceTypeImpl extends JavaUserDefinedTypeImpl implements JavaInterfaceType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaInterfaceTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.JAVA_INTERFACE_TYPE;
	}

} //JavaInterfaceTypeImpl
