/**
 */
package PSM.impl;

import PSM.DockerFile;
import PSM.PSMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Docker File</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.DockerFileImpl#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.impl.DockerFileImpl#getCommandFROM <em>Command FROM</em>}</li>
 *   <li>{@link PSM.impl.DockerFileImpl#getCommandEXPOSE <em>Command EXPOSE</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DockerFileImpl extends MinimalEObjectImpl.Container implements DockerFile {
	/**
	 * The default value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected static final String FILE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFileName() <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFileName()
	 * @generated
	 * @ordered
	 */
	protected String fileName = FILE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCommandFROM() <em>Command FROM</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommandFROM()
	 * @generated
	 * @ordered
	 */
	protected static final String COMMAND_FROM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCommandFROM() <em>Command FROM</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommandFROM()
	 * @generated
	 * @ordered
	 */
	protected String commandFROM = COMMAND_FROM_EDEFAULT;

	/**
	 * The default value of the '{@link #getCommandEXPOSE() <em>Command EXPOSE</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommandEXPOSE()
	 * @generated
	 * @ordered
	 */
	protected static final String COMMAND_EXPOSE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCommandEXPOSE() <em>Command EXPOSE</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommandEXPOSE()
	 * @generated
	 * @ordered
	 */
	protected String commandEXPOSE = COMMAND_EXPOSE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DockerFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.DOCKER_FILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFileName(String newFileName) {
		String oldFileName = fileName;
		fileName = newFileName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.DOCKER_FILE__FILE_NAME, oldFileName, fileName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCommandFROM() {
		return commandFROM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommandFROM(String newCommandFROM) {
		String oldCommandFROM = commandFROM;
		commandFROM = newCommandFROM;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.DOCKER_FILE__COMMAND_FROM, oldCommandFROM, commandFROM));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCommandEXPOSE() {
		return commandEXPOSE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommandEXPOSE(String newCommandEXPOSE) {
		String oldCommandEXPOSE = commandEXPOSE;
		commandEXPOSE = newCommandEXPOSE;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.DOCKER_FILE__COMMAND_EXPOSE, oldCommandEXPOSE, commandEXPOSE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.DOCKER_FILE__FILE_NAME:
				return getFileName();
			case PSMPackage.DOCKER_FILE__COMMAND_FROM:
				return getCommandFROM();
			case PSMPackage.DOCKER_FILE__COMMAND_EXPOSE:
				return getCommandEXPOSE();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.DOCKER_FILE__FILE_NAME:
				setFileName((String)newValue);
				return;
			case PSMPackage.DOCKER_FILE__COMMAND_FROM:
				setCommandFROM((String)newValue);
				return;
			case PSMPackage.DOCKER_FILE__COMMAND_EXPOSE:
				setCommandEXPOSE((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.DOCKER_FILE__FILE_NAME:
				setFileName(FILE_NAME_EDEFAULT);
				return;
			case PSMPackage.DOCKER_FILE__COMMAND_FROM:
				setCommandFROM(COMMAND_FROM_EDEFAULT);
				return;
			case PSMPackage.DOCKER_FILE__COMMAND_EXPOSE:
				setCommandEXPOSE(COMMAND_EXPOSE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.DOCKER_FILE__FILE_NAME:
				return FILE_NAME_EDEFAULT == null ? fileName != null : !FILE_NAME_EDEFAULT.equals(fileName);
			case PSMPackage.DOCKER_FILE__COMMAND_FROM:
				return COMMAND_FROM_EDEFAULT == null ? commandFROM != null : !COMMAND_FROM_EDEFAULT.equals(commandFROM);
			case PSMPackage.DOCKER_FILE__COMMAND_EXPOSE:
				return COMMAND_EXPOSE_EDEFAULT == null ? commandEXPOSE != null : !COMMAND_EXPOSE_EDEFAULT.equals(commandEXPOSE);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (FileName: ");
		result.append(fileName);
		result.append(", CommandFROM: ");
		result.append(commandFROM);
		result.append(", CommandEXPOSE: ");
		result.append(commandEXPOSE);
		result.append(')');
		return result.toString();
	}

} //DockerFileImpl
