/**
 */
package PSM.impl;

import PSM.JavaDataType;
import PSM.PSMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java Data Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.JavaDataTypeImpl#isIsPrimitive <em>Is Primitive</em>}</li>
 *   <li>{@link PSM.impl.JavaDataTypeImpl#getJsonSchema <em>Json Schema</em>}</li>
 *   <li>{@link PSM.impl.JavaDataTypeImpl#getSuper <em>Super</em>}</li>
 *   <li>{@link PSM.impl.JavaDataTypeImpl#getImports <em>Imports</em>}</li>
 * </ul>
 *
 * @generated
 */
public class JavaDataTypeImpl extends JavaElementImpl implements JavaDataType {
	/**
	 * The default value of the '{@link #isIsPrimitive() <em>Is Primitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsPrimitive()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_PRIMITIVE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsPrimitive() <em>Is Primitive</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsPrimitive()
	 * @generated
	 * @ordered
	 */
	protected boolean isPrimitive = IS_PRIMITIVE_EDEFAULT;

	/**
	 * The default value of the '{@link #getJsonSchema() <em>Json Schema</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJsonSchema()
	 * @generated
	 * @ordered
	 */
	protected static final String JSON_SCHEMA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getJsonSchema() <em>Json Schema</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJsonSchema()
	 * @generated
	 * @ordered
	 */
	protected String jsonSchema = JSON_SCHEMA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSuper() <em>Super</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuper()
	 * @generated
	 * @ordered
	 */
	protected JavaDataType super_;

	/**
	 * The cached value of the '{@link #getImports() <em>Imports</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImports()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaDataType> imports;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaDataTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.JAVA_DATA_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsPrimitive() {
		return isPrimitive;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsPrimitive(boolean newIsPrimitive) {
		boolean oldIsPrimitive = isPrimitive;
		isPrimitive = newIsPrimitive;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.JAVA_DATA_TYPE__IS_PRIMITIVE, oldIsPrimitive, isPrimitive));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getJsonSchema() {
		return jsonSchema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setJsonSchema(String newJsonSchema) {
		String oldJsonSchema = jsonSchema;
		jsonSchema = newJsonSchema;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.JAVA_DATA_TYPE__JSON_SCHEMA, oldJsonSchema, jsonSchema));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaDataType getSuper() {
		if (super_ != null && super_.eIsProxy()) {
			InternalEObject oldSuper = (InternalEObject)super_;
			super_ = (JavaDataType)eResolveProxy(oldSuper);
			if (super_ != oldSuper) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PSMPackage.JAVA_DATA_TYPE__SUPER, oldSuper, super_));
			}
		}
		return super_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaDataType basicGetSuper() {
		return super_;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSuper(JavaDataType newSuper) {
		JavaDataType oldSuper = super_;
		super_ = newSuper;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.JAVA_DATA_TYPE__SUPER, oldSuper, super_));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaDataType> getImports() {
		if (imports == null) {
			imports = new EObjectContainmentEList<JavaDataType>(JavaDataType.class, this, PSMPackage.JAVA_DATA_TYPE__IMPORTS);
		}
		return imports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.JAVA_DATA_TYPE__IMPORTS:
				return ((InternalEList<?>)getImports()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.JAVA_DATA_TYPE__IS_PRIMITIVE:
				return isIsPrimitive();
			case PSMPackage.JAVA_DATA_TYPE__JSON_SCHEMA:
				return getJsonSchema();
			case PSMPackage.JAVA_DATA_TYPE__SUPER:
				if (resolve) return getSuper();
				return basicGetSuper();
			case PSMPackage.JAVA_DATA_TYPE__IMPORTS:
				return getImports();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.JAVA_DATA_TYPE__IS_PRIMITIVE:
				setIsPrimitive((Boolean)newValue);
				return;
			case PSMPackage.JAVA_DATA_TYPE__JSON_SCHEMA:
				setJsonSchema((String)newValue);
				return;
			case PSMPackage.JAVA_DATA_TYPE__SUPER:
				setSuper((JavaDataType)newValue);
				return;
			case PSMPackage.JAVA_DATA_TYPE__IMPORTS:
				getImports().clear();
				getImports().addAll((Collection<? extends JavaDataType>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.JAVA_DATA_TYPE__IS_PRIMITIVE:
				setIsPrimitive(IS_PRIMITIVE_EDEFAULT);
				return;
			case PSMPackage.JAVA_DATA_TYPE__JSON_SCHEMA:
				setJsonSchema(JSON_SCHEMA_EDEFAULT);
				return;
			case PSMPackage.JAVA_DATA_TYPE__SUPER:
				setSuper((JavaDataType)null);
				return;
			case PSMPackage.JAVA_DATA_TYPE__IMPORTS:
				getImports().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.JAVA_DATA_TYPE__IS_PRIMITIVE:
				return isPrimitive != IS_PRIMITIVE_EDEFAULT;
			case PSMPackage.JAVA_DATA_TYPE__JSON_SCHEMA:
				return JSON_SCHEMA_EDEFAULT == null ? jsonSchema != null : !JSON_SCHEMA_EDEFAULT.equals(jsonSchema);
			case PSMPackage.JAVA_DATA_TYPE__SUPER:
				return super_ != null;
			case PSMPackage.JAVA_DATA_TYPE__IMPORTS:
				return imports != null && !imports.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (IsPrimitive: ");
		result.append(isPrimitive);
		result.append(", JsonSchema: ");
		result.append(jsonSchema);
		result.append(')');
		return result.toString();
	}

} //JavaDataTypeImpl
