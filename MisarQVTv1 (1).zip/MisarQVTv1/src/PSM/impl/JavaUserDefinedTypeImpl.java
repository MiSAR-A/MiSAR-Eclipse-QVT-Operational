/**
 */
package PSM.impl;

import PSM.JavaUserDefinedType;
import PSM.PSMPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java User Defined Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JavaUserDefinedTypeImpl extends JavaDataTypeImpl implements JavaUserDefinedType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaUserDefinedTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.JAVA_USER_DEFINED_TYPE;
	}

} //JavaUserDefinedTypeImpl
