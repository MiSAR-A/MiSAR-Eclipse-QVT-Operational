/**
 */
package PSM.impl;

import PSM.ConfigurationProperty;
import PSM.PSMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Configuration Property</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.ConfigurationPropertyImpl#getFullyQualifiedPropertyName <em>Fully Qualified Property Name</em>}</li>
 *   <li>{@link PSM.impl.ConfigurationPropertyImpl#getPropertyValue <em>Property Value</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConfigurationPropertyImpl extends MinimalEObjectImpl.Container implements ConfigurationProperty {
	/**
	 * The default value of the '{@link #getFullyQualifiedPropertyName() <em>Fully Qualified Property Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFullyQualifiedPropertyName()
	 * @generated
	 * @ordered
	 */
	protected static final String FULLY_QUALIFIED_PROPERTY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFullyQualifiedPropertyName() <em>Fully Qualified Property Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFullyQualifiedPropertyName()
	 * @generated
	 * @ordered
	 */
	protected String fullyQualifiedPropertyName = FULLY_QUALIFIED_PROPERTY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPropertyValue() <em>Property Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPropertyValue()
	 * @generated
	 * @ordered
	 */
	protected static final String PROPERTY_VALUE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPropertyValue() <em>Property Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPropertyValue()
	 * @generated
	 * @ordered
	 */
	protected String propertyValue = PROPERTY_VALUE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConfigurationPropertyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.CONFIGURATION_PROPERTY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFullyQualifiedPropertyName() {
		return fullyQualifiedPropertyName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFullyQualifiedPropertyName(String newFullyQualifiedPropertyName) {
		String oldFullyQualifiedPropertyName = fullyQualifiedPropertyName;
		fullyQualifiedPropertyName = newFullyQualifiedPropertyName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME, oldFullyQualifiedPropertyName, fullyQualifiedPropertyName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPropertyValue() {
		return propertyValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPropertyValue(String newPropertyValue) {
		String oldPropertyValue = propertyValue;
		propertyValue = newPropertyValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONFIGURATION_PROPERTY__PROPERTY_VALUE, oldPropertyValue, propertyValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME:
				return getFullyQualifiedPropertyName();
			case PSMPackage.CONFIGURATION_PROPERTY__PROPERTY_VALUE:
				return getPropertyValue();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME:
				setFullyQualifiedPropertyName((String)newValue);
				return;
			case PSMPackage.CONFIGURATION_PROPERTY__PROPERTY_VALUE:
				setPropertyValue((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME:
				setFullyQualifiedPropertyName(FULLY_QUALIFIED_PROPERTY_NAME_EDEFAULT);
				return;
			case PSMPackage.CONFIGURATION_PROPERTY__PROPERTY_VALUE:
				setPropertyValue(PROPERTY_VALUE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME:
				return FULLY_QUALIFIED_PROPERTY_NAME_EDEFAULT == null ? fullyQualifiedPropertyName != null : !FULLY_QUALIFIED_PROPERTY_NAME_EDEFAULT.equals(fullyQualifiedPropertyName);
			case PSMPackage.CONFIGURATION_PROPERTY__PROPERTY_VALUE:
				return PROPERTY_VALUE_EDEFAULT == null ? propertyValue != null : !PROPERTY_VALUE_EDEFAULT.equals(propertyValue);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (FullyQualifiedPropertyName: ");
		result.append(fullyQualifiedPropertyName);
		result.append(", PropertyValue: ");
		result.append(propertyValue);
		result.append(')');
		return result.toString();
	}

} //ConfigurationPropertyImpl
