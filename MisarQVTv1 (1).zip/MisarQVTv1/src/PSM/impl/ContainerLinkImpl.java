/**
 */
package PSM.impl;

import PSM.ContainerLink;
import PSM.PSMPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Container Link</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.ContainerLinkImpl#getFromServiceName <em>From Service Name</em>}</li>
 *   <li>{@link PSM.impl.ContainerLinkImpl#getToServiceName <em>To Service Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ContainerLinkImpl extends MinimalEObjectImpl.Container implements ContainerLink {
	/**
	 * The default value of the '{@link #getFromServiceName() <em>From Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFromServiceName()
	 * @generated
	 * @ordered
	 */
	protected static final String FROM_SERVICE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFromServiceName() <em>From Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFromServiceName()
	 * @generated
	 * @ordered
	 */
	protected String fromServiceName = FROM_SERVICE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getToServiceName() <em>To Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToServiceName()
	 * @generated
	 * @ordered
	 */
	protected static final String TO_SERVICE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getToServiceName() <em>To Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToServiceName()
	 * @generated
	 * @ordered
	 */
	protected String toServiceName = TO_SERVICE_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContainerLinkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.CONTAINER_LINK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFromServiceName() {
		return fromServiceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFromServiceName(String newFromServiceName) {
		String oldFromServiceName = fromServiceName;
		fromServiceName = newFromServiceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_LINK__FROM_SERVICE_NAME, oldFromServiceName, fromServiceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getToServiceName() {
		return toServiceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setToServiceName(String newToServiceName) {
		String oldToServiceName = toServiceName;
		toServiceName = newToServiceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_LINK__TO_SERVICE_NAME, oldToServiceName, toServiceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.CONTAINER_LINK__FROM_SERVICE_NAME:
				return getFromServiceName();
			case PSMPackage.CONTAINER_LINK__TO_SERVICE_NAME:
				return getToServiceName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.CONTAINER_LINK__FROM_SERVICE_NAME:
				setFromServiceName((String)newValue);
				return;
			case PSMPackage.CONTAINER_LINK__TO_SERVICE_NAME:
				setToServiceName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.CONTAINER_LINK__FROM_SERVICE_NAME:
				setFromServiceName(FROM_SERVICE_NAME_EDEFAULT);
				return;
			case PSMPackage.CONTAINER_LINK__TO_SERVICE_NAME:
				setToServiceName(TO_SERVICE_NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.CONTAINER_LINK__FROM_SERVICE_NAME:
				return FROM_SERVICE_NAME_EDEFAULT == null ? fromServiceName != null : !FROM_SERVICE_NAME_EDEFAULT.equals(fromServiceName);
			case PSMPackage.CONTAINER_LINK__TO_SERVICE_NAME:
				return TO_SERVICE_NAME_EDEFAULT == null ? toServiceName != null : !TO_SERVICE_NAME_EDEFAULT.equals(toServiceName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (FromServiceName: ");
		result.append(fromServiceName);
		result.append(", ToServiceName: ");
		result.append(toServiceName);
		result.append(')');
		return result.toString();
	}

} //ContainerLinkImpl
