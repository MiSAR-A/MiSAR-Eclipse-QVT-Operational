/**
 */
package PSM.impl;

import PSM.ConfigurationProperty;
import PSM.ContainerDefinition;
import PSM.ContainerLink;
import PSM.DependencyLibrary;
import PSM.DockerComposeFile;
import PSM.DockerFile;
import PSM.JavaAnnotation;
import PSM.JavaAnnotationParameter;
import PSM.JavaClassType;
import PSM.JavaDataType;
import PSM.JavaElement;
import PSM.JavaField;
import PSM.JavaInterfaceType;
import PSM.JavaMethod;
import PSM.JavaSourceFile;
import PSM.JavaUserDefinedType;
import PSM.MicroserviceProjectArtifactsModel;
import PSM.MicroserviceProjectBuildFile;
import PSM.MicroserviceProjectConfigurationsFile;
import PSM.PSMFactory;
import PSM.PSMPackage;
import PSM.PortsField;
import PSM.RootPSM;
import PSM.SourceFile;
import PSM.SystemProjectArtifactsModel;
import PSM.SystemProjectBuildFile;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PSMPackageImpl extends EPackageImpl implements PSMPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rootPSMEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass systemProjectArtifactsModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dockerComposeFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerDefinitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass portsFieldEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerLinkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dockerFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass systemProjectBuildFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microserviceProjectArtifactsModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microserviceProjectBuildFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dependencyLibraryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microserviceProjectConfigurationsFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass configurationPropertyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sourceFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaSourceFileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaElementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaAnnotationParameterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaDataTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaUserDefinedTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaClassTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaInterfaceTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaMethodEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaFieldEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see PSM.PSMPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PSMPackageImpl() {
		super(eNS_URI, PSMFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link PSMPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PSMPackage init() {
		if (isInited) return (PSMPackage)EPackage.Registry.INSTANCE.getEPackage(PSMPackage.eNS_URI);

		// Obtain or create and register package
		PSMPackageImpl thePSMPackage = (PSMPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof PSMPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new PSMPackageImpl());

		isInited = true;

		// Create package meta-data objects
		thePSMPackage.createPackageContents();

		// Initialize created meta-data
		thePSMPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		thePSMPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(PSMPackage.eNS_URI, thePSMPackage);
		return thePSMPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRootPSM() {
		return rootPSMEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRootPSM_System() {
		return (EReference)rootPSMEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSystemProjectArtifactsModel() {
		return systemProjectArtifactsModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSystemProjectArtifactsModel_ProjectName() {
		return (EAttribute)systemProjectArtifactsModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSystemProjectArtifactsModel_ArtifactsRepositoryURI() {
		return (EAttribute)systemProjectArtifactsModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSystemProjectArtifactsModel_Docker() {
		return (EReference)systemProjectArtifactsModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSystemProjectArtifactsModel_Build() {
		return (EReference)systemProjectArtifactsModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDockerComposeFile() {
		return dockerComposeFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDockerComposeFile_FileName() {
		return (EAttribute)dockerComposeFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDockerComposeFile_Containers() {
		return (EReference)dockerComposeFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainerDefinition() {
		return containerDefinitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerDefinition_ServiceName() {
		return (EAttribute)containerDefinitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerDefinition_ImageField() {
		return (EAttribute)containerDefinitionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerDefinition_BuildField() {
		return (EAttribute)containerDefinitionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerDefinition_LoggingField() {
		return (EAttribute)containerDefinitionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainerDefinition_Ports() {
		return (EReference)containerDefinitionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainerDefinition_Links() {
		return (EReference)containerDefinitionEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainerDefinition_Build() {
		return (EReference)containerDefinitionEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getContainerDefinition_Project() {
		return (EReference)containerDefinitionEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPortsField() {
		return portsFieldEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPortsField_HostPortField() {
		return (EAttribute)portsFieldEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPortsField_ContainerPortField() {
		return (EAttribute)portsFieldEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainerLink() {
		return containerLinkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerLink_FromServiceName() {
		return (EAttribute)containerLinkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getContainerLink_ToServiceName() {
		return (EAttribute)containerLinkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDockerFile() {
		return dockerFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDockerFile_FileName() {
		return (EAttribute)dockerFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDockerFile_CommandFROM() {
		return (EAttribute)dockerFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDockerFile_CommandEXPOSE() {
		return (EAttribute)dockerFileEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSystemProjectBuildFile() {
		return systemProjectBuildFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSystemProjectBuildFile_FileName() {
		return (EAttribute)systemProjectBuildFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSystemProjectBuildFile_SystemProjectName() {
		return (EAttribute)systemProjectBuildFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSystemProjectBuildFile_Projects() {
		return (EReference)systemProjectBuildFileEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroserviceProjectArtifactsModel() {
		return microserviceProjectArtifactsModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroserviceProjectArtifactsModel_ProjectName() {
		return (EAttribute)microserviceProjectArtifactsModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceProjectArtifactsModel_Build() {
		return (EReference)microserviceProjectArtifactsModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceProjectArtifactsModel_Config() {
		return (EReference)microserviceProjectArtifactsModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceProjectArtifactsModel_Sources() {
		return (EReference)microserviceProjectArtifactsModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroserviceProjectBuildFile() {
		return microserviceProjectBuildFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroserviceProjectBuildFile_FileName() {
		return (EAttribute)microserviceProjectBuildFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroserviceProjectBuildFile_MicroserviceName() {
		return (EAttribute)microserviceProjectBuildFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceProjectBuildFile_Dependencies() {
		return (EReference)microserviceProjectBuildFileEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDependencyLibrary() {
		return dependencyLibraryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDependencyLibrary_LibraryGroupName() {
		return (EAttribute)dependencyLibraryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDependencyLibrary_LibraryName() {
		return (EAttribute)dependencyLibraryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicroserviceProjectConfigurationsFile() {
		return microserviceProjectConfigurationsFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicroserviceProjectConfigurationsFile_FileName() {
		return (EAttribute)microserviceProjectConfigurationsFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicroserviceProjectConfigurationsFile_Properties() {
		return (EReference)microserviceProjectConfigurationsFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConfigurationProperty() {
		return configurationPropertyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConfigurationProperty_FullyQualifiedPropertyName() {
		return (EAttribute)configurationPropertyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConfigurationProperty_PropertyValue() {
		return (EAttribute)configurationPropertyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSourceFile() {
		return sourceFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaSourceFile() {
		return javaSourceFileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaSourceFile_FileName() {
		return (EAttribute)javaSourceFileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaSourceFile_Elements() {
		return (EReference)javaSourceFileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaElement() {
		return javaElementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaElement_ElementName() {
		return (EAttribute)javaElementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaElement_ElementType() {
		return (EAttribute)javaElementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaElement_LineNumber() {
		return (EAttribute)javaElementEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaElement_Annotations() {
		return (EReference)javaElementEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaAnnotation() {
		return javaAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaAnnotation_LineNumber() {
		return (EAttribute)javaAnnotationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaAnnotation_AnnotationName() {
		return (EAttribute)javaAnnotationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaAnnotation_Parameters() {
		return (EReference)javaAnnotationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaAnnotationParameter() {
		return javaAnnotationParameterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaAnnotationParameter_ParameterName() {
		return (EAttribute)javaAnnotationParameterEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaAnnotationParameter_ParameterValue() {
		return (EAttribute)javaAnnotationParameterEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaDataType() {
		return javaDataTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaDataType_IsPrimitive() {
		return (EAttribute)javaDataTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaDataType_JsonSchema() {
		return (EAttribute)javaDataTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaDataType_Super() {
		return (EReference)javaDataTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaDataType_Imports() {
		return (EReference)javaDataTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaUserDefinedType() {
		return javaUserDefinedTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaClassType() {
		return javaClassTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaClassType_Implements() {
		return (EReference)javaClassTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaClassType_Fields() {
		return (EReference)javaClassTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaInterfaceType() {
		return javaInterfaceTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaMethod() {
		return javaMethodEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Fields() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Invokes() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Returns() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Parameters() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Owner() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaMethod_Args() {
		return (EReference)javaMethodEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaField() {
		return javaFieldEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJavaField_JsonSchema() {
		return (EAttribute)javaFieldEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJavaField_Type() {
		return (EReference)javaFieldEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PSMFactory getPSMFactory() {
		return (PSMFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		rootPSMEClass = createEClass(ROOT_PSM);
		createEReference(rootPSMEClass, ROOT_PSM__SYSTEM);

		systemProjectArtifactsModelEClass = createEClass(SYSTEM_PROJECT_ARTIFACTS_MODEL);
		createEAttribute(systemProjectArtifactsModelEClass, SYSTEM_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME);
		createEAttribute(systemProjectArtifactsModelEClass, SYSTEM_PROJECT_ARTIFACTS_MODEL__ARTIFACTS_REPOSITORY_URI);
		createEReference(systemProjectArtifactsModelEClass, SYSTEM_PROJECT_ARTIFACTS_MODEL__DOCKER);
		createEReference(systemProjectArtifactsModelEClass, SYSTEM_PROJECT_ARTIFACTS_MODEL__BUILD);

		dockerComposeFileEClass = createEClass(DOCKER_COMPOSE_FILE);
		createEAttribute(dockerComposeFileEClass, DOCKER_COMPOSE_FILE__FILE_NAME);
		createEReference(dockerComposeFileEClass, DOCKER_COMPOSE_FILE__CONTAINERS);

		containerDefinitionEClass = createEClass(CONTAINER_DEFINITION);
		createEAttribute(containerDefinitionEClass, CONTAINER_DEFINITION__SERVICE_NAME);
		createEAttribute(containerDefinitionEClass, CONTAINER_DEFINITION__IMAGE_FIELD);
		createEAttribute(containerDefinitionEClass, CONTAINER_DEFINITION__BUILD_FIELD);
		createEAttribute(containerDefinitionEClass, CONTAINER_DEFINITION__LOGGING_FIELD);
		createEReference(containerDefinitionEClass, CONTAINER_DEFINITION__PORTS);
		createEReference(containerDefinitionEClass, CONTAINER_DEFINITION__LINKS);
		createEReference(containerDefinitionEClass, CONTAINER_DEFINITION__BUILD);
		createEReference(containerDefinitionEClass, CONTAINER_DEFINITION__PROJECT);

		portsFieldEClass = createEClass(PORTS_FIELD);
		createEAttribute(portsFieldEClass, PORTS_FIELD__HOST_PORT_FIELD);
		createEAttribute(portsFieldEClass, PORTS_FIELD__CONTAINER_PORT_FIELD);

		containerLinkEClass = createEClass(CONTAINER_LINK);
		createEAttribute(containerLinkEClass, CONTAINER_LINK__FROM_SERVICE_NAME);
		createEAttribute(containerLinkEClass, CONTAINER_LINK__TO_SERVICE_NAME);

		dockerFileEClass = createEClass(DOCKER_FILE);
		createEAttribute(dockerFileEClass, DOCKER_FILE__FILE_NAME);
		createEAttribute(dockerFileEClass, DOCKER_FILE__COMMAND_FROM);
		createEAttribute(dockerFileEClass, DOCKER_FILE__COMMAND_EXPOSE);

		systemProjectBuildFileEClass = createEClass(SYSTEM_PROJECT_BUILD_FILE);
		createEAttribute(systemProjectBuildFileEClass, SYSTEM_PROJECT_BUILD_FILE__FILE_NAME);
		createEAttribute(systemProjectBuildFileEClass, SYSTEM_PROJECT_BUILD_FILE__SYSTEM_PROJECT_NAME);
		createEReference(systemProjectBuildFileEClass, SYSTEM_PROJECT_BUILD_FILE__PROJECTS);

		microserviceProjectArtifactsModelEClass = createEClass(MICROSERVICE_PROJECT_ARTIFACTS_MODEL);
		createEAttribute(microserviceProjectArtifactsModelEClass, MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME);
		createEReference(microserviceProjectArtifactsModelEClass, MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD);
		createEReference(microserviceProjectArtifactsModelEClass, MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG);
		createEReference(microserviceProjectArtifactsModelEClass, MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES);

		microserviceProjectBuildFileEClass = createEClass(MICROSERVICE_PROJECT_BUILD_FILE);
		createEAttribute(microserviceProjectBuildFileEClass, MICROSERVICE_PROJECT_BUILD_FILE__FILE_NAME);
		createEAttribute(microserviceProjectBuildFileEClass, MICROSERVICE_PROJECT_BUILD_FILE__MICROSERVICE_NAME);
		createEReference(microserviceProjectBuildFileEClass, MICROSERVICE_PROJECT_BUILD_FILE__DEPENDENCIES);

		dependencyLibraryEClass = createEClass(DEPENDENCY_LIBRARY);
		createEAttribute(dependencyLibraryEClass, DEPENDENCY_LIBRARY__LIBRARY_GROUP_NAME);
		createEAttribute(dependencyLibraryEClass, DEPENDENCY_LIBRARY__LIBRARY_NAME);

		microserviceProjectConfigurationsFileEClass = createEClass(MICROSERVICE_PROJECT_CONFIGURATIONS_FILE);
		createEAttribute(microserviceProjectConfigurationsFileEClass, MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__FILE_NAME);
		createEReference(microserviceProjectConfigurationsFileEClass, MICROSERVICE_PROJECT_CONFIGURATIONS_FILE__PROPERTIES);

		configurationPropertyEClass = createEClass(CONFIGURATION_PROPERTY);
		createEAttribute(configurationPropertyEClass, CONFIGURATION_PROPERTY__FULLY_QUALIFIED_PROPERTY_NAME);
		createEAttribute(configurationPropertyEClass, CONFIGURATION_PROPERTY__PROPERTY_VALUE);

		sourceFileEClass = createEClass(SOURCE_FILE);

		javaSourceFileEClass = createEClass(JAVA_SOURCE_FILE);
		createEAttribute(javaSourceFileEClass, JAVA_SOURCE_FILE__FILE_NAME);
		createEReference(javaSourceFileEClass, JAVA_SOURCE_FILE__ELEMENTS);

		javaElementEClass = createEClass(JAVA_ELEMENT);
		createEAttribute(javaElementEClass, JAVA_ELEMENT__ELEMENT_NAME);
		createEAttribute(javaElementEClass, JAVA_ELEMENT__ELEMENT_TYPE);
		createEAttribute(javaElementEClass, JAVA_ELEMENT__LINE_NUMBER);
		createEReference(javaElementEClass, JAVA_ELEMENT__ANNOTATIONS);

		javaAnnotationEClass = createEClass(JAVA_ANNOTATION);
		createEAttribute(javaAnnotationEClass, JAVA_ANNOTATION__LINE_NUMBER);
		createEAttribute(javaAnnotationEClass, JAVA_ANNOTATION__ANNOTATION_NAME);
		createEReference(javaAnnotationEClass, JAVA_ANNOTATION__PARAMETERS);

		javaAnnotationParameterEClass = createEClass(JAVA_ANNOTATION_PARAMETER);
		createEAttribute(javaAnnotationParameterEClass, JAVA_ANNOTATION_PARAMETER__PARAMETER_NAME);
		createEAttribute(javaAnnotationParameterEClass, JAVA_ANNOTATION_PARAMETER__PARAMETER_VALUE);

		javaDataTypeEClass = createEClass(JAVA_DATA_TYPE);
		createEAttribute(javaDataTypeEClass, JAVA_DATA_TYPE__IS_PRIMITIVE);
		createEAttribute(javaDataTypeEClass, JAVA_DATA_TYPE__JSON_SCHEMA);
		createEReference(javaDataTypeEClass, JAVA_DATA_TYPE__SUPER);
		createEReference(javaDataTypeEClass, JAVA_DATA_TYPE__IMPORTS);

		javaUserDefinedTypeEClass = createEClass(JAVA_USER_DEFINED_TYPE);

		javaClassTypeEClass = createEClass(JAVA_CLASS_TYPE);
		createEReference(javaClassTypeEClass, JAVA_CLASS_TYPE__IMPLEMENTS);
		createEReference(javaClassTypeEClass, JAVA_CLASS_TYPE__FIELDS);

		javaInterfaceTypeEClass = createEClass(JAVA_INTERFACE_TYPE);

		javaMethodEClass = createEClass(JAVA_METHOD);
		createEReference(javaMethodEClass, JAVA_METHOD__FIELDS);
		createEReference(javaMethodEClass, JAVA_METHOD__INVOKES);
		createEReference(javaMethodEClass, JAVA_METHOD__RETURNS);
		createEReference(javaMethodEClass, JAVA_METHOD__PARAMETERS);
		createEReference(javaMethodEClass, JAVA_METHOD__OWNER);
		createEReference(javaMethodEClass, JAVA_METHOD__ARGS);

		javaFieldEClass = createEClass(JAVA_FIELD);
		createEAttribute(javaFieldEClass, JAVA_FIELD__JSON_SCHEMA);
		createEReference(javaFieldEClass, JAVA_FIELD__TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		javaSourceFileEClass.getESuperTypes().add(this.getSourceFile());
		javaDataTypeEClass.getESuperTypes().add(this.getJavaElement());
		javaUserDefinedTypeEClass.getESuperTypes().add(this.getJavaDataType());
		javaClassTypeEClass.getESuperTypes().add(this.getJavaUserDefinedType());
		javaInterfaceTypeEClass.getESuperTypes().add(this.getJavaUserDefinedType());
		javaMethodEClass.getESuperTypes().add(this.getJavaElement());
		javaFieldEClass.getESuperTypes().add(this.getJavaElement());

		// Initialize classes, features, and operations; add parameters
		initEClass(rootPSMEClass, RootPSM.class, "RootPSM", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRootPSM_System(), this.getSystemProjectArtifactsModel(), null, "system", null, 1, 1, RootPSM.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(systemProjectArtifactsModelEClass, SystemProjectArtifactsModel.class, "SystemProjectArtifactsModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSystemProjectArtifactsModel_ProjectName(), ecorePackage.getEString(), "ProjectName", null, 0, 1, SystemProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSystemProjectArtifactsModel_ArtifactsRepositoryURI(), ecorePackage.getEString(), "ArtifactsRepositoryURI", null, 0, 1, SystemProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemProjectArtifactsModel_Docker(), this.getDockerComposeFile(), null, "docker", null, 0, 1, SystemProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemProjectArtifactsModel_Build(), this.getSystemProjectBuildFile(), null, "build", null, 0, 1, SystemProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dockerComposeFileEClass, DockerComposeFile.class, "DockerComposeFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDockerComposeFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, DockerComposeFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDockerComposeFile_Containers(), this.getContainerDefinition(), null, "containers", null, 1, -1, DockerComposeFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(containerDefinitionEClass, ContainerDefinition.class, "ContainerDefinition", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContainerDefinition_ServiceName(), ecorePackage.getEString(), "ServiceName", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContainerDefinition_ImageField(), ecorePackage.getEString(), "ImageField", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContainerDefinition_BuildField(), ecorePackage.getEString(), "BuildField", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContainerDefinition_LoggingField(), ecorePackage.getEBoolean(), "LoggingField", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainerDefinition_Ports(), this.getPortsField(), null, "ports", null, 0, -1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainerDefinition_Links(), this.getContainerLink(), null, "links", null, 0, -1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainerDefinition_Build(), this.getDockerFile(), null, "build", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getContainerDefinition_Project(), this.getMicroserviceProjectArtifactsModel(), null, "project", null, 0, 1, ContainerDefinition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(portsFieldEClass, PortsField.class, "PortsField", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPortsField_HostPortField(), ecorePackage.getEString(), "HostPortField", null, 0, 1, PortsField.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPortsField_ContainerPortField(), ecorePackage.getEString(), "ContainerPortField", null, 0, 1, PortsField.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(containerLinkEClass, ContainerLink.class, "ContainerLink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContainerLink_FromServiceName(), ecorePackage.getEString(), "FromServiceName", null, 0, 1, ContainerLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContainerLink_ToServiceName(), ecorePackage.getEString(), "ToServiceName", null, 0, 1, ContainerLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dockerFileEClass, DockerFile.class, "DockerFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDockerFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, DockerFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDockerFile_CommandFROM(), ecorePackage.getEString(), "CommandFROM", null, 0, 1, DockerFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDockerFile_CommandEXPOSE(), ecorePackage.getEString(), "CommandEXPOSE", null, 0, 1, DockerFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(systemProjectBuildFileEClass, SystemProjectBuildFile.class, "SystemProjectBuildFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSystemProjectBuildFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, SystemProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSystemProjectBuildFile_SystemProjectName(), ecorePackage.getEString(), "SystemProjectName", null, 0, 1, SystemProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSystemProjectBuildFile_Projects(), this.getMicroserviceProjectArtifactsModel(), null, "projects", null, 1, -1, SystemProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microserviceProjectArtifactsModelEClass, MicroserviceProjectArtifactsModel.class, "MicroserviceProjectArtifactsModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroserviceProjectArtifactsModel_ProjectName(), ecorePackage.getEString(), "ProjectName", null, 0, 1, MicroserviceProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroserviceProjectArtifactsModel_Build(), this.getMicroserviceProjectBuildFile(), null, "build", null, 1, 1, MicroserviceProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroserviceProjectArtifactsModel_Config(), this.getMicroserviceProjectConfigurationsFile(), null, "config", null, 1, 1, MicroserviceProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroserviceProjectArtifactsModel_Sources(), this.getSourceFile(), null, "sources", null, 1, -1, MicroserviceProjectArtifactsModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microserviceProjectBuildFileEClass, MicroserviceProjectBuildFile.class, "MicroserviceProjectBuildFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroserviceProjectBuildFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, MicroserviceProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMicroserviceProjectBuildFile_MicroserviceName(), ecorePackage.getEString(), "MicroserviceName", null, 0, 1, MicroserviceProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroserviceProjectBuildFile_Dependencies(), this.getDependencyLibrary(), null, "dependencies", null, 1, -1, MicroserviceProjectBuildFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dependencyLibraryEClass, DependencyLibrary.class, "DependencyLibrary", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDependencyLibrary_LibraryGroupName(), ecorePackage.getEString(), "LibraryGroupName", null, 0, 1, DependencyLibrary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDependencyLibrary_LibraryName(), ecorePackage.getEString(), "LibraryName", null, 0, 1, DependencyLibrary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microserviceProjectConfigurationsFileEClass, MicroserviceProjectConfigurationsFile.class, "MicroserviceProjectConfigurationsFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicroserviceProjectConfigurationsFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, MicroserviceProjectConfigurationsFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicroserviceProjectConfigurationsFile_Properties(), this.getConfigurationProperty(), null, "properties", null, 1, -1, MicroserviceProjectConfigurationsFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(configurationPropertyEClass, ConfigurationProperty.class, "ConfigurationProperty", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConfigurationProperty_FullyQualifiedPropertyName(), ecorePackage.getEString(), "FullyQualifiedPropertyName", null, 0, 1, ConfigurationProperty.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConfigurationProperty_PropertyValue(), ecorePackage.getEString(), "PropertyValue", null, 0, 1, ConfigurationProperty.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sourceFileEClass, SourceFile.class, "SourceFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(javaSourceFileEClass, JavaSourceFile.class, "JavaSourceFile", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaSourceFile_FileName(), ecorePackage.getEString(), "FileName", null, 0, 1, JavaSourceFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaSourceFile_Elements(), this.getJavaElement(), null, "elements", null, 1, -1, JavaSourceFile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaElementEClass, JavaElement.class, "JavaElement", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaElement_ElementName(), ecorePackage.getEString(), "ElementName", null, 0, 1, JavaElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJavaElement_ElementType(), ecorePackage.getEString(), "ElementType", null, 0, 1, JavaElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJavaElement_LineNumber(), ecorePackage.getEInt(), "LineNumber", null, 0, 1, JavaElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaElement_Annotations(), this.getJavaAnnotation(), null, "annotations", null, 1, -1, JavaElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaAnnotationEClass, JavaAnnotation.class, "JavaAnnotation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaAnnotation_LineNumber(), ecorePackage.getEInt(), "LineNumber", null, 0, 1, JavaAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJavaAnnotation_AnnotationName(), ecorePackage.getEString(), "AnnotationName", null, 0, 1, JavaAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaAnnotation_Parameters(), this.getJavaAnnotationParameter(), null, "parameters", null, 1, -1, JavaAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaAnnotationParameterEClass, JavaAnnotationParameter.class, "JavaAnnotationParameter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaAnnotationParameter_ParameterName(), ecorePackage.getEString(), "ParameterName", null, 0, 1, JavaAnnotationParameter.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJavaAnnotationParameter_ParameterValue(), ecorePackage.getEString(), "ParameterValue", null, 0, 1, JavaAnnotationParameter.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaDataTypeEClass, JavaDataType.class, "JavaDataType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaDataType_IsPrimitive(), ecorePackage.getEBoolean(), "IsPrimitive", null, 0, 1, JavaDataType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJavaDataType_JsonSchema(), ecorePackage.getEString(), "JsonSchema", null, 0, 1, JavaDataType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaDataType_Super(), this.getJavaDataType(), null, "super", null, 0, 1, JavaDataType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaDataType_Imports(), this.getJavaDataType(), null, "imports", null, 0, -1, JavaDataType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaUserDefinedTypeEClass, JavaUserDefinedType.class, "JavaUserDefinedType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(javaClassTypeEClass, JavaClassType.class, "JavaClassType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getJavaClassType_Implements(), this.getJavaInterfaceType(), null, "implements", null, 0, -1, JavaClassType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaClassType_Fields(), this.getJavaField(), null, "fields", null, 0, -1, JavaClassType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaInterfaceTypeEClass, JavaInterfaceType.class, "JavaInterfaceType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(javaMethodEClass, JavaMethod.class, "JavaMethod", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getJavaMethod_Fields(), this.getJavaField(), null, "fields", null, 0, -1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaMethod_Invokes(), this.getJavaMethod(), null, "invokes", null, 0, -1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaMethod_Returns(), this.getJavaDataType(), null, "returns", null, 0, -1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaMethod_Parameters(), this.getJavaDataType(), null, "parameters", null, 0, -1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaMethod_Owner(), this.getJavaDataType(), null, "owner", null, 1, 1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaMethod_Args(), this.getJavaField(), null, "args", null, 0, -1, JavaMethod.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(javaFieldEClass, JavaField.class, "JavaField", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJavaField_JsonSchema(), ecorePackage.getEString(), "JsonSchema", null, 0, 1, JavaField.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJavaField_Type(), this.getJavaDataType(), null, "type", null, 1, 1, JavaField.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //PSMPackageImpl
