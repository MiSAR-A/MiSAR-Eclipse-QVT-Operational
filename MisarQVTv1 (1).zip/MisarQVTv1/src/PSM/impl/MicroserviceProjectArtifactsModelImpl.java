/**
 */
package PSM.impl;

import PSM.MicroserviceProjectArtifactsModel;
import PSM.MicroserviceProjectBuildFile;
import PSM.MicroserviceProjectConfigurationsFile;
import PSM.PSMPackage;
import PSM.SourceFile;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Microservice Project Artifacts Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.MicroserviceProjectArtifactsModelImpl#getProjectName <em>Project Name</em>}</li>
 *   <li>{@link PSM.impl.MicroserviceProjectArtifactsModelImpl#getBuild <em>Build</em>}</li>
 *   <li>{@link PSM.impl.MicroserviceProjectArtifactsModelImpl#getConfig <em>Config</em>}</li>
 *   <li>{@link PSM.impl.MicroserviceProjectArtifactsModelImpl#getSources <em>Sources</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MicroserviceProjectArtifactsModelImpl extends MinimalEObjectImpl.Container implements MicroserviceProjectArtifactsModel {
	/**
	 * The default value of the '{@link #getProjectName() <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProjectName()
	 * @generated
	 * @ordered
	 */
	protected static final String PROJECT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProjectName() <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProjectName()
	 * @generated
	 * @ordered
	 */
	protected String projectName = PROJECT_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBuild() <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuild()
	 * @generated
	 * @ordered
	 */
	protected MicroserviceProjectBuildFile build;

	/**
	 * The cached value of the '{@link #getConfig() <em>Config</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConfig()
	 * @generated
	 * @ordered
	 */
	protected MicroserviceProjectConfigurationsFile config;

	/**
	 * The cached value of the '{@link #getSources() <em>Sources</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSources()
	 * @generated
	 * @ordered
	 */
	protected EList<SourceFile> sources;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicroserviceProjectArtifactsModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.MICROSERVICE_PROJECT_ARTIFACTS_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProjectName(String newProjectName) {
		String oldProjectName = projectName;
		projectName = newProjectName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME, oldProjectName, projectName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectBuildFile getBuild() {
		return build;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuild(MicroserviceProjectBuildFile newBuild, NotificationChain msgs) {
		MicroserviceProjectBuildFile oldBuild = build;
		build = newBuild;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD, oldBuild, newBuild);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuild(MicroserviceProjectBuildFile newBuild) {
		if (newBuild != build) {
			NotificationChain msgs = null;
			if (build != null)
				msgs = ((InternalEObject)build).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD, null, msgs);
			if (newBuild != null)
				msgs = ((InternalEObject)newBuild).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD, null, msgs);
			msgs = basicSetBuild(newBuild, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD, newBuild, newBuild));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectConfigurationsFile getConfig() {
		return config;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetConfig(MicroserviceProjectConfigurationsFile newConfig, NotificationChain msgs) {
		MicroserviceProjectConfigurationsFile oldConfig = config;
		config = newConfig;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG, oldConfig, newConfig);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConfig(MicroserviceProjectConfigurationsFile newConfig) {
		if (newConfig != config) {
			NotificationChain msgs = null;
			if (config != null)
				msgs = ((InternalEObject)config).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG, null, msgs);
			if (newConfig != null)
				msgs = ((InternalEObject)newConfig).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG, null, msgs);
			msgs = basicSetConfig(newConfig, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG, newConfig, newConfig));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SourceFile> getSources() {
		if (sources == null) {
			sources = new EObjectContainmentEList<SourceFile>(SourceFile.class, this, PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES);
		}
		return sources;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD:
				return basicSetBuild(null, msgs);
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG:
				return basicSetConfig(null, msgs);
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES:
				return ((InternalEList<?>)getSources()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				return getProjectName();
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD:
				return getBuild();
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG:
				return getConfig();
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES:
				return getSources();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				setProjectName((String)newValue);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD:
				setBuild((MicroserviceProjectBuildFile)newValue);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG:
				setConfig((MicroserviceProjectConfigurationsFile)newValue);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES:
				getSources().clear();
				getSources().addAll((Collection<? extends SourceFile>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				setProjectName(PROJECT_NAME_EDEFAULT);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD:
				setBuild((MicroserviceProjectBuildFile)null);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG:
				setConfig((MicroserviceProjectConfigurationsFile)null);
				return;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES:
				getSources().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__PROJECT_NAME:
				return PROJECT_NAME_EDEFAULT == null ? projectName != null : !PROJECT_NAME_EDEFAULT.equals(projectName);
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__BUILD:
				return build != null;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__CONFIG:
				return config != null;
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL__SOURCES:
				return sources != null && !sources.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ProjectName: ");
		result.append(projectName);
		result.append(')');
		return result.toString();
	}

} //MicroserviceProjectArtifactsModelImpl
