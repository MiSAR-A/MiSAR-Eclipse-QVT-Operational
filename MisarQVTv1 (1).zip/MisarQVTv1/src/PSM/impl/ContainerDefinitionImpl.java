/**
 */
package PSM.impl;

import PSM.ContainerDefinition;
import PSM.ContainerLink;
import PSM.DockerFile;
import PSM.MicroserviceProjectArtifactsModel;
import PSM.PSMPackage;
import PSM.PortsField;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Container Definition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getServiceName <em>Service Name</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getImageField <em>Image Field</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getBuildField <em>Build Field</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#isLoggingField <em>Logging Field</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getPorts <em>Ports</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getLinks <em>Links</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getBuild <em>Build</em>}</li>
 *   <li>{@link PSM.impl.ContainerDefinitionImpl#getProject <em>Project</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ContainerDefinitionImpl extends MinimalEObjectImpl.Container implements ContainerDefinition {
	/**
	 * The default value of the '{@link #getServiceName() <em>Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceName()
	 * @generated
	 * @ordered
	 */
	protected static final String SERVICE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getServiceName() <em>Service Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getServiceName()
	 * @generated
	 * @ordered
	 */
	protected String serviceName = SERVICE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getImageField() <em>Image Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImageField()
	 * @generated
	 * @ordered
	 */
	protected static final String IMAGE_FIELD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getImageField() <em>Image Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImageField()
	 * @generated
	 * @ordered
	 */
	protected String imageField = IMAGE_FIELD_EDEFAULT;

	/**
	 * The default value of the '{@link #getBuildField() <em>Build Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuildField()
	 * @generated
	 * @ordered
	 */
	protected static final String BUILD_FIELD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBuildField() <em>Build Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuildField()
	 * @generated
	 * @ordered
	 */
	protected String buildField = BUILD_FIELD_EDEFAULT;

	/**
	 * The default value of the '{@link #isLoggingField() <em>Logging Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isLoggingField()
	 * @generated
	 * @ordered
	 */
	protected static final boolean LOGGING_FIELD_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isLoggingField() <em>Logging Field</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isLoggingField()
	 * @generated
	 * @ordered
	 */
	protected boolean loggingField = LOGGING_FIELD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected EList<PortsField> ports;

	/**
	 * The cached value of the '{@link #getLinks() <em>Links</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLinks()
	 * @generated
	 * @ordered
	 */
	protected EList<ContainerLink> links;

	/**
	 * The cached value of the '{@link #getBuild() <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuild()
	 * @generated
	 * @ordered
	 */
	protected DockerFile build;

	/**
	 * The cached value of the '{@link #getProject() <em>Project</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProject()
	 * @generated
	 * @ordered
	 */
	protected MicroserviceProjectArtifactsModel project;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContainerDefinitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.CONTAINER_DEFINITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setServiceName(String newServiceName) {
		String oldServiceName = serviceName;
		serviceName = newServiceName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__SERVICE_NAME, oldServiceName, serviceName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getImageField() {
		return imageField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setImageField(String newImageField) {
		String oldImageField = imageField;
		imageField = newImageField;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__IMAGE_FIELD, oldImageField, imageField));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBuildField() {
		return buildField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuildField(String newBuildField) {
		String oldBuildField = buildField;
		buildField = newBuildField;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__BUILD_FIELD, oldBuildField, buildField));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isLoggingField() {
		return loggingField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLoggingField(boolean newLoggingField) {
		boolean oldLoggingField = loggingField;
		loggingField = newLoggingField;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__LOGGING_FIELD, oldLoggingField, loggingField));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PortsField> getPorts() {
		if (ports == null) {
			ports = new EObjectContainmentEList<PortsField>(PortsField.class, this, PSMPackage.CONTAINER_DEFINITION__PORTS);
		}
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ContainerLink> getLinks() {
		if (links == null) {
			links = new EObjectContainmentEList<ContainerLink>(ContainerLink.class, this, PSMPackage.CONTAINER_DEFINITION__LINKS);
		}
		return links;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DockerFile getBuild() {
		return build;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuild(DockerFile newBuild, NotificationChain msgs) {
		DockerFile oldBuild = build;
		build = newBuild;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__BUILD, oldBuild, newBuild);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuild(DockerFile newBuild) {
		if (newBuild != build) {
			NotificationChain msgs = null;
			if (build != null)
				msgs = ((InternalEObject)build).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.CONTAINER_DEFINITION__BUILD, null, msgs);
			if (newBuild != null)
				msgs = ((InternalEObject)newBuild).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.CONTAINER_DEFINITION__BUILD, null, msgs);
			msgs = basicSetBuild(newBuild, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__BUILD, newBuild, newBuild));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectArtifactsModel getProject() {
		return project;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetProject(MicroserviceProjectArtifactsModel newProject, NotificationChain msgs) {
		MicroserviceProjectArtifactsModel oldProject = project;
		project = newProject;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__PROJECT, oldProject, newProject);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProject(MicroserviceProjectArtifactsModel newProject) {
		if (newProject != project) {
			NotificationChain msgs = null;
			if (project != null)
				msgs = ((InternalEObject)project).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.CONTAINER_DEFINITION__PROJECT, null, msgs);
			if (newProject != null)
				msgs = ((InternalEObject)newProject).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.CONTAINER_DEFINITION__PROJECT, null, msgs);
			msgs = basicSetProject(newProject, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.CONTAINER_DEFINITION__PROJECT, newProject, newProject));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.CONTAINER_DEFINITION__PORTS:
				return ((InternalEList<?>)getPorts()).basicRemove(otherEnd, msgs);
			case PSMPackage.CONTAINER_DEFINITION__LINKS:
				return ((InternalEList<?>)getLinks()).basicRemove(otherEnd, msgs);
			case PSMPackage.CONTAINER_DEFINITION__BUILD:
				return basicSetBuild(null, msgs);
			case PSMPackage.CONTAINER_DEFINITION__PROJECT:
				return basicSetProject(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.CONTAINER_DEFINITION__SERVICE_NAME:
				return getServiceName();
			case PSMPackage.CONTAINER_DEFINITION__IMAGE_FIELD:
				return getImageField();
			case PSMPackage.CONTAINER_DEFINITION__BUILD_FIELD:
				return getBuildField();
			case PSMPackage.CONTAINER_DEFINITION__LOGGING_FIELD:
				return isLoggingField();
			case PSMPackage.CONTAINER_DEFINITION__PORTS:
				return getPorts();
			case PSMPackage.CONTAINER_DEFINITION__LINKS:
				return getLinks();
			case PSMPackage.CONTAINER_DEFINITION__BUILD:
				return getBuild();
			case PSMPackage.CONTAINER_DEFINITION__PROJECT:
				return getProject();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.CONTAINER_DEFINITION__SERVICE_NAME:
				setServiceName((String)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__IMAGE_FIELD:
				setImageField((String)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__BUILD_FIELD:
				setBuildField((String)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__LOGGING_FIELD:
				setLoggingField((Boolean)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__PORTS:
				getPorts().clear();
				getPorts().addAll((Collection<? extends PortsField>)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__LINKS:
				getLinks().clear();
				getLinks().addAll((Collection<? extends ContainerLink>)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__BUILD:
				setBuild((DockerFile)newValue);
				return;
			case PSMPackage.CONTAINER_DEFINITION__PROJECT:
				setProject((MicroserviceProjectArtifactsModel)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.CONTAINER_DEFINITION__SERVICE_NAME:
				setServiceName(SERVICE_NAME_EDEFAULT);
				return;
			case PSMPackage.CONTAINER_DEFINITION__IMAGE_FIELD:
				setImageField(IMAGE_FIELD_EDEFAULT);
				return;
			case PSMPackage.CONTAINER_DEFINITION__BUILD_FIELD:
				setBuildField(BUILD_FIELD_EDEFAULT);
				return;
			case PSMPackage.CONTAINER_DEFINITION__LOGGING_FIELD:
				setLoggingField(LOGGING_FIELD_EDEFAULT);
				return;
			case PSMPackage.CONTAINER_DEFINITION__PORTS:
				getPorts().clear();
				return;
			case PSMPackage.CONTAINER_DEFINITION__LINKS:
				getLinks().clear();
				return;
			case PSMPackage.CONTAINER_DEFINITION__BUILD:
				setBuild((DockerFile)null);
				return;
			case PSMPackage.CONTAINER_DEFINITION__PROJECT:
				setProject((MicroserviceProjectArtifactsModel)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.CONTAINER_DEFINITION__SERVICE_NAME:
				return SERVICE_NAME_EDEFAULT == null ? serviceName != null : !SERVICE_NAME_EDEFAULT.equals(serviceName);
			case PSMPackage.CONTAINER_DEFINITION__IMAGE_FIELD:
				return IMAGE_FIELD_EDEFAULT == null ? imageField != null : !IMAGE_FIELD_EDEFAULT.equals(imageField);
			case PSMPackage.CONTAINER_DEFINITION__BUILD_FIELD:
				return BUILD_FIELD_EDEFAULT == null ? buildField != null : !BUILD_FIELD_EDEFAULT.equals(buildField);
			case PSMPackage.CONTAINER_DEFINITION__LOGGING_FIELD:
				return loggingField != LOGGING_FIELD_EDEFAULT;
			case PSMPackage.CONTAINER_DEFINITION__PORTS:
				return ports != null && !ports.isEmpty();
			case PSMPackage.CONTAINER_DEFINITION__LINKS:
				return links != null && !links.isEmpty();
			case PSMPackage.CONTAINER_DEFINITION__BUILD:
				return build != null;
			case PSMPackage.CONTAINER_DEFINITION__PROJECT:
				return project != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ServiceName: ");
		result.append(serviceName);
		result.append(", ImageField: ");
		result.append(imageField);
		result.append(", BuildField: ");
		result.append(buildField);
		result.append(", LoggingField: ");
		result.append(loggingField);
		result.append(')');
		return result.toString();
	}

} //ContainerDefinitionImpl
