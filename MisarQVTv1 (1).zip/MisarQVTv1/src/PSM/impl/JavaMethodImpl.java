/**
 */
package PSM.impl;

import PSM.JavaDataType;
import PSM.JavaField;
import PSM.JavaMethod;
import PSM.PSMPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java Method</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link PSM.impl.JavaMethodImpl#getFields <em>Fields</em>}</li>
 *   <li>{@link PSM.impl.JavaMethodImpl#getInvokes <em>Invokes</em>}</li>
 *   <li>{@link PSM.impl.JavaMethodImpl#getReturns <em>Returns</em>}</li>
 *   <li>{@link PSM.impl.JavaMethodImpl#getParameters <em>Parameters</em>}</li>
 *   <li>{@link PSM.impl.JavaMethodImpl#getOwner <em>Owner</em>}</li>
 *   <li>{@link PSM.impl.JavaMethodImpl#getArgs <em>Args</em>}</li>
 * </ul>
 *
 * @generated
 */
public class JavaMethodImpl extends JavaElementImpl implements JavaMethod {
	/**
	 * The cached value of the '{@link #getFields() <em>Fields</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFields()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaField> fields;

	/**
	 * The cached value of the '{@link #getInvokes() <em>Invokes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInvokes()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaMethod> invokes;

	/**
	 * The cached value of the '{@link #getReturns() <em>Returns</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReturns()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaDataType> returns;

	/**
	 * The cached value of the '{@link #getParameters() <em>Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaDataType> parameters;

	/**
	 * The cached value of the '{@link #getOwner() <em>Owner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOwner()
	 * @generated
	 * @ordered
	 */
	protected JavaDataType owner;

	/**
	 * The cached value of the '{@link #getArgs() <em>Args</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArgs()
	 * @generated
	 * @ordered
	 */
	protected EList<JavaField> args;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaMethodImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PSMPackage.Literals.JAVA_METHOD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaField> getFields() {
		if (fields == null) {
			fields = new EObjectContainmentEList<JavaField>(JavaField.class, this, PSMPackage.JAVA_METHOD__FIELDS);
		}
		return fields;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaMethod> getInvokes() {
		if (invokes == null) {
			invokes = new EObjectContainmentEList<JavaMethod>(JavaMethod.class, this, PSMPackage.JAVA_METHOD__INVOKES);
		}
		return invokes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaDataType> getReturns() {
		if (returns == null) {
			returns = new EObjectContainmentEList<JavaDataType>(JavaDataType.class, this, PSMPackage.JAVA_METHOD__RETURNS);
		}
		return returns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaDataType> getParameters() {
		if (parameters == null) {
			parameters = new EObjectContainmentEList<JavaDataType>(JavaDataType.class, this, PSMPackage.JAVA_METHOD__PARAMETERS);
		}
		return parameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaDataType getOwner() {
		return owner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOwner(JavaDataType newOwner, NotificationChain msgs) {
		JavaDataType oldOwner = owner;
		owner = newOwner;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PSMPackage.JAVA_METHOD__OWNER, oldOwner, newOwner);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOwner(JavaDataType newOwner) {
		if (newOwner != owner) {
			NotificationChain msgs = null;
			if (owner != null)
				msgs = ((InternalEObject)owner).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PSMPackage.JAVA_METHOD__OWNER, null, msgs);
			if (newOwner != null)
				msgs = ((InternalEObject)newOwner).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PSMPackage.JAVA_METHOD__OWNER, null, msgs);
			msgs = basicSetOwner(newOwner, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PSMPackage.JAVA_METHOD__OWNER, newOwner, newOwner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<JavaField> getArgs() {
		if (args == null) {
			args = new EObjectContainmentEList<JavaField>(JavaField.class, this, PSMPackage.JAVA_METHOD__ARGS);
		}
		return args;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PSMPackage.JAVA_METHOD__FIELDS:
				return ((InternalEList<?>)getFields()).basicRemove(otherEnd, msgs);
			case PSMPackage.JAVA_METHOD__INVOKES:
				return ((InternalEList<?>)getInvokes()).basicRemove(otherEnd, msgs);
			case PSMPackage.JAVA_METHOD__RETURNS:
				return ((InternalEList<?>)getReturns()).basicRemove(otherEnd, msgs);
			case PSMPackage.JAVA_METHOD__PARAMETERS:
				return ((InternalEList<?>)getParameters()).basicRemove(otherEnd, msgs);
			case PSMPackage.JAVA_METHOD__OWNER:
				return basicSetOwner(null, msgs);
			case PSMPackage.JAVA_METHOD__ARGS:
				return ((InternalEList<?>)getArgs()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PSMPackage.JAVA_METHOD__FIELDS:
				return getFields();
			case PSMPackage.JAVA_METHOD__INVOKES:
				return getInvokes();
			case PSMPackage.JAVA_METHOD__RETURNS:
				return getReturns();
			case PSMPackage.JAVA_METHOD__PARAMETERS:
				return getParameters();
			case PSMPackage.JAVA_METHOD__OWNER:
				return getOwner();
			case PSMPackage.JAVA_METHOD__ARGS:
				return getArgs();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PSMPackage.JAVA_METHOD__FIELDS:
				getFields().clear();
				getFields().addAll((Collection<? extends JavaField>)newValue);
				return;
			case PSMPackage.JAVA_METHOD__INVOKES:
				getInvokes().clear();
				getInvokes().addAll((Collection<? extends JavaMethod>)newValue);
				return;
			case PSMPackage.JAVA_METHOD__RETURNS:
				getReturns().clear();
				getReturns().addAll((Collection<? extends JavaDataType>)newValue);
				return;
			case PSMPackage.JAVA_METHOD__PARAMETERS:
				getParameters().clear();
				getParameters().addAll((Collection<? extends JavaDataType>)newValue);
				return;
			case PSMPackage.JAVA_METHOD__OWNER:
				setOwner((JavaDataType)newValue);
				return;
			case PSMPackage.JAVA_METHOD__ARGS:
				getArgs().clear();
				getArgs().addAll((Collection<? extends JavaField>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case PSMPackage.JAVA_METHOD__FIELDS:
				getFields().clear();
				return;
			case PSMPackage.JAVA_METHOD__INVOKES:
				getInvokes().clear();
				return;
			case PSMPackage.JAVA_METHOD__RETURNS:
				getReturns().clear();
				return;
			case PSMPackage.JAVA_METHOD__PARAMETERS:
				getParameters().clear();
				return;
			case PSMPackage.JAVA_METHOD__OWNER:
				setOwner((JavaDataType)null);
				return;
			case PSMPackage.JAVA_METHOD__ARGS:
				getArgs().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PSMPackage.JAVA_METHOD__FIELDS:
				return fields != null && !fields.isEmpty();
			case PSMPackage.JAVA_METHOD__INVOKES:
				return invokes != null && !invokes.isEmpty();
			case PSMPackage.JAVA_METHOD__RETURNS:
				return returns != null && !returns.isEmpty();
			case PSMPackage.JAVA_METHOD__PARAMETERS:
				return parameters != null && !parameters.isEmpty();
			case PSMPackage.JAVA_METHOD__OWNER:
				return owner != null;
			case PSMPackage.JAVA_METHOD__ARGS:
				return args != null && !args.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //JavaMethodImpl
