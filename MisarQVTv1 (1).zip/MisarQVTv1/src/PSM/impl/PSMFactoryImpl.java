/**
 */
package PSM.impl;

import PSM.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PSMFactoryImpl extends EFactoryImpl implements PSMFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PSMFactory init() {
		try {
			PSMFactory thePSMFactory = (PSMFactory)EPackage.Registry.INSTANCE.getEFactory(PSMPackage.eNS_URI);
			if (thePSMFactory != null) {
				return thePSMFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PSMFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PSMFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case PSMPackage.ROOT_PSM: return createRootPSM();
			case PSMPackage.SYSTEM_PROJECT_ARTIFACTS_MODEL: return createSystemProjectArtifactsModel();
			case PSMPackage.DOCKER_COMPOSE_FILE: return createDockerComposeFile();
			case PSMPackage.CONTAINER_DEFINITION: return createContainerDefinition();
			case PSMPackage.PORTS_FIELD: return createPortsField();
			case PSMPackage.CONTAINER_LINK: return createContainerLink();
			case PSMPackage.DOCKER_FILE: return createDockerFile();
			case PSMPackage.SYSTEM_PROJECT_BUILD_FILE: return createSystemProjectBuildFile();
			case PSMPackage.MICROSERVICE_PROJECT_ARTIFACTS_MODEL: return createMicroserviceProjectArtifactsModel();
			case PSMPackage.MICROSERVICE_PROJECT_BUILD_FILE: return createMicroserviceProjectBuildFile();
			case PSMPackage.DEPENDENCY_LIBRARY: return createDependencyLibrary();
			case PSMPackage.MICROSERVICE_PROJECT_CONFIGURATIONS_FILE: return createMicroserviceProjectConfigurationsFile();
			case PSMPackage.CONFIGURATION_PROPERTY: return createConfigurationProperty();
			case PSMPackage.SOURCE_FILE: return createSourceFile();
			case PSMPackage.JAVA_SOURCE_FILE: return createJavaSourceFile();
			case PSMPackage.JAVA_ELEMENT: return createJavaElement();
			case PSMPackage.JAVA_ANNOTATION: return createJavaAnnotation();
			case PSMPackage.JAVA_ANNOTATION_PARAMETER: return createJavaAnnotationParameter();
			case PSMPackage.JAVA_DATA_TYPE: return createJavaDataType();
			case PSMPackage.JAVA_USER_DEFINED_TYPE: return createJavaUserDefinedType();
			case PSMPackage.JAVA_CLASS_TYPE: return createJavaClassType();
			case PSMPackage.JAVA_INTERFACE_TYPE: return createJavaInterfaceType();
			case PSMPackage.JAVA_METHOD: return createJavaMethod();
			case PSMPackage.JAVA_FIELD: return createJavaField();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RootPSM createRootPSM() {
		RootPSMImpl rootPSM = new RootPSMImpl();
		return rootPSM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SystemProjectArtifactsModel createSystemProjectArtifactsModel() {
		SystemProjectArtifactsModelImpl systemProjectArtifactsModel = new SystemProjectArtifactsModelImpl();
		return systemProjectArtifactsModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DockerComposeFile createDockerComposeFile() {
		DockerComposeFileImpl dockerComposeFile = new DockerComposeFileImpl();
		return dockerComposeFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainerDefinition createContainerDefinition() {
		ContainerDefinitionImpl containerDefinition = new ContainerDefinitionImpl();
		return containerDefinition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortsField createPortsField() {
		PortsFieldImpl portsField = new PortsFieldImpl();
		return portsField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContainerLink createContainerLink() {
		ContainerLinkImpl containerLink = new ContainerLinkImpl();
		return containerLink;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DockerFile createDockerFile() {
		DockerFileImpl dockerFile = new DockerFileImpl();
		return dockerFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SystemProjectBuildFile createSystemProjectBuildFile() {
		SystemProjectBuildFileImpl systemProjectBuildFile = new SystemProjectBuildFileImpl();
		return systemProjectBuildFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectArtifactsModel createMicroserviceProjectArtifactsModel() {
		MicroserviceProjectArtifactsModelImpl microserviceProjectArtifactsModel = new MicroserviceProjectArtifactsModelImpl();
		return microserviceProjectArtifactsModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectBuildFile createMicroserviceProjectBuildFile() {
		MicroserviceProjectBuildFileImpl microserviceProjectBuildFile = new MicroserviceProjectBuildFileImpl();
		return microserviceProjectBuildFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DependencyLibrary createDependencyLibrary() {
		DependencyLibraryImpl dependencyLibrary = new DependencyLibraryImpl();
		return dependencyLibrary;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicroserviceProjectConfigurationsFile createMicroserviceProjectConfigurationsFile() {
		MicroserviceProjectConfigurationsFileImpl microserviceProjectConfigurationsFile = new MicroserviceProjectConfigurationsFileImpl();
		return microserviceProjectConfigurationsFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConfigurationProperty createConfigurationProperty() {
		ConfigurationPropertyImpl configurationProperty = new ConfigurationPropertyImpl();
		return configurationProperty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SourceFile createSourceFile() {
		SourceFileImpl sourceFile = new SourceFileImpl();
		return sourceFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaSourceFile createJavaSourceFile() {
		JavaSourceFileImpl javaSourceFile = new JavaSourceFileImpl();
		return javaSourceFile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaElement createJavaElement() {
		JavaElementImpl javaElement = new JavaElementImpl();
		return javaElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaAnnotation createJavaAnnotation() {
		JavaAnnotationImpl javaAnnotation = new JavaAnnotationImpl();
		return javaAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaAnnotationParameter createJavaAnnotationParameter() {
		JavaAnnotationParameterImpl javaAnnotationParameter = new JavaAnnotationParameterImpl();
		return javaAnnotationParameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaDataType createJavaDataType() {
		JavaDataTypeImpl javaDataType = new JavaDataTypeImpl();
		return javaDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaUserDefinedType createJavaUserDefinedType() {
		JavaUserDefinedTypeImpl javaUserDefinedType = new JavaUserDefinedTypeImpl();
		return javaUserDefinedType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaClassType createJavaClassType() {
		JavaClassTypeImpl javaClassType = new JavaClassTypeImpl();
		return javaClassType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaInterfaceType createJavaInterfaceType() {
		JavaInterfaceTypeImpl javaInterfaceType = new JavaInterfaceTypeImpl();
		return javaInterfaceType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaMethod createJavaMethod() {
		JavaMethodImpl javaMethod = new JavaMethodImpl();
		return javaMethod;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaField createJavaField() {
		JavaFieldImpl javaField = new JavaFieldImpl();
		return javaField;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PSMPackage getPSMPackage() {
		return (PSMPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PSMPackage getPackage() {
		return PSMPackage.eINSTANCE;
	}

} //PSMFactoryImpl
