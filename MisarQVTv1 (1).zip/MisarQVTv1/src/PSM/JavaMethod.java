/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Java Method</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.JavaMethod#getFields <em>Fields</em>}</li>
 *   <li>{@link PSM.JavaMethod#getInvokes <em>Invokes</em>}</li>
 *   <li>{@link PSM.JavaMethod#getReturns <em>Returns</em>}</li>
 *   <li>{@link PSM.JavaMethod#getParameters <em>Parameters</em>}</li>
 *   <li>{@link PSM.JavaMethod#getOwner <em>Owner</em>}</li>
 *   <li>{@link PSM.JavaMethod#getArgs <em>Args</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getJavaMethod()
 * @model
 * @generated
 */
public interface JavaMethod extends JavaElement {
	/**
	 * Returns the value of the '<em><b>Fields</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaField}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fields</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fields</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaMethod_Fields()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaField> getFields();

	/**
	 * Returns the value of the '<em><b>Invokes</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaMethod}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Invokes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Invokes</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaMethod_Invokes()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaMethod> getInvokes();

	/**
	 * Returns the value of the '<em><b>Returns</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaDataType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Returns</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Returns</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaMethod_Returns()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaDataType> getReturns();

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaDataType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaMethod_Parameters()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaDataType> getParameters();

	/**
	 * Returns the value of the '<em><b>Owner</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Owner</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Owner</em>' containment reference.
	 * @see #setOwner(JavaDataType)
	 * @see PSM.PSMPackage#getJavaMethod_Owner()
	 * @model containment="true" required="true"
	 * @generated
	 */
	JavaDataType getOwner();

	/**
	 * Sets the value of the '{@link PSM.JavaMethod#getOwner <em>Owner</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Owner</em>' containment reference.
	 * @see #getOwner()
	 * @generated
	 */
	void setOwner(JavaDataType value);

	/**
	 * Returns the value of the '<em><b>Args</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaField}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Args</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Args</em>' containment reference list.
	 * @see PSM.PSMPackage#getJavaMethod_Args()
	 * @model containment="true"
	 * @generated
	 */
	EList<JavaField> getArgs();

} // JavaMethod
