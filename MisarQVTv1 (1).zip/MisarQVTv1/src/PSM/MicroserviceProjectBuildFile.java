/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservice Project Build File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.MicroserviceProjectBuildFile#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.MicroserviceProjectBuildFile#getMicroserviceName <em>Microservice Name</em>}</li>
 *   <li>{@link PSM.MicroserviceProjectBuildFile#getDependencies <em>Dependencies</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getMicroserviceProjectBuildFile()
 * @model
 * @generated
 */
public interface MicroserviceProjectBuildFile extends EObject {
	/**
	 * Returns the value of the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>File Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Name</em>' attribute.
	 * @see #setFileName(String)
	 * @see PSM.PSMPackage#getMicroserviceProjectBuildFile_FileName()
	 * @model
	 * @generated
	 */
	String getFileName();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProjectBuildFile#getFileName <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Name</em>' attribute.
	 * @see #getFileName()
	 * @generated
	 */
	void setFileName(String value);

	/**
	 * Returns the value of the '<em><b>Microservice Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Microservice Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Microservice Name</em>' attribute.
	 * @see #setMicroserviceName(String)
	 * @see PSM.PSMPackage#getMicroserviceProjectBuildFile_MicroserviceName()
	 * @model
	 * @generated
	 */
	String getMicroserviceName();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProjectBuildFile#getMicroserviceName <em>Microservice Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Microservice Name</em>' attribute.
	 * @see #getMicroserviceName()
	 * @generated
	 */
	void setMicroserviceName(String value);

	/**
	 * Returns the value of the '<em><b>Dependencies</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.DependencyLibrary}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dependencies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dependencies</em>' containment reference list.
	 * @see PSM.PSMPackage#getMicroserviceProjectBuildFile_Dependencies()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<DependencyLibrary> getDependencies();

} // MicroserviceProjectBuildFile
