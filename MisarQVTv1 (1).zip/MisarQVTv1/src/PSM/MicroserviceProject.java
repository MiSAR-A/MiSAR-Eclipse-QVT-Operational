/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservice Project</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.MicroserviceProject#getProjectName <em>Project Name</em>}</li>
 *   <li>{@link PSM.MicroserviceProject#getBuild <em>Build</em>}</li>
 *   <li>{@link PSM.MicroserviceProject#getConfig <em>Config</em>}</li>
 *   <li>{@link PSM.MicroserviceProject#getSource <em>Source</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getMicroserviceProject()
 * @model
 * @generated
 */
public interface MicroserviceProject extends EObject {
	/**
	 * Returns the value of the '<em><b>Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Project Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Project Name</em>' attribute.
	 * @see #setProjectName(String)
	 * @see PSM.PSMPackage#getMicroserviceProject_ProjectName()
	 * @model
	 * @generated
	 */
	String getProjectName();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProject#getProjectName <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Project Name</em>' attribute.
	 * @see #getProjectName()
	 * @generated
	 */
	void setProjectName(String value);

	/**
	 * Returns the value of the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Build</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Build</em>' containment reference.
	 * @see #setBuild(MicroserviceProjectBuildFile)
	 * @see PSM.PSMPackage#getMicroserviceProject_Build()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroserviceProjectBuildFile getBuild();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProject#getBuild <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Build</em>' containment reference.
	 * @see #getBuild()
	 * @generated
	 */
	void setBuild(MicroserviceProjectBuildFile value);

	/**
	 * Returns the value of the '<em><b>Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Config</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Config</em>' containment reference.
	 * @see #setConfig(MicroserviceProjectConfigurationsFile)
	 * @see PSM.PSMPackage#getMicroserviceProject_Config()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroserviceProjectConfigurationsFile getConfig();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProject#getConfig <em>Config</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Config</em>' containment reference.
	 * @see #getConfig()
	 * @generated
	 */
	void setConfig(MicroserviceProjectConfigurationsFile value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.SourceFile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' containment reference list.
	 * @see PSM.PSMPackage#getMicroserviceProject_Source()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<SourceFile> getSource();

} // MicroserviceProject
