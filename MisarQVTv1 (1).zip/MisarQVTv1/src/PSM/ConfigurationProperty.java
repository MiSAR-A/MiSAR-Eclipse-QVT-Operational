/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Configuration Property</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.ConfigurationProperty#getFullyQualifiedPropertyName <em>Fully Qualified Property Name</em>}</li>
 *   <li>{@link PSM.ConfigurationProperty#getPropertyValue <em>Property Value</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getConfigurationProperty()
 * @model
 * @generated
 */
public interface ConfigurationProperty extends EObject {
	/**
	 * Returns the value of the '<em><b>Fully Qualified Property Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fully Qualified Property Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fully Qualified Property Name</em>' attribute.
	 * @see #setFullyQualifiedPropertyName(String)
	 * @see PSM.PSMPackage#getConfigurationProperty_FullyQualifiedPropertyName()
	 * @model
	 * @generated
	 */
	String getFullyQualifiedPropertyName();

	/**
	 * Sets the value of the '{@link PSM.ConfigurationProperty#getFullyQualifiedPropertyName <em>Fully Qualified Property Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fully Qualified Property Name</em>' attribute.
	 * @see #getFullyQualifiedPropertyName()
	 * @generated
	 */
	void setFullyQualifiedPropertyName(String value);

	/**
	 * Returns the value of the '<em><b>Property Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Property Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Property Value</em>' attribute.
	 * @see #setPropertyValue(String)
	 * @see PSM.PSMPackage#getConfigurationProperty_PropertyValue()
	 * @model
	 * @generated
	 */
	String getPropertyValue();

	/**
	 * Sets the value of the '{@link PSM.ConfigurationProperty#getPropertyValue <em>Property Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property Value</em>' attribute.
	 * @see #getPropertyValue()
	 * @generated
	 */
	void setPropertyValue(String value);

} // ConfigurationProperty
