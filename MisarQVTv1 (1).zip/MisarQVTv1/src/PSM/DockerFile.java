/**
 */
package PSM;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Docker File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.DockerFile#getFileName <em>File Name</em>}</li>
 *   <li>{@link PSM.DockerFile#getCommandFROM <em>Command FROM</em>}</li>
 *   <li>{@link PSM.DockerFile#getCommandEXPOSE <em>Command EXPOSE</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getDockerFile()
 * @model
 * @generated
 */
public interface DockerFile extends EObject {
	/**
	 * Returns the value of the '<em><b>File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>File Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File Name</em>' attribute.
	 * @see #setFileName(String)
	 * @see PSM.PSMPackage#getDockerFile_FileName()
	 * @model
	 * @generated
	 */
	String getFileName();

	/**
	 * Sets the value of the '{@link PSM.DockerFile#getFileName <em>File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Name</em>' attribute.
	 * @see #getFileName()
	 * @generated
	 */
	void setFileName(String value);

	/**
	 * Returns the value of the '<em><b>Command FROM</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Command FROM</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Command FROM</em>' attribute.
	 * @see #setCommandFROM(String)
	 * @see PSM.PSMPackage#getDockerFile_CommandFROM()
	 * @model
	 * @generated
	 */
	String getCommandFROM();

	/**
	 * Sets the value of the '{@link PSM.DockerFile#getCommandFROM <em>Command FROM</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Command FROM</em>' attribute.
	 * @see #getCommandFROM()
	 * @generated
	 */
	void setCommandFROM(String value);

	/**
	 * Returns the value of the '<em><b>Command EXPOSE</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Command EXPOSE</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Command EXPOSE</em>' attribute.
	 * @see #setCommandEXPOSE(String)
	 * @see PSM.PSMPackage#getDockerFile_CommandEXPOSE()
	 * @model
	 * @generated
	 */
	String getCommandEXPOSE();

	/**
	 * Sets the value of the '{@link PSM.DockerFile#getCommandEXPOSE <em>Command EXPOSE</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Command EXPOSE</em>' attribute.
	 * @see #getCommandEXPOSE()
	 * @generated
	 */
	void setCommandEXPOSE(String value);

} // DockerFile
