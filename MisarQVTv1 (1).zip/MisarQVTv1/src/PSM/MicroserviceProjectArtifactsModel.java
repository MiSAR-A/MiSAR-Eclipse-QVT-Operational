/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microservice Project Artifacts Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.MicroserviceProjectArtifactsModel#getProjectName <em>Project Name</em>}</li>
 *   <li>{@link PSM.MicroserviceProjectArtifactsModel#getBuild <em>Build</em>}</li>
 *   <li>{@link PSM.MicroserviceProjectArtifactsModel#getConfig <em>Config</em>}</li>
 *   <li>{@link PSM.MicroserviceProjectArtifactsModel#getSources <em>Sources</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getMicroserviceProjectArtifactsModel()
 * @model
 * @generated
 */
public interface MicroserviceProjectArtifactsModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Project Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Project Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Project Name</em>' attribute.
	 * @see #setProjectName(String)
	 * @see PSM.PSMPackage#getMicroserviceProjectArtifactsModel_ProjectName()
	 * @model
	 * @generated
	 */
	String getProjectName();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProjectArtifactsModel#getProjectName <em>Project Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Project Name</em>' attribute.
	 * @see #getProjectName()
	 * @generated
	 */
	void setProjectName(String value);

	/**
	 * Returns the value of the '<em><b>Build</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Build</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Build</em>' containment reference.
	 * @see #setBuild(MicroserviceProjectBuildFile)
	 * @see PSM.PSMPackage#getMicroserviceProjectArtifactsModel_Build()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroserviceProjectBuildFile getBuild();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProjectArtifactsModel#getBuild <em>Build</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Build</em>' containment reference.
	 * @see #getBuild()
	 * @generated
	 */
	void setBuild(MicroserviceProjectBuildFile value);

	/**
	 * Returns the value of the '<em><b>Config</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Config</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Config</em>' containment reference.
	 * @see #setConfig(MicroserviceProjectConfigurationsFile)
	 * @see PSM.PSMPackage#getMicroserviceProjectArtifactsModel_Config()
	 * @model containment="true" required="true"
	 * @generated
	 */
	MicroserviceProjectConfigurationsFile getConfig();

	/**
	 * Sets the value of the '{@link PSM.MicroserviceProjectArtifactsModel#getConfig <em>Config</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Config</em>' containment reference.
	 * @see #getConfig()
	 * @generated
	 */
	void setConfig(MicroserviceProjectConfigurationsFile value);

	/**
	 * Returns the value of the '<em><b>Sources</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.SourceFile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sources</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sources</em>' containment reference list.
	 * @see PSM.PSMPackage#getMicroserviceProjectArtifactsModel_Sources()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<SourceFile> getSources();

} // MicroserviceProjectArtifactsModel
