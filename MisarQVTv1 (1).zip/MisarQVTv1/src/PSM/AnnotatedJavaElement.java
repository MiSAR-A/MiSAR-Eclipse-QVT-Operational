/**
 */
package PSM;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Annotated Java Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link PSM.AnnotatedJavaElement#getAnnotation <em>Annotation</em>}</li>
 * </ul>
 *
 * @see PSM.PSMPackage#getAnnotatedJavaElement()
 * @model
 * @generated
 */
public interface AnnotatedJavaElement extends JavaElement {
	/**
	 * Returns the value of the '<em><b>Annotation</b></em>' containment reference list.
	 * The list contents are of type {@link PSM.JavaAnnotation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Annotation</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Annotation</em>' containment reference list.
	 * @see PSM.PSMPackage#getAnnotatedJavaElement_Annotation()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<JavaAnnotation> getAnnotation();

} // AnnotatedJavaElement
